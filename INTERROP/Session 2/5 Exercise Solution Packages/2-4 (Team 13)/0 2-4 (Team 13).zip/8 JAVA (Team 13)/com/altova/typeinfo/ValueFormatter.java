// ValueFormatter.java 
// This file contains generated code and will be overwritten when you rerun code generation.


package com.altova.typeinfo;

public interface ValueFormatter
{
}

