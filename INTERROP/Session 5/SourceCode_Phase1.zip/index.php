Inventory management: <a href="inventory_mgmt.php">here</a><br>
Order management: <a href="order_mgmt.php">here</a><br>
Progresss management: <a href="progress_mgmt.php">here</a><br>