/**
 */
package at.ac.univie.swa.ase2015.a9902268.task3.wikiML;


/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Abstract Unformatted Inline Content</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see at.ac.univie.swa.ase2015.a9902268.task3.wikiML.WikiMLPackage#getAbstractUnformattedInlineContent()
 * @model
 * @generated
 */
public interface AbstractUnformattedInlineContent extends AnyText
{
} // AbstractUnformattedInlineContent
