/**
 */
package at.ac.univie.swa.ase2015.a9902268.task3.wikiML;


/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Heading4</b></em>'.
 * <!-- end-user-doc -->
 *
 * <p>
 * The following features are supported:
 * </p>
 * <ul>
 *   <li>{@link at.ac.univie.swa.ase2015.a9902268.task3.wikiML.Heading4#getHeadingValue4 <em>Heading Value4</em>}</li>
 * </ul>
 *
 * @see at.ac.univie.swa.ase2015.a9902268.task3.wikiML.WikiMLPackage#getHeading4()
 * @model
 * @generated
 */
public interface Heading4 extends ParagraphTypes
{
  /**
   * Returns the value of the '<em><b>Heading Value4</b></em>' containment reference.
   * <!-- begin-user-doc -->
   * <p>
   * If the meaning of the '<em>Heading Value4</em>' containment reference isn't clear,
   * there really should be more of a description here...
   * </p>
   * <!-- end-user-doc -->
   * @return the value of the '<em>Heading Value4</em>' containment reference.
   * @see #setHeadingValue4(AbstractUnformattedInlineContent)
   * @see at.ac.univie.swa.ase2015.a9902268.task3.wikiML.WikiMLPackage#getHeading4_HeadingValue4()
   * @model containment="true"
   * @generated
   */
  AbstractUnformattedInlineContent getHeadingValue4();

  /**
   * Sets the value of the '{@link at.ac.univie.swa.ase2015.a9902268.task3.wikiML.Heading4#getHeadingValue4 <em>Heading Value4</em>}' containment reference.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @param value the new value of the '<em>Heading Value4</em>' containment reference.
   * @see #getHeadingValue4()
   * @generated
   */
  void setHeadingValue4(AbstractUnformattedInlineContent value);

} // Heading4
