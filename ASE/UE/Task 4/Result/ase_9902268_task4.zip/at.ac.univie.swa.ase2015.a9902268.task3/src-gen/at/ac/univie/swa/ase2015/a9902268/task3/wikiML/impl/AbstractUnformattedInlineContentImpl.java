/**
 */
package at.ac.univie.swa.ase2015.a9902268.task3.wikiML.impl;

import at.ac.univie.swa.ase2015.a9902268.task3.wikiML.AbstractUnformattedInlineContent;
import at.ac.univie.swa.ase2015.a9902268.task3.wikiML.WikiMLPackage;

import org.eclipse.emf.ecore.EClass;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>Abstract Unformatted Inline Content</b></em>'.
 * <!-- end-user-doc -->
 *
 * @generated
 */
public class AbstractUnformattedInlineContentImpl extends AnyTextImpl implements AbstractUnformattedInlineContent
{
  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  protected AbstractUnformattedInlineContentImpl()
  {
    super();
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  @Override
  protected EClass eStaticClass()
  {
    return WikiMLPackage.Literals.ABSTRACT_UNFORMATTED_INLINE_CONTENT;
  }

} //AbstractUnformattedInlineContentImpl
