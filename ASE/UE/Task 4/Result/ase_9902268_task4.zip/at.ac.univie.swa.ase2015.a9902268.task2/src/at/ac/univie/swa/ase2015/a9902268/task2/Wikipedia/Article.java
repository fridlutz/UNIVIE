/**
 */
package at.ac.univie.swa.ase2015.a9902268.task2.Wikipedia;


/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Article</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see at.ac.univie.swa.ase2015.a9902268.task2.Wikipedia.ModelPackage#getArticle()
 * @model
 * @generated
 */
public interface Article extends Content {
} // Article
