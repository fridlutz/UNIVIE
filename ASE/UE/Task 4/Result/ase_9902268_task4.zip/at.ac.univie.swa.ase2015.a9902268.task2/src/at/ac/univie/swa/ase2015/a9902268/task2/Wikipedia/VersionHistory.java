/**
 */
package at.ac.univie.swa.ase2015.a9902268.task2.Wikipedia;

import org.eclipse.emf.ecore.EObject;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Version History</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see at.ac.univie.swa.ase2015.a9902268.task2.Wikipedia.ModelPackage#getVersionHistory()
 * @model
 * @generated
 */
public interface VersionHistory extends EObject {
	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @model
	 * @generated
	 */
	String renderHTML();

} // VersionHistory
