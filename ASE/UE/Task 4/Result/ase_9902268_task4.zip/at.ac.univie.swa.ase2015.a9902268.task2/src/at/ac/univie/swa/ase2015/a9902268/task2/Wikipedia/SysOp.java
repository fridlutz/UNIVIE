/**
 */
package at.ac.univie.swa.ase2015.a9902268.task2.Wikipedia;


/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Sys Op</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see at.ac.univie.swa.ase2015.a9902268.task2.Wikipedia.ModelPackage#getSysOp()
 * @model
 * @generated
 */
public interface SysOp extends RegisteredUser {
} // SysOp
