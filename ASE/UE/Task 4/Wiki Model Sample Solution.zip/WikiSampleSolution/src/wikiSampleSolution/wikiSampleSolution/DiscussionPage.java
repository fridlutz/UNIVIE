/**
 */
package wikiSampleSolution.wikiSampleSolution;


/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Discussion Page</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see wikiSampleSolution.wikiSampleSolution.WikiSampleSolutionPackage#getDiscussionPage()
 * @model
 * @generated
 */
public interface DiscussionPage extends Content {
} // DiscussionPage
