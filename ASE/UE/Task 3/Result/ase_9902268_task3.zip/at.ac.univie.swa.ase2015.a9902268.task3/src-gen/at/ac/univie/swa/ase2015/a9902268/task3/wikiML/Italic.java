/**
 */
package at.ac.univie.swa.ase2015.a9902268.task3.wikiML;


/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Italic</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see at.ac.univie.swa.ase2015.a9902268.task3.wikiML.WikiMLPackage#getItalic()
 * @model
 * @generated
 */
public interface Italic extends AbstractFormattedInlineContent
{
} // Italic
