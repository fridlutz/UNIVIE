/**
 */
package wikiSampleSolution.wikiSampleSolution.tests;

import junit.framework.TestCase;

import wikiSampleSolution.wikiSampleSolution.Subscribable;

/**
 * <!-- begin-user-doc -->
 * A test case for the model object '<em><b>Subscribable</b></em>'.
 * <!-- end-user-doc -->
 * @generated
 */
public abstract class SubscribableTest extends TestCase {

	/**
	 * The fixture for this Subscribable test case.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected Subscribable fixture = null;

	/**
	 * Constructs a new Subscribable test case with the given name.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public SubscribableTest(String name) {
		super(name);
	}

	/**
	 * Sets the fixture for this Subscribable test case.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected void setFixture(Subscribable fixture) {
		this.fixture = fixture;
	}

	/**
	 * Returns the fixture for this Subscribable test case.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected Subscribable getFixture() {
		return fixture;
	}

} //SubscribableTest
