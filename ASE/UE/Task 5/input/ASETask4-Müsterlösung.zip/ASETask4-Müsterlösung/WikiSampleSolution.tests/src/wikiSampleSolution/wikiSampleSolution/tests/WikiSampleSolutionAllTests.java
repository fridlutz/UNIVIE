/**
 */
package wikiSampleSolution.wikiSampleSolution.tests;

import junit.framework.Test;
import junit.framework.TestSuite;

import junit.textui.TestRunner;

/**
 * <!-- begin-user-doc -->
 * A test suite for the '<em><b>WikiSampleSolution</b></em>' model.
 * <!-- end-user-doc -->
 * @generated
 */
public class WikiSampleSolutionAllTests extends TestSuite {

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public static void main(String[] args) {
		TestRunner.run(suite());
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public static Test suite() {
		TestSuite suite = new WikiSampleSolutionAllTests("WikiSampleSolution Tests");
		suite.addTest(WikiSampleSolutionTests.suite());
		return suite;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public WikiSampleSolutionAllTests(String name) {
		super(name);
	}

} //WikiSampleSolutionAllTests
