/**
 */
package wikiSampleSolution.wikiSampleSolution.tests;

import junit.framework.TestCase;

import wikiSampleSolution.wikiSampleSolution.Content;

/**
 * <!-- begin-user-doc -->
 * A test case for the model object '<em><b>Content</b></em>'.
 * <!-- end-user-doc -->
 * @generated
 */
public abstract class ContentTest extends TestCase {

	/**
	 * The fixture for this Content test case.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected Content fixture = null;

	/**
	 * Constructs a new Content test case with the given name.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public ContentTest(String name) {
		super(name);
	}

	/**
	 * Sets the fixture for this Content test case.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected void setFixture(Content fixture) {
		this.fixture = fixture;
	}

	/**
	 * Returns the fixture for this Content test case.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected Content getFixture() {
		return fixture;
	}

} //ContentTest
