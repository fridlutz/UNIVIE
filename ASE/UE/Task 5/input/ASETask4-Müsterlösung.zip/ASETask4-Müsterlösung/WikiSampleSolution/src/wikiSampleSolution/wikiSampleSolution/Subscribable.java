/**
 */
package wikiSampleSolution.wikiSampleSolution;

import org.eclipse.emf.ecore.EObject;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Subscribable</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see wikiSampleSolution.wikiSampleSolution.WikiSampleSolutionPackage#getSubscribable()
 * @model interface="true" abstract="true"
 * @generated
 */
public interface Subscribable extends EObject {
} // Subscribable
