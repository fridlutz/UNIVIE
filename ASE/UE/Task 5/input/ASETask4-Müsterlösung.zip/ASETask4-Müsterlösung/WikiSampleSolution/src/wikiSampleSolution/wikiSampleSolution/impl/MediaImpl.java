/**
 */
package wikiSampleSolution.wikiSampleSolution.impl;

import org.eclipse.emf.ecore.EClass;

import wikiSampleSolution.wikiSampleSolution.Media;
import wikiSampleSolution.wikiSampleSolution.WikiSampleSolutionPackage;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>Media</b></em>'.
 * <!-- end-user-doc -->
 *
 * @generated
 */
public class MediaImpl extends ContentImpl implements Media {
	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected MediaImpl() {
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected EClass eStaticClass() {
		return WikiSampleSolutionPackage.Literals.MEDIA;
	}

} //MediaImpl
