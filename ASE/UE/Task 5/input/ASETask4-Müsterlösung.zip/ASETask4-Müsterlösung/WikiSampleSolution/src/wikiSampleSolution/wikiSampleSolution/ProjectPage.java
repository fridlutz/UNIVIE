/**
 */
package wikiSampleSolution.wikiSampleSolution;


/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Project Page</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see wikiSampleSolution.wikiSampleSolution.WikiSampleSolutionPackage#getProjectPage()
 * @model
 * @generated
 */
public interface ProjectPage extends Content, Subscribable {
} // ProjectPage
