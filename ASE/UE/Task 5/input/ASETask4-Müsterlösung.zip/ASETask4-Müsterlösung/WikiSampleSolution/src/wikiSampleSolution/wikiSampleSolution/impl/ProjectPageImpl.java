/**
 */
package wikiSampleSolution.wikiSampleSolution.impl;

import org.eclipse.emf.ecore.EClass;

import wikiSampleSolution.wikiSampleSolution.ProjectPage;
import wikiSampleSolution.wikiSampleSolution.WikiSampleSolutionPackage;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>Project Page</b></em>'.
 * <!-- end-user-doc -->
 *
 * @generated
 */
public class ProjectPageImpl extends ContentImpl implements ProjectPage {
	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected ProjectPageImpl() {
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected EClass eStaticClass() {
		return WikiSampleSolutionPackage.Literals.PROJECT_PAGE;
	}

} //ProjectPageImpl
