/**
 */
package wikiSampleSolution.wikiSampleSolution;


/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Article</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see wikiSampleSolution.wikiSampleSolution.WikiSampleSolutionPackage#getArticle()
 * @model
 * @generated
 */
public interface Article extends Content {
} // Article
