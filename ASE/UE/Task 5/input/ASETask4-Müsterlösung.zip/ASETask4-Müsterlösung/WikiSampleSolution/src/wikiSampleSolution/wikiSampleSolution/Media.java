/**
 */
package wikiSampleSolution.wikiSampleSolution;


/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Media</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see wikiSampleSolution.wikiSampleSolution.WikiSampleSolutionPackage#getMedia()
 * @model
 * @generated
 */
public interface Media extends Content {
} // Media
