package at.ac.univie.swa.ase2014.a1276754.task1.model;

public abstract class StreamingMedia extends Media {
	public int Groesse; //MB
	
	public StreamingMedia(){
		super();
		this.Groesse = 500;		
	}
}
