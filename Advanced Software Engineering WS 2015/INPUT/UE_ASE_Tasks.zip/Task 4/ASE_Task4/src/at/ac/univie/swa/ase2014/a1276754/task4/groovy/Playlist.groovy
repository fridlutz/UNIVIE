package at.ac.univie.swa.ase2014.a1276754.task4.groovy

class Playlist {
	def name
	def include = []
	List<Song> exclude
	
}
