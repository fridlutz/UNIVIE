/**
 */
package netflix;

import org.eclipse.emf.common.util.EList;

import org.eclipse.emf.ecore.EObject;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Recommendation</b></em>'.
 * <!-- end-user-doc -->
 *
 * <p>
 * The following features are supported:
 * <ul>
 *   <li>{@link netflix.Recommendation#getMediaRecommendation <em>Media Recommendation</em>}</li>
 *   <li>{@link netflix.Recommendation#getMedia <em>Media</em>}</li>
 * </ul>
 * </p>
 *
 * @see netflix.NetflixPackage#getRecommendation()
 * @model
 * @generated
 */
public interface Recommendation extends EObject {
	/**
	 * Returns the value of the '<em><b>Media Recommendation</b></em>' reference list.
	 * The list contents are of type {@link netflix.Profile}.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Media Recommendation</em>' reference list isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Media Recommendation</em>' reference list.
	 * @see netflix.NetflixPackage#getRecommendation_MediaRecommendation()
	 * @model required="true"
	 * @generated
	 */
	EList<Profile> getMediaRecommendation();

	/**
	 * Returns the value of the '<em><b>Media</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Media</em>' reference isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Media</em>' reference.
	 * @see #setMedia(Media)
	 * @see netflix.NetflixPackage#getRecommendation_Media()
	 * @model required="true"
	 * @generated
	 */
	Media getMedia();

	/**
	 * Sets the value of the '{@link netflix.Recommendation#getMedia <em>Media</em>}' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Media</em>' reference.
	 * @see #getMedia()
	 * @generated
	 */
	void setMedia(Media value);

} // Recommendation
