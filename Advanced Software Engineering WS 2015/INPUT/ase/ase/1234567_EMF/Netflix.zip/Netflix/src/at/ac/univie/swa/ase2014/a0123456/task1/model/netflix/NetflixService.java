/**
 */
package at.ac.univie.swa.ase2014.a0123456.task1.model.netflix;

import org.eclipse.emf.ecore.EObject;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Service</b></em>'.
 * <!-- end-user-doc -->
 *
 * <p>
 * The following features are supported:
 * <ul>
 *   <li>{@link at.ac.univie.swa.ase2014.a0123456.task1.model.netflix.NetflixService#getStreamService <em>Stream Service</em>}</li>
 *   <li>{@link at.ac.univie.swa.ase2014.a0123456.task1.model.netflix.NetflixService#getSubscriptionManagement <em>Subscription Management</em>}</li>
 *   <li>{@link at.ac.univie.swa.ase2014.a0123456.task1.model.netflix.NetflixService#getStreamLibrary <em>Stream Library</em>}</li>
 * </ul>
 * </p>
 *
 * @see at.ac.univie.swa.ase2014.a0123456.task1.model.netflix.NetflixPackage#getNetflixService()
 * @model
 * @generated
 */
public interface NetflixService extends EObject {
	/**
	 * Returns the value of the '<em><b>Stream Service</b></em>' containment reference.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Stream Service</em>' containment reference isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Stream Service</em>' containment reference.
	 * @see #setStreamService(StreamService)
	 * @see at.ac.univie.swa.ase2014.a0123456.task1.model.netflix.NetflixPackage#getNetflixService_StreamService()
	 * @model containment="true" required="true"
	 * @generated
	 */
	StreamService getStreamService();

	/**
	 * Sets the value of the '{@link at.ac.univie.swa.ase2014.a0123456.task1.model.netflix.NetflixService#getStreamService <em>Stream Service</em>}' containment reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Stream Service</em>' containment reference.
	 * @see #getStreamService()
	 * @generated
	 */
	void setStreamService(StreamService value);

	/**
	 * Returns the value of the '<em><b>Subscription Management</b></em>' containment reference.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Subscription Management</em>' containment reference isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Subscription Management</em>' containment reference.
	 * @see #setSubscriptionManagement(SubscriptionManagement)
	 * @see at.ac.univie.swa.ase2014.a0123456.task1.model.netflix.NetflixPackage#getNetflixService_SubscriptionManagement()
	 * @model containment="true" required="true"
	 * @generated
	 */
	SubscriptionManagement getSubscriptionManagement();

	/**
	 * Sets the value of the '{@link at.ac.univie.swa.ase2014.a0123456.task1.model.netflix.NetflixService#getSubscriptionManagement <em>Subscription Management</em>}' containment reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Subscription Management</em>' containment reference.
	 * @see #getSubscriptionManagement()
	 * @generated
	 */
	void setSubscriptionManagement(SubscriptionManagement value);

	/**
	 * Returns the value of the '<em><b>Stream Library</b></em>' containment reference.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Stream Library</em>' containment reference isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Stream Library</em>' containment reference.
	 * @see #setStreamLibrary(StreamingLibrary)
	 * @see at.ac.univie.swa.ase2014.a0123456.task1.model.netflix.NetflixPackage#getNetflixService_StreamLibrary()
	 * @model containment="true" required="true"
	 * @generated
	 */
	StreamingLibrary getStreamLibrary();

	/**
	 * Sets the value of the '{@link at.ac.univie.swa.ase2014.a0123456.task1.model.netflix.NetflixService#getStreamLibrary <em>Stream Library</em>}' containment reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Stream Library</em>' containment reference.
	 * @see #getStreamLibrary()
	 * @generated
	 */
	void setStreamLibrary(StreamingLibrary value);

} // NetflixService
