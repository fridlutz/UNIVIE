/**
 */
package at.ac.univie.swa.ase2014.a0123456.task1.model.netflix;

import org.eclipse.emf.ecore.EObject;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Device</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see at.ac.univie.swa.ase2014.a0123456.task1.model.netflix.NetflixPackage#getDevice()
 * @model
 * @generated
 */
public interface Device extends EObject {
} // Device
