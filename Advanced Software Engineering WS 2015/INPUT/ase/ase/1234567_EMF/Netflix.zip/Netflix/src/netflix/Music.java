/**
 */
package netflix;


/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Music</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see netflix.NetflixPackage#getMusic()
 * @model
 * @generated
 */
public interface Music extends StreamingMedia {
} // Music
