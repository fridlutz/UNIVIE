/**
 */
package at.ac.univie.swa.ase2014.a0123456.task1.model.netflix.impl;

import at.ac.univie.swa.ase2014.a0123456.task1.model.netflix.LicenseHolder;
import at.ac.univie.swa.ase2014.a0123456.task1.model.netflix.Media;
import at.ac.univie.swa.ase2014.a0123456.task1.model.netflix.NetflixPackage;
import at.ac.univie.swa.ase2014.a0123456.task1.model.netflix.StreamingLibrary;

import java.util.Collection;

import org.eclipse.emf.common.notify.NotificationChain;

import org.eclipse.emf.common.util.EList;

import org.eclipse.emf.ecore.EClass;
import org.eclipse.emf.ecore.InternalEObject;

import org.eclipse.emf.ecore.impl.MinimalEObjectImpl;

import org.eclipse.emf.ecore.util.EObjectContainmentEList;
import org.eclipse.emf.ecore.util.InternalEList;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>Streaming Library</b></em>'.
 * <!-- end-user-doc -->
 * <p>
 * The following features are implemented:
 * <ul>
 *   <li>{@link at.ac.univie.swa.ase2014.a0123456.task1.model.netflix.impl.StreamingLibraryImpl#getMedien <em>Medien</em>}</li>
 *   <li>{@link at.ac.univie.swa.ase2014.a0123456.task1.model.netflix.impl.StreamingLibraryImpl#getLicenseHolders <em>License Holders</em>}</li>
 * </ul>
 * </p>
 *
 * @generated
 */
public class StreamingLibraryImpl extends MinimalEObjectImpl.Container implements StreamingLibrary {
	/**
	 * The cached value of the '{@link #getMedien() <em>Medien</em>}' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getMedien()
	 * @generated
	 * @ordered
	 */
	protected EList<Media> medien;

	/**
	 * The cached value of the '{@link #getLicenseHolders() <em>License Holders</em>}' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getLicenseHolders()
	 * @generated
	 * @ordered
	 */
	protected EList<LicenseHolder> licenseHolders;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected StreamingLibraryImpl() {
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected EClass eStaticClass() {
		return NetflixPackage.Literals.STREAMING_LIBRARY;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EList<Media> getMedien() {
		if (medien == null) {
			medien = new EObjectContainmentEList<Media>(Media.class, this, NetflixPackage.STREAMING_LIBRARY__MEDIEN);
		}
		return medien;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EList<LicenseHolder> getLicenseHolders() {
		if (licenseHolders == null) {
			licenseHolders = new EObjectContainmentEList<LicenseHolder>(LicenseHolder.class, this, NetflixPackage.STREAMING_LIBRARY__LICENSE_HOLDERS);
		}
		return licenseHolders;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public NotificationChain eInverseRemove(InternalEObject otherEnd, int featureID, NotificationChain msgs) {
		switch (featureID) {
			case NetflixPackage.STREAMING_LIBRARY__MEDIEN:
				return ((InternalEList<?>)getMedien()).basicRemove(otherEnd, msgs);
			case NetflixPackage.STREAMING_LIBRARY__LICENSE_HOLDERS:
				return ((InternalEList<?>)getLicenseHolders()).basicRemove(otherEnd, msgs);
		}
		return super.eInverseRemove(otherEnd, featureID, msgs);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public Object eGet(int featureID, boolean resolve, boolean coreType) {
		switch (featureID) {
			case NetflixPackage.STREAMING_LIBRARY__MEDIEN:
				return getMedien();
			case NetflixPackage.STREAMING_LIBRARY__LICENSE_HOLDERS:
				return getLicenseHolders();
		}
		return super.eGet(featureID, resolve, coreType);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@SuppressWarnings("unchecked")
	@Override
	public void eSet(int featureID, Object newValue) {
		switch (featureID) {
			case NetflixPackage.STREAMING_LIBRARY__MEDIEN:
				getMedien().clear();
				getMedien().addAll((Collection<? extends Media>)newValue);
				return;
			case NetflixPackage.STREAMING_LIBRARY__LICENSE_HOLDERS:
				getLicenseHolders().clear();
				getLicenseHolders().addAll((Collection<? extends LicenseHolder>)newValue);
				return;
		}
		super.eSet(featureID, newValue);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void eUnset(int featureID) {
		switch (featureID) {
			case NetflixPackage.STREAMING_LIBRARY__MEDIEN:
				getMedien().clear();
				return;
			case NetflixPackage.STREAMING_LIBRARY__LICENSE_HOLDERS:
				getLicenseHolders().clear();
				return;
		}
		super.eUnset(featureID);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public boolean eIsSet(int featureID) {
		switch (featureID) {
			case NetflixPackage.STREAMING_LIBRARY__MEDIEN:
				return medien != null && !medien.isEmpty();
			case NetflixPackage.STREAMING_LIBRARY__LICENSE_HOLDERS:
				return licenseHolders != null && !licenseHolders.isEmpty();
		}
		return super.eIsSet(featureID);
	}

} //StreamingLibraryImpl
