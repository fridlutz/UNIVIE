/**
 */
package at.ac.univie.swa.ase2014.a0123456.task1.model.netflix.impl;

import at.ac.univie.swa.ase2014.a0123456.task1.model.netflix.Movie;
import at.ac.univie.swa.ase2014.a0123456.task1.model.netflix.NetflixPackage;

import org.eclipse.emf.ecore.EClass;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>Movie</b></em>'.
 * <!-- end-user-doc -->
 * <p>
 * </p>
 *
 * @generated
 */
public class MovieImpl extends StreamingMediaImpl implements Movie {
	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected MovieImpl() {
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected EClass eStaticClass() {
		return NetflixPackage.Literals.MOVIE;
	}

} //MovieImpl
