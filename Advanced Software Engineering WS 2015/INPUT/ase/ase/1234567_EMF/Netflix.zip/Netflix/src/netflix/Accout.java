/**
 */
package netflix;

import org.eclipse.emf.common.util.EList;

import org.eclipse.emf.ecore.EObject;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Accout</b></em>'.
 * <!-- end-user-doc -->
 *
 * <p>
 * The following features are supported:
 * <ul>
 *   <li>{@link netflix.Accout#getProfiles <em>Profiles</em>}</li>
 *   <li>{@link netflix.Accout#getDevices <em>Devices</em>}</li>
 *   <li>{@link netflix.Accout#getEmail <em>Email</em>}</li>
 *   <li>{@link netflix.Accout#getPwd <em>Pwd</em>}</li>
 *   <li>{@link netflix.Accout#getRentedMedias <em>Rented Medias</em>}</li>
 *   <li>{@link netflix.Accout#getCountry <em>Country</em>}</li>
 * </ul>
 * </p>
 *
 * @see netflix.NetflixPackage#getAccout()
 * @model annotation="http://www.eclipse.org/emf/2002/Ecore constraints='mustHaveFiveProfiles customerFromUS reviewOnlyRentedDVDs mustHaveEmail'"
 *        annotation="http://www.eclipse.org/emf/2002/Ecore/OCL/Pivot mustHaveFiveProfiles='profiles->size() <= 5' customerFromUS='rentedMedias->exists(m | m.oclIsKindOf(DVD)) implies country = \'US\'' reviewOnlyRentedDVDs='profiles->forAll(p | p.reviews->forAll(r | r.media.oclIsKindOf(DVD) implies rentedMedias->exists(rm | r.media = rm)))' mustHaveEmail='not email.oclIsUndefined()'"
 * @generated
 */
public interface Accout extends EObject {
	/**
	 * Returns the value of the '<em><b>Profiles</b></em>' containment reference list.
	 * The list contents are of type {@link netflix.Profile}.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Profiles</em>' containment reference list isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Profiles</em>' containment reference list.
	 * @see netflix.NetflixPackage#getAccout_Profiles()
	 * @model containment="true"
	 * @generated
	 */
	EList<Profile> getProfiles();

	/**
	 * Returns the value of the '<em><b>Devices</b></em>' reference list.
	 * The list contents are of type {@link netflix.Device}.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Devices</em>' reference list isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Devices</em>' reference list.
	 * @see netflix.NetflixPackage#getAccout_Devices()
	 * @model
	 * @generated
	 */
	EList<Device> getDevices();

	/**
	 * Returns the value of the '<em><b>Email</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Email</em>' attribute isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Email</em>' attribute.
	 * @see #setEmail(String)
	 * @see netflix.NetflixPackage#getAccout_Email()
	 * @model
	 * @generated
	 */
	String getEmail();

	/**
	 * Sets the value of the '{@link netflix.Accout#getEmail <em>Email</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Email</em>' attribute.
	 * @see #getEmail()
	 * @generated
	 */
	void setEmail(String value);

	/**
	 * Returns the value of the '<em><b>Pwd</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Pwd</em>' attribute isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Pwd</em>' attribute.
	 * @see #setPwd(String)
	 * @see netflix.NetflixPackage#getAccout_Pwd()
	 * @model
	 * @generated
	 */
	String getPwd();

	/**
	 * Sets the value of the '{@link netflix.Accout#getPwd <em>Pwd</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Pwd</em>' attribute.
	 * @see #getPwd()
	 * @generated
	 */
	void setPwd(String value);

	/**
	 * Returns the value of the '<em><b>Rented Medias</b></em>' reference list.
	 * The list contents are of type {@link netflix.Media}.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Rented Medias</em>' reference list isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Rented Medias</em>' reference list.
	 * @see netflix.NetflixPackage#getAccout_RentedMedias()
	 * @model
	 * @generated
	 */
	EList<Media> getRentedMedias();

	/**
	 * Returns the value of the '<em><b>Country</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Country</em>' attribute isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Country</em>' attribute.
	 * @see #setCountry(String)
	 * @see netflix.NetflixPackage#getAccout_Country()
	 * @model
	 * @generated
	 */
	String getCountry();

	/**
	 * Sets the value of the '{@link netflix.Accout#getCountry <em>Country</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Country</em>' attribute.
	 * @see #getCountry()
	 * @generated
	 */
	void setCountry(String value);

} // Accout
