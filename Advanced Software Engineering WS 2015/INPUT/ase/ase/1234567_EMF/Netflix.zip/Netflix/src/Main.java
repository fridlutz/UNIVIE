import at.ac.swa.ase2014.a0123456.task1.application.view.MediaManagementView;
import at.ac.univie.swa.ase2014.a0123456.task1.model.netflix.Movie;
import at.ac.univie.swa.ase2014.a0123456.task1.model.netflix.NetflixFactory;
import at.ac.univie.swa.ase2014.a0123456.task1.model.netflix.NetflixService;
import at.ac.univie.swa.ase2014.a0123456.task1.model.netflix.StreamingLibrary;
import at.ac.univie.swa.ase2014.a0123456.task1.model.netflix.util.NetflixAdapterFactory;


public class Main {
	private static NetflixService service = NetflixFactory.eINSTANCE.createNetflixService();
	public static void main(String[] args) {
		StreamingLibrary library = NetflixFactory.eINSTANCE.createStreamingLibrary();
		Movie movie1 = NetflixFactory.eINSTANCE.createMovie();
		movie1.setName("Spider man");
		movie1.setLength("190");
		
		Movie movie2 = NetflixFactory.eINSTANCE.createMovie();
		movie2.setName("Iron man");
		movie2.setLength("220");
		
		library.getMedien().add(movie1);
		library.getMedien().add(movie2);
		
		service.setStreamLibrary(library);
		
		MediaManagementView view = new MediaManagementView(service.getStreamLibrary());
		
	}

}
