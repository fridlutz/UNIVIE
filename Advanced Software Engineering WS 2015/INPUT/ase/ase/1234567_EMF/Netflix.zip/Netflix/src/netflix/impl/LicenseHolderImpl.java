/**
 */
package netflix.impl;

import java.util.Collection;

import netflix.LicenseHolder;
import netflix.Media;
import netflix.NetflixPackage;

import org.eclipse.emf.common.util.EList;

import org.eclipse.emf.ecore.EClass;

import org.eclipse.emf.ecore.impl.MinimalEObjectImpl;

import org.eclipse.emf.ecore.util.EObjectResolvingEList;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>License Holder</b></em>'.
 * <!-- end-user-doc -->
 * <p>
 * The following features are implemented:
 * <ul>
 *   <li>{@link netflix.impl.LicenseHolderImpl#getMedien <em>Medien</em>}</li>
 * </ul>
 * </p>
 *
 * @generated
 */
public abstract class LicenseHolderImpl extends MinimalEObjectImpl.Container implements LicenseHolder {
	/**
	 * The cached value of the '{@link #getMedien() <em>Medien</em>}' reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getMedien()
	 * @generated
	 * @ordered
	 */
	protected EList<Media> medien;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected LicenseHolderImpl() {
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected EClass eStaticClass() {
		return NetflixPackage.Literals.LICENSE_HOLDER;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EList<Media> getMedien() {
		if (medien == null) {
			medien = new EObjectResolvingEList<Media>(Media.class, this, NetflixPackage.LICENSE_HOLDER__MEDIEN);
		}
		return medien;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public Object eGet(int featureID, boolean resolve, boolean coreType) {
		switch (featureID) {
			case NetflixPackage.LICENSE_HOLDER__MEDIEN:
				return getMedien();
		}
		return super.eGet(featureID, resolve, coreType);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@SuppressWarnings("unchecked")
	@Override
	public void eSet(int featureID, Object newValue) {
		switch (featureID) {
			case NetflixPackage.LICENSE_HOLDER__MEDIEN:
				getMedien().clear();
				getMedien().addAll((Collection<? extends Media>)newValue);
				return;
		}
		super.eSet(featureID, newValue);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void eUnset(int featureID) {
		switch (featureID) {
			case NetflixPackage.LICENSE_HOLDER__MEDIEN:
				getMedien().clear();
				return;
		}
		super.eUnset(featureID);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public boolean eIsSet(int featureID) {
		switch (featureID) {
			case NetflixPackage.LICENSE_HOLDER__MEDIEN:
				return medien != null && !medien.isEmpty();
		}
		return super.eIsSet(featureID);
	}

} //LicenseHolderImpl
