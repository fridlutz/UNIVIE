/**
 */
package netflix;


/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Distributor</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see netflix.NetflixPackage#getDistributor()
 * @model
 * @generated
 */
public interface Distributor extends LicenseHolder {
} // Distributor
