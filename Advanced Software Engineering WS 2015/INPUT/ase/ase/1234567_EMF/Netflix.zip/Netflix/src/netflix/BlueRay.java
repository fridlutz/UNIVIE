/**
 */
package netflix;


/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Blue Ray</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see netflix.NetflixPackage#getBlueRay()
 * @model
 * @generated
 */
public interface BlueRay extends RentalMedia {
} // BlueRay
