/**
 */
package netflix;

import org.eclipse.emf.common.util.EList;

import org.eclipse.emf.ecore.EObject;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Streaming Library</b></em>'.
 * <!-- end-user-doc -->
 *
 * <p>
 * The following features are supported:
 * <ul>
 *   <li>{@link netflix.StreamingLibrary#getMedien <em>Medien</em>}</li>
 *   <li>{@link netflix.StreamingLibrary#getLicenseHolders <em>License Holders</em>}</li>
 * </ul>
 * </p>
 *
 * @see netflix.NetflixPackage#getStreamingLibrary()
 * @model
 * @generated
 */
public interface StreamingLibrary extends EObject {
	/**
	 * Returns the value of the '<em><b>Medien</b></em>' containment reference list.
	 * The list contents are of type {@link netflix.Media}.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Medien</em>' containment reference list isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Medien</em>' containment reference list.
	 * @see netflix.NetflixPackage#getStreamingLibrary_Medien()
	 * @model containment="true"
	 * @generated
	 */
	EList<Media> getMedien();

	/**
	 * Returns the value of the '<em><b>License Holders</b></em>' containment reference list.
	 * The list contents are of type {@link netflix.LicenseHolder}.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>License Holders</em>' containment reference list isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>License Holders</em>' containment reference list.
	 * @see netflix.NetflixPackage#getStreamingLibrary_LicenseHolders()
	 * @model containment="true"
	 * @generated
	 */
	EList<LicenseHolder> getLicenseHolders();

} // StreamingLibrary
