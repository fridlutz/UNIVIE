/**
 */
package at.ac.univie.swa.ase2014.a0123456.task1.model.netflix;

import org.eclipse.emf.common.util.EList;

import org.eclipse.emf.ecore.EObject;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Profile</b></em>'.
 * <!-- end-user-doc -->
 *
 * <p>
 * The following features are supported:
 * <ul>
 *   <li>{@link at.ac.univie.swa.ase2014.a0123456.task1.model.netflix.Profile#getQueue <em>Queue</em>}</li>
 *   <li>{@link at.ac.univie.swa.ase2014.a0123456.task1.model.netflix.Profile#getFriendList <em>Friend List</em>}</li>
 *   <li>{@link at.ac.univie.swa.ase2014.a0123456.task1.model.netflix.Profile#getReviews <em>Reviews</em>}</li>
 *   <li>{@link at.ac.univie.swa.ase2014.a0123456.task1.model.netflix.Profile#getRecommendations <em>Recommendations</em>}</li>
 * </ul>
 * </p>
 *
 * @see at.ac.univie.swa.ase2014.a0123456.task1.model.netflix.NetflixPackage#getProfile()
 * @model
 * @generated
 */
public interface Profile extends EObject {
	/**
	 * Returns the value of the '<em><b>Queue</b></em>' containment reference.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Queue</em>' containment reference isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Queue</em>' containment reference.
	 * @see #setQueue(FavoriteQueue)
	 * @see at.ac.univie.swa.ase2014.a0123456.task1.model.netflix.NetflixPackage#getProfile_Queue()
	 * @model containment="true" required="true"
	 * @generated
	 */
	FavoriteQueue getQueue();

	/**
	 * Sets the value of the '{@link at.ac.univie.swa.ase2014.a0123456.task1.model.netflix.Profile#getQueue <em>Queue</em>}' containment reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Queue</em>' containment reference.
	 * @see #getQueue()
	 * @generated
	 */
	void setQueue(FavoriteQueue value);

	/**
	 * Returns the value of the '<em><b>Friend List</b></em>' containment reference.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Friend List</em>' containment reference isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Friend List</em>' containment reference.
	 * @see #setFriendList(FriendList)
	 * @see at.ac.univie.swa.ase2014.a0123456.task1.model.netflix.NetflixPackage#getProfile_FriendList()
	 * @model containment="true" required="true"
	 * @generated
	 */
	FriendList getFriendList();

	/**
	 * Sets the value of the '{@link at.ac.univie.swa.ase2014.a0123456.task1.model.netflix.Profile#getFriendList <em>Friend List</em>}' containment reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Friend List</em>' containment reference.
	 * @see #getFriendList()
	 * @generated
	 */
	void setFriendList(FriendList value);

	/**
	 * Returns the value of the '<em><b>Reviews</b></em>' containment reference list.
	 * The list contents are of type {@link at.ac.univie.swa.ase2014.a0123456.task1.model.netflix.Review}.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Reviews</em>' containment reference list isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Reviews</em>' containment reference list.
	 * @see at.ac.univie.swa.ase2014.a0123456.task1.model.netflix.NetflixPackage#getProfile_Reviews()
	 * @model containment="true"
	 * @generated
	 */
	EList<Review> getReviews();

	/**
	 * Returns the value of the '<em><b>Recommendations</b></em>' containment reference list.
	 * The list contents are of type {@link at.ac.univie.swa.ase2014.a0123456.task1.model.netflix.Recommendation}.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Recommendations</em>' containment reference list isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Recommendations</em>' containment reference list.
	 * @see at.ac.univie.swa.ase2014.a0123456.task1.model.netflix.NetflixPackage#getProfile_Recommendations()
	 * @model containment="true"
	 * @generated
	 */
	EList<Recommendation> getRecommendations();

} // Profile
