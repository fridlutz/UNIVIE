/**
 */
package netflix;


/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>TV Serie</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see netflix.NetflixPackage#getTVSerie()
 * @model
 * @generated
 */
public interface TVSerie extends StreamingMedia {
} // TVSerie
