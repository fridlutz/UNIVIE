/**
 */
package at.ac.univie.swa.ase2014.a0123456.task1.model.netflix.impl;

import at.ac.univie.swa.ase2014.a0123456.task1.model.netflix.*;

import org.eclipse.emf.ecore.EClass;
import org.eclipse.emf.ecore.EObject;
import org.eclipse.emf.ecore.EPackage;

import org.eclipse.emf.ecore.impl.EFactoryImpl;

import org.eclipse.emf.ecore.plugin.EcorePlugin;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model <b>Factory</b>.
 * <!-- end-user-doc -->
 * @generated
 */
public class NetflixFactoryImpl extends EFactoryImpl implements NetflixFactory {
	/**
	 * Creates the default factory implementation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public static NetflixFactory init() {
		try {
			NetflixFactory theNetflixFactory = (NetflixFactory)EPackage.Registry.INSTANCE.getEFactory(NetflixPackage.eNS_URI);
			if (theNetflixFactory != null) {
				return theNetflixFactory;
			}
		}
		catch (Exception exception) {
			EcorePlugin.INSTANCE.log(exception);
		}
		return new NetflixFactoryImpl();
	}

	/**
	 * Creates an instance of the factory.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public NetflixFactoryImpl() {
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public EObject create(EClass eClass) {
		switch (eClass.getClassifierID()) {
			case NetflixPackage.MOVIE: return createMovie();
			case NetflixPackage.TV_SERIE: return createTVSerie();
			case NetflixPackage.MUSIC: return createMusic();
			case NetflixPackage.DVD: return createDVD();
			case NetflixPackage.BLUE_RAY: return createBlueRay();
			case NetflixPackage.DISTRIBUTOR: return createDistributor();
			case NetflixPackage.IN_HOUSE: return createInHouse();
			case NetflixPackage.SUBSCRIPTION_MANAGEMENT: return createSubscriptionManagement();
			case NetflixPackage.ACCOUT: return createAccout();
			case NetflixPackage.PROFILE: return createProfile();
			case NetflixPackage.FAVORITE_QUEUE: return createFavoriteQueue();
			case NetflixPackage.FRIEND_LIST: return createFriendList();
			case NetflixPackage.REVIEW: return createReview();
			case NetflixPackage.RECOMMENDATION: return createRecommendation();
			case NetflixPackage.STREAM_SERVICE: return createStreamService();
			case NetflixPackage.DEVICE: return createDevice();
			case NetflixPackage.STREAMING_LIBRARY: return createStreamingLibrary();
			case NetflixPackage.NETFLIX_SERVICE: return createNetflixService();
			default:
				throw new IllegalArgumentException("The class '" + eClass.getName() + "' is not a valid classifier");
		}
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public Movie createMovie() {
		MovieImpl movie = new MovieImpl();
		return movie;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public TVSerie createTVSerie() {
		TVSerieImpl tvSerie = new TVSerieImpl();
		return tvSerie;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public Music createMusic() {
		MusicImpl music = new MusicImpl();
		return music;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public DVD createDVD() {
		DVDImpl dvd = new DVDImpl();
		return dvd;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public BlueRay createBlueRay() {
		BlueRayImpl blueRay = new BlueRayImpl();
		return blueRay;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public Distributor createDistributor() {
		DistributorImpl distributor = new DistributorImpl();
		return distributor;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public InHouse createInHouse() {
		InHouseImpl inHouse = new InHouseImpl();
		return inHouse;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public SubscriptionManagement createSubscriptionManagement() {
		SubscriptionManagementImpl subscriptionManagement = new SubscriptionManagementImpl();
		return subscriptionManagement;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public Accout createAccout() {
		AccoutImpl accout = new AccoutImpl();
		return accout;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public Profile createProfile() {
		ProfileImpl profile = new ProfileImpl();
		return profile;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public FavoriteQueue createFavoriteQueue() {
		FavoriteQueueImpl favoriteQueue = new FavoriteQueueImpl();
		return favoriteQueue;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public FriendList createFriendList() {
		FriendListImpl friendList = new FriendListImpl();
		return friendList;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public Review createReview() {
		ReviewImpl review = new ReviewImpl();
		return review;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public Recommendation createRecommendation() {
		RecommendationImpl recommendation = new RecommendationImpl();
		return recommendation;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public StreamService createStreamService() {
		StreamServiceImpl streamService = new StreamServiceImpl();
		return streamService;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public Device createDevice() {
		DeviceImpl device = new DeviceImpl();
		return device;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public StreamingLibrary createStreamingLibrary() {
		StreamingLibraryImpl streamingLibrary = new StreamingLibraryImpl();
		return streamingLibrary;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public NetflixService createNetflixService() {
		NetflixServiceImpl netflixService = new NetflixServiceImpl();
		return netflixService;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public NetflixPackage getNetflixPackage() {
		return (NetflixPackage)getEPackage();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @deprecated
	 * @generated
	 */
	@Deprecated
	public static NetflixPackage getPackage() {
		return NetflixPackage.eINSTANCE;
	}

} //NetflixFactoryImpl
