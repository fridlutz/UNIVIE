package at.ac.swa.ase2014.a0123456.task1.application.view;

import java.awt.BorderLayout;
import java.awt.FlowLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.JTextField;
import javax.swing.table.DefaultTableModel;

import at.ac.swa.ase2014.a0123456.task1.application.controller.StreamingLibraryController;
import at.ac.univie.swa.ase2014.a0123456.task1.model.netflix.Media;
import at.ac.univie.swa.ase2014.a0123456.task1.model.netflix.Movie;
import at.ac.univie.swa.ase2014.a0123456.task1.model.netflix.NetflixFactory;
import at.ac.univie.swa.ase2014.a0123456.task1.model.netflix.StreamingLibrary;

public class MediaManagementView extends JFrame implements ActionListener{

	private JTable table;
	private String[] columnNames = {"Name", "Length"};
	private DefaultTableModel tableModel = new DefaultTableModel(null,columnNames);

	private JTextField movieName = new JTextField();
	private JTextField length = new JTextField();
	
	private Object[] message = {
		    "Movie name:", movieName,
		    "Length:", length
		};
	
	private JButton newMovieBtn = new JButton("Add");
	private JButton removeMovieBtn = new JButton("Remove");
	private JButton updateMovieBtn = new JButton("Update");
	
	private StreamingLibraryController controller = new StreamingLibraryController();
	
	public MediaManagementView(StreamingLibrary streamingLibrary){
		
		controller.setStreamingLibrary(streamingLibrary);
		
		this.setTitle("Media Management");

		this.setLayout(new BorderLayout());
		//2. Optional: What happens when the frame closes?
		this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		
		populateTable();
		
		table = new JTable(tableModel);
		this.add(new JScrollPane(table),BorderLayout.CENTER);
		
		JPanel panel = new JPanel(new FlowLayout());
		
		panel.add(newMovieBtn);
		newMovieBtn.addActionListener(this);
		panel.add(updateMovieBtn);
		updateMovieBtn.addActionListener(this);
		panel.add(removeMovieBtn);
		removeMovieBtn.addActionListener(this);
		
		this.add(panel, BorderLayout.SOUTH);
		
		this.setSize(800,600);
		//4. Size the frame.
		this.pack();

		//5. Show it.
		this.setVisible(true);
	}
	
	private void populateTable(){
		tableModel.setRowCount(0);
		for(Media media : controller.getMedias()){
			tableModel.addRow(new Object[]{media.getName(), media.getLength()});
		}
		
	}

	@Override
	public void actionPerformed(ActionEvent arg0) {
		this.movieName.setText("");
		this.length.setText("");
		
		if(newMovieBtn == arg0.getSource()){
			int option = JOptionPane.showConfirmDialog(null, message, "New movie", JOptionPane.OK_CANCEL_OPTION);
			if (option == JOptionPane.OK_OPTION) {
			    Movie movie = NetflixFactory.eINSTANCE.createMovie();
			    movie.setName(movieName.getText());
			    movie.setLength(length.getText());
			    controller.addMedia(movie);
			}
			return;
		}
		if(table.getSelectedRow() == -1){
			JOptionPane.showConfirmDialog(null, new JLabel("No row selected"), "Error", JOptionPane.CANCEL_OPTION);
			return;
		}
		
		if(removeMovieBtn == arg0.getSource()){
			int index = table.getSelectedRow();
			controller.removeMedia(controller.getMedias().get(index));
		}else if(updateMovieBtn == arg0.getSource()){
			this.movieName.setText((String)tableModel.getValueAt(table.getSelectedRow(), 0));
			this.length.setText((String) tableModel.getValueAt(table.getSelectedRow(), 1));
			int option = JOptionPane.showConfirmDialog(null, message, "Update movie", JOptionPane.OK_CANCEL_OPTION);
			int index = table.getSelectedRow();
			controller.removeMedia(controller.getMedias().get(index));
			if (option == JOptionPane.OK_OPTION) {
			    Movie movie = NetflixFactory.eINSTANCE.createMovie();
			    movie.setName(movieName.getText());
			    movie.setLength(length.getText());
			    controller.addMedia(movie);
			}
		}
		populateTable();
	}
}
