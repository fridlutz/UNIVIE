/**
 */
package at.ac.univie.swa.ase2014.a0123456.task1.model.netflix.impl;

import at.ac.univie.swa.ase2014.a0123456.task1.model.netflix.Accout;
import at.ac.univie.swa.ase2014.a0123456.task1.model.netflix.BlueRay;
import at.ac.univie.swa.ase2014.a0123456.task1.model.netflix.Device;
import at.ac.univie.swa.ase2014.a0123456.task1.model.netflix.Distributor;
import at.ac.univie.swa.ase2014.a0123456.task1.model.netflix.FavoriteQueue;
import at.ac.univie.swa.ase2014.a0123456.task1.model.netflix.FriendList;
import at.ac.univie.swa.ase2014.a0123456.task1.model.netflix.InHouse;
import at.ac.univie.swa.ase2014.a0123456.task1.model.netflix.LicenseHolder;
import at.ac.univie.swa.ase2014.a0123456.task1.model.netflix.Media;
import at.ac.univie.swa.ase2014.a0123456.task1.model.netflix.Movie;
import at.ac.univie.swa.ase2014.a0123456.task1.model.netflix.Music;
import at.ac.univie.swa.ase2014.a0123456.task1.model.netflix.NetflixFactory;
import at.ac.univie.swa.ase2014.a0123456.task1.model.netflix.NetflixPackage;
import at.ac.univie.swa.ase2014.a0123456.task1.model.netflix.NetflixService;
import at.ac.univie.swa.ase2014.a0123456.task1.model.netflix.Profile;
import at.ac.univie.swa.ase2014.a0123456.task1.model.netflix.Recommendation;
import at.ac.univie.swa.ase2014.a0123456.task1.model.netflix.RentalMedia;
import at.ac.univie.swa.ase2014.a0123456.task1.model.netflix.Review;
import at.ac.univie.swa.ase2014.a0123456.task1.model.netflix.StreamService;
import at.ac.univie.swa.ase2014.a0123456.task1.model.netflix.StreamingLibrary;
import at.ac.univie.swa.ase2014.a0123456.task1.model.netflix.StreamingMedia;
import at.ac.univie.swa.ase2014.a0123456.task1.model.netflix.SubscriptionManagement;
import at.ac.univie.swa.ase2014.a0123456.task1.model.netflix.TVSerie;
import at.ac.univie.swa.ase2014.a0123456.task1.model.netflix.util.NetflixValidator;
import org.eclipse.emf.ecore.EAttribute;
import org.eclipse.emf.ecore.EClass;
import org.eclipse.emf.ecore.EPackage;
import org.eclipse.emf.ecore.EReference;
import org.eclipse.emf.ecore.EValidator;
import org.eclipse.emf.ecore.impl.EPackageImpl;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model <b>Package</b>.
 * <!-- end-user-doc -->
 * @generated
 */
public class NetflixPackageImpl extends EPackageImpl implements NetflixPackage {
	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EClass mediaEClass = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EClass streamingMediaEClass = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EClass rentalMediaEClass = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EClass movieEClass = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EClass tvSerieEClass = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EClass musicEClass = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EClass dvdEClass = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EClass blueRayEClass = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EClass licenseHolderEClass = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EClass distributorEClass = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EClass inHouseEClass = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EClass subscriptionManagementEClass = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EClass accoutEClass = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EClass profileEClass = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EClass favoriteQueueEClass = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EClass friendListEClass = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EClass reviewEClass = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EClass recommendationEClass = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EClass streamServiceEClass = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EClass deviceEClass = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EClass streamingLibraryEClass = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EClass netflixServiceEClass = null;

	/**
	 * Creates an instance of the model <b>Package</b>, registered with
	 * {@link org.eclipse.emf.ecore.EPackage.Registry EPackage.Registry} by the package
	 * package URI value.
	 * <p>Note: the correct way to create the package is via the static
	 * factory method {@link #init init()}, which also performs
	 * initialization of the package, or returns the registered package,
	 * if one already exists.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see org.eclipse.emf.ecore.EPackage.Registry
	 * @see at.ac.univie.swa.ase2014.a0123456.task1.model.netflix.NetflixPackage#eNS_URI
	 * @see #init()
	 * @generated
	 */
	private NetflixPackageImpl() {
		super(eNS_URI, NetflixFactory.eINSTANCE);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private static boolean isInited = false;

	/**
	 * Creates, registers, and initializes the <b>Package</b> for this model, and for any others upon which it depends.
	 * 
	 * <p>This method is used to initialize {@link NetflixPackage#eINSTANCE} when that field is accessed.
	 * Clients should not invoke it directly. Instead, they should simply access that field to obtain the package.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #eNS_URI
	 * @see #createPackageContents()
	 * @see #initializePackageContents()
	 * @generated
	 */
	public static NetflixPackage init() {
		if (isInited) return (NetflixPackage)EPackage.Registry.INSTANCE.getEPackage(NetflixPackage.eNS_URI);

		// Obtain or create and register package
		NetflixPackageImpl theNetflixPackage = (NetflixPackageImpl)(EPackage.Registry.INSTANCE.get(eNS_URI) instanceof NetflixPackageImpl ? EPackage.Registry.INSTANCE.get(eNS_URI) : new NetflixPackageImpl());

		isInited = true;

		// Create package meta-data objects
		theNetflixPackage.createPackageContents();

		// Initialize created meta-data
		theNetflixPackage.initializePackageContents();

		// Register package validator
		EValidator.Registry.INSTANCE.put
			(theNetflixPackage, 
			 new EValidator.Descriptor() {
				 public EValidator getEValidator() {
					 return NetflixValidator.INSTANCE;
				 }
			 });

		// Mark meta-data to indicate it can't be changed
		theNetflixPackage.freeze();

  
		// Update the registry and return the package
		EPackage.Registry.INSTANCE.put(NetflixPackage.eNS_URI, theNetflixPackage);
		return theNetflixPackage;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EClass getMedia() {
		return mediaEClass;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getMedia_Name() {
		return (EAttribute)mediaEClass.getEStructuralFeatures().get(0);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getMedia_Length() {
		return (EAttribute)mediaEClass.getEStructuralFeatures().get(1);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EClass getStreamingMedia() {
		return streamingMediaEClass;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EClass getRentalMedia() {
		return rentalMediaEClass;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EClass getMovie() {
		return movieEClass;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EClass getTVSerie() {
		return tvSerieEClass;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EClass getMusic() {
		return musicEClass;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EClass getDVD() {
		return dvdEClass;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EClass getBlueRay() {
		return blueRayEClass;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EClass getLicenseHolder() {
		return licenseHolderEClass;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EReference getLicenseHolder_Medien() {
		return (EReference)licenseHolderEClass.getEStructuralFeatures().get(0);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EClass getDistributor() {
		return distributorEClass;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EClass getInHouse() {
		return inHouseEClass;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EClass getSubscriptionManagement() {
		return subscriptionManagementEClass;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EReference getSubscriptionManagement_Accounts() {
		return (EReference)subscriptionManagementEClass.getEStructuralFeatures().get(0);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EClass getAccout() {
		return accoutEClass;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EReference getAccout_Profiles() {
		return (EReference)accoutEClass.getEStructuralFeatures().get(0);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EReference getAccout_Devices() {
		return (EReference)accoutEClass.getEStructuralFeatures().get(1);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getAccout_Email() {
		return (EAttribute)accoutEClass.getEStructuralFeatures().get(2);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getAccout_Pwd() {
		return (EAttribute)accoutEClass.getEStructuralFeatures().get(3);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EReference getAccout_RentedMedias() {
		return (EReference)accoutEClass.getEStructuralFeatures().get(4);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getAccout_Country() {
		return (EAttribute)accoutEClass.getEStructuralFeatures().get(5);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EClass getProfile() {
		return profileEClass;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EReference getProfile_Queue() {
		return (EReference)profileEClass.getEStructuralFeatures().get(0);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EReference getProfile_FriendList() {
		return (EReference)profileEClass.getEStructuralFeatures().get(1);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EReference getProfile_Reviews() {
		return (EReference)profileEClass.getEStructuralFeatures().get(2);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EReference getProfile_Recommendations() {
		return (EReference)profileEClass.getEStructuralFeatures().get(3);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EClass getFavoriteQueue() {
		return favoriteQueueEClass;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EReference getFavoriteQueue_Medien() {
		return (EReference)favoriteQueueEClass.getEStructuralFeatures().get(0);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EClass getFriendList() {
		return friendListEClass;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EReference getFriendList_FriendProfiles() {
		return (EReference)friendListEClass.getEStructuralFeatures().get(0);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EClass getReview() {
		return reviewEClass;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EReference getReview_Media() {
		return (EReference)reviewEClass.getEStructuralFeatures().get(0);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EClass getRecommendation() {
		return recommendationEClass;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EReference getRecommendation_MediaRecommendation() {
		return (EReference)recommendationEClass.getEStructuralFeatures().get(0);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EReference getRecommendation_Media() {
		return (EReference)recommendationEClass.getEStructuralFeatures().get(1);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EClass getStreamService() {
		return streamServiceEClass;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EReference getStreamService_Devices() {
		return (EReference)streamServiceEClass.getEStructuralFeatures().get(0);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EClass getDevice() {
		return deviceEClass;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EClass getStreamingLibrary() {
		return streamingLibraryEClass;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EReference getStreamingLibrary_Medien() {
		return (EReference)streamingLibraryEClass.getEStructuralFeatures().get(0);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EReference getStreamingLibrary_LicenseHolders() {
		return (EReference)streamingLibraryEClass.getEStructuralFeatures().get(1);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EClass getNetflixService() {
		return netflixServiceEClass;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EReference getNetflixService_StreamService() {
		return (EReference)netflixServiceEClass.getEStructuralFeatures().get(0);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EReference getNetflixService_SubscriptionManagement() {
		return (EReference)netflixServiceEClass.getEStructuralFeatures().get(1);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EReference getNetflixService_StreamLibrary() {
		return (EReference)netflixServiceEClass.getEStructuralFeatures().get(2);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public NetflixFactory getNetflixFactory() {
		return (NetflixFactory)getEFactoryInstance();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private boolean isCreated = false;

	/**
	 * Creates the meta-model objects for the package.  This method is
	 * guarded to have no affect on any invocation but its first.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void createPackageContents() {
		if (isCreated) return;
		isCreated = true;

		// Create classes and their features
		mediaEClass = createEClass(MEDIA);
		createEAttribute(mediaEClass, MEDIA__NAME);
		createEAttribute(mediaEClass, MEDIA__LENGTH);

		streamingMediaEClass = createEClass(STREAMING_MEDIA);

		rentalMediaEClass = createEClass(RENTAL_MEDIA);

		movieEClass = createEClass(MOVIE);

		tvSerieEClass = createEClass(TV_SERIE);

		musicEClass = createEClass(MUSIC);

		dvdEClass = createEClass(DVD);

		blueRayEClass = createEClass(BLUE_RAY);

		licenseHolderEClass = createEClass(LICENSE_HOLDER);
		createEReference(licenseHolderEClass, LICENSE_HOLDER__MEDIEN);

		distributorEClass = createEClass(DISTRIBUTOR);

		inHouseEClass = createEClass(IN_HOUSE);

		subscriptionManagementEClass = createEClass(SUBSCRIPTION_MANAGEMENT);
		createEReference(subscriptionManagementEClass, SUBSCRIPTION_MANAGEMENT__ACCOUNTS);

		accoutEClass = createEClass(ACCOUT);
		createEReference(accoutEClass, ACCOUT__PROFILES);
		createEReference(accoutEClass, ACCOUT__DEVICES);
		createEAttribute(accoutEClass, ACCOUT__EMAIL);
		createEAttribute(accoutEClass, ACCOUT__PWD);
		createEReference(accoutEClass, ACCOUT__RENTED_MEDIAS);
		createEAttribute(accoutEClass, ACCOUT__COUNTRY);

		profileEClass = createEClass(PROFILE);
		createEReference(profileEClass, PROFILE__QUEUE);
		createEReference(profileEClass, PROFILE__FRIEND_LIST);
		createEReference(profileEClass, PROFILE__REVIEWS);
		createEReference(profileEClass, PROFILE__RECOMMENDATIONS);

		favoriteQueueEClass = createEClass(FAVORITE_QUEUE);
		createEReference(favoriteQueueEClass, FAVORITE_QUEUE__MEDIEN);

		friendListEClass = createEClass(FRIEND_LIST);
		createEReference(friendListEClass, FRIEND_LIST__FRIEND_PROFILES);

		reviewEClass = createEClass(REVIEW);
		createEReference(reviewEClass, REVIEW__MEDIA);

		recommendationEClass = createEClass(RECOMMENDATION);
		createEReference(recommendationEClass, RECOMMENDATION__MEDIA_RECOMMENDATION);
		createEReference(recommendationEClass, RECOMMENDATION__MEDIA);

		streamServiceEClass = createEClass(STREAM_SERVICE);
		createEReference(streamServiceEClass, STREAM_SERVICE__DEVICES);

		deviceEClass = createEClass(DEVICE);

		streamingLibraryEClass = createEClass(STREAMING_LIBRARY);
		createEReference(streamingLibraryEClass, STREAMING_LIBRARY__MEDIEN);
		createEReference(streamingLibraryEClass, STREAMING_LIBRARY__LICENSE_HOLDERS);

		netflixServiceEClass = createEClass(NETFLIX_SERVICE);
		createEReference(netflixServiceEClass, NETFLIX_SERVICE__STREAM_SERVICE);
		createEReference(netflixServiceEClass, NETFLIX_SERVICE__SUBSCRIPTION_MANAGEMENT);
		createEReference(netflixServiceEClass, NETFLIX_SERVICE__STREAM_LIBRARY);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private boolean isInitialized = false;

	/**
	 * Complete the initialization of the package and its meta-model.  This
	 * method is guarded to have no affect on any invocation but its first.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void initializePackageContents() {
		if (isInitialized) return;
		isInitialized = true;

		// Initialize package
		setName(eNAME);
		setNsPrefix(eNS_PREFIX);
		setNsURI(eNS_URI);

		// Create type parameters

		// Set bounds for type parameters

		// Add supertypes to classes
		streamingMediaEClass.getESuperTypes().add(this.getMedia());
		rentalMediaEClass.getESuperTypes().add(this.getMedia());
		movieEClass.getESuperTypes().add(this.getStreamingMedia());
		tvSerieEClass.getESuperTypes().add(this.getStreamingMedia());
		musicEClass.getESuperTypes().add(this.getStreamingMedia());
		dvdEClass.getESuperTypes().add(this.getRentalMedia());
		blueRayEClass.getESuperTypes().add(this.getRentalMedia());
		distributorEClass.getESuperTypes().add(this.getLicenseHolder());
		inHouseEClass.getESuperTypes().add(this.getLicenseHolder());

		// Initialize classes, features, and operations; add parameters
		initEClass(mediaEClass, Media.class, "Media", IS_ABSTRACT, !IS_INTERFACE, IS_GENERATED_INSTANCE_CLASS);
		initEAttribute(getMedia_Name(), ecorePackage.getEString(), "name", null, 0, 1, Media.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEAttribute(getMedia_Length(), ecorePackage.getEString(), "length", null, 0, 1, Media.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);

		initEClass(streamingMediaEClass, StreamingMedia.class, "StreamingMedia", IS_ABSTRACT, !IS_INTERFACE, IS_GENERATED_INSTANCE_CLASS);

		initEClass(rentalMediaEClass, RentalMedia.class, "RentalMedia", IS_ABSTRACT, !IS_INTERFACE, IS_GENERATED_INSTANCE_CLASS);

		initEClass(movieEClass, Movie.class, "Movie", !IS_ABSTRACT, !IS_INTERFACE, IS_GENERATED_INSTANCE_CLASS);

		initEClass(tvSerieEClass, TVSerie.class, "TVSerie", !IS_ABSTRACT, !IS_INTERFACE, IS_GENERATED_INSTANCE_CLASS);

		initEClass(musicEClass, Music.class, "Music", !IS_ABSTRACT, !IS_INTERFACE, IS_GENERATED_INSTANCE_CLASS);

		initEClass(dvdEClass, at.ac.univie.swa.ase2014.a0123456.task1.model.netflix.DVD.class, "DVD", !IS_ABSTRACT, !IS_INTERFACE, IS_GENERATED_INSTANCE_CLASS);

		initEClass(blueRayEClass, BlueRay.class, "BlueRay", !IS_ABSTRACT, !IS_INTERFACE, IS_GENERATED_INSTANCE_CLASS);

		initEClass(licenseHolderEClass, LicenseHolder.class, "LicenseHolder", IS_ABSTRACT, !IS_INTERFACE, IS_GENERATED_INSTANCE_CLASS);
		initEReference(getLicenseHolder_Medien(), this.getMedia(), null, "medien", null, 0, -1, LicenseHolder.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_COMPOSITE, IS_RESOLVE_PROXIES, !IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);

		initEClass(distributorEClass, Distributor.class, "Distributor", !IS_ABSTRACT, !IS_INTERFACE, IS_GENERATED_INSTANCE_CLASS);

		initEClass(inHouseEClass, InHouse.class, "InHouse", !IS_ABSTRACT, !IS_INTERFACE, IS_GENERATED_INSTANCE_CLASS);

		initEClass(subscriptionManagementEClass, SubscriptionManagement.class, "SubscriptionManagement", !IS_ABSTRACT, !IS_INTERFACE, IS_GENERATED_INSTANCE_CLASS);
		initEReference(getSubscriptionManagement_Accounts(), this.getAccout(), null, "accounts", null, 0, -1, SubscriptionManagement.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, IS_COMPOSITE, !IS_RESOLVE_PROXIES, !IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);

		initEClass(accoutEClass, Accout.class, "Accout", !IS_ABSTRACT, !IS_INTERFACE, IS_GENERATED_INSTANCE_CLASS);
		initEReference(getAccout_Profiles(), this.getProfile(), null, "profiles", null, 0, -1, Accout.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, IS_COMPOSITE, !IS_RESOLVE_PROXIES, !IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEReference(getAccout_Devices(), this.getDevice(), null, "devices", null, 0, -1, Accout.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_COMPOSITE, IS_RESOLVE_PROXIES, !IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEAttribute(getAccout_Email(), ecorePackage.getEString(), "email", null, 0, 1, Accout.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEAttribute(getAccout_Pwd(), ecorePackage.getEString(), "pwd", null, 0, 1, Accout.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEReference(getAccout_RentedMedias(), this.getMedia(), null, "rentedMedias", null, 0, -1, Accout.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_COMPOSITE, IS_RESOLVE_PROXIES, !IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEAttribute(getAccout_Country(), ecorePackage.getEString(), "country", null, 0, 1, Accout.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);

		initEClass(profileEClass, Profile.class, "Profile", !IS_ABSTRACT, !IS_INTERFACE, IS_GENERATED_INSTANCE_CLASS);
		initEReference(getProfile_Queue(), this.getFavoriteQueue(), null, "queue", null, 1, 1, Profile.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, IS_COMPOSITE, !IS_RESOLVE_PROXIES, !IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEReference(getProfile_FriendList(), this.getFriendList(), null, "friendList", null, 1, 1, Profile.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, IS_COMPOSITE, !IS_RESOLVE_PROXIES, !IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEReference(getProfile_Reviews(), this.getReview(), null, "reviews", null, 0, -1, Profile.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, IS_COMPOSITE, !IS_RESOLVE_PROXIES, !IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEReference(getProfile_Recommendations(), this.getRecommendation(), null, "recommendations", null, 0, -1, Profile.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, IS_COMPOSITE, !IS_RESOLVE_PROXIES, !IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);

		initEClass(favoriteQueueEClass, FavoriteQueue.class, "FavoriteQueue", !IS_ABSTRACT, !IS_INTERFACE, IS_GENERATED_INSTANCE_CLASS);
		initEReference(getFavoriteQueue_Medien(), this.getMedia(), null, "medien", null, 0, -1, FavoriteQueue.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_COMPOSITE, IS_RESOLVE_PROXIES, !IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);

		initEClass(friendListEClass, FriendList.class, "FriendList", !IS_ABSTRACT, !IS_INTERFACE, IS_GENERATED_INSTANCE_CLASS);
		initEReference(getFriendList_FriendProfiles(), this.getProfile(), null, "friendProfiles", null, 0, -1, FriendList.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_COMPOSITE, IS_RESOLVE_PROXIES, !IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);

		initEClass(reviewEClass, Review.class, "Review", !IS_ABSTRACT, !IS_INTERFACE, IS_GENERATED_INSTANCE_CLASS);
		initEReference(getReview_Media(), this.getMedia(), null, "media", null, 1, 1, Review.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_COMPOSITE, IS_RESOLVE_PROXIES, !IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);

		initEClass(recommendationEClass, Recommendation.class, "Recommendation", !IS_ABSTRACT, !IS_INTERFACE, IS_GENERATED_INSTANCE_CLASS);
		initEReference(getRecommendation_MediaRecommendation(), this.getProfile(), null, "mediaRecommendation", null, 1, -1, Recommendation.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_COMPOSITE, IS_RESOLVE_PROXIES, !IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEReference(getRecommendation_Media(), this.getMedia(), null, "media", null, 1, 1, Recommendation.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_COMPOSITE, IS_RESOLVE_PROXIES, !IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);

		initEClass(streamServiceEClass, StreamService.class, "StreamService", !IS_ABSTRACT, !IS_INTERFACE, IS_GENERATED_INSTANCE_CLASS);
		initEReference(getStreamService_Devices(), this.getDevice(), null, "devices", null, 0, -1, StreamService.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, IS_COMPOSITE, !IS_RESOLVE_PROXIES, !IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);

		initEClass(deviceEClass, Device.class, "Device", !IS_ABSTRACT, !IS_INTERFACE, IS_GENERATED_INSTANCE_CLASS);

		initEClass(streamingLibraryEClass, StreamingLibrary.class, "StreamingLibrary", !IS_ABSTRACT, !IS_INTERFACE, IS_GENERATED_INSTANCE_CLASS);
		initEReference(getStreamingLibrary_Medien(), this.getMedia(), null, "medien", null, 0, -1, StreamingLibrary.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, IS_COMPOSITE, !IS_RESOLVE_PROXIES, !IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEReference(getStreamingLibrary_LicenseHolders(), this.getLicenseHolder(), null, "licenseHolders", null, 0, -1, StreamingLibrary.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, IS_COMPOSITE, !IS_RESOLVE_PROXIES, !IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);

		initEClass(netflixServiceEClass, NetflixService.class, "NetflixService", !IS_ABSTRACT, !IS_INTERFACE, IS_GENERATED_INSTANCE_CLASS);
		initEReference(getNetflixService_StreamService(), this.getStreamService(), null, "streamService", null, 1, 1, NetflixService.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, IS_COMPOSITE, !IS_RESOLVE_PROXIES, !IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEReference(getNetflixService_SubscriptionManagement(), this.getSubscriptionManagement(), null, "subscriptionManagement", null, 1, 1, NetflixService.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, IS_COMPOSITE, !IS_RESOLVE_PROXIES, !IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEReference(getNetflixService_StreamLibrary(), this.getStreamingLibrary(), null, "streamLibrary", null, 1, 1, NetflixService.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, IS_COMPOSITE, !IS_RESOLVE_PROXIES, !IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);

		// Create resource
		createResource(eNS_URI);

		// Create annotations
		// http://www.eclipse.org/emf/2002/Ecore
		createEcoreAnnotations();
		// http://www.eclipse.org/emf/2002/Ecore/OCL/Pivot
		createPivotAnnotations();
	}

	/**
	 * Initializes the annotations for <b>http://www.eclipse.org/emf/2002/Ecore</b>.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected void createEcoreAnnotations() {
		String source = "http://www.eclipse.org/emf/2002/Ecore";		
		addAnnotation
		  (this, 
		   source, 
		   new String[] {
			 "invocationDelegates", "http://www.eclipse.org/emf/2002/Ecore/OCL/Pivot",
			 "settingDelegates", "http://www.eclipse.org/emf/2002/Ecore/OCL/Pivot",
			 "validationDelegates", "http://www.eclipse.org/emf/2002/Ecore/OCL/Pivot"
		   });		
		addAnnotation
		  (accoutEClass, 
		   source, 
		   new String[] {
			 "constraints", "mustHaveName"
		   });	
	}

	/**
	 * Initializes the annotations for <b>http://www.eclipse.org/emf/2002/Ecore/OCL/Pivot</b>.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected void createPivotAnnotations() {
		String source = "http://www.eclipse.org/emf/2002/Ecore/OCL/Pivot";				
		addAnnotation
		  (accoutEClass, 
		   source, 
		   new String[] {
			 "mustHaveName", "not email.oclIsUndefined()"
		   });
	}

} //NetflixPackageImpl
