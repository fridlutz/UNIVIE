package at.ac.swa.ase2014.a0123456.task1.application.controller;

import java.util.Iterator;
import java.util.List;

import at.ac.univie.swa.ase2014.a0123456.task1.model.netflix.Media;
import at.ac.univie.swa.ase2014.a0123456.task1.model.netflix.StreamingLibrary;

public class StreamingLibraryController {
	private StreamingLibrary streamingLibrary;
	
	public List<Media> getMedias(){
		return streamingLibrary.getMedien();
	}
	
	public Media getMediaByName(String name){
		for(Media media : getMedias()){
			if(media.getName().equals(name)){
				return media;
			}
		}
		return null;
	}

	public void addMedia(Media media){
		getMedias().add(media);
	}
	public void updateMedia(Media media){
		removeMedia(media);
		addMedia(media);
		
	}
	public void removeMedia(Media media){
		Iterator<Media> iterator = getMedias().iterator();
		for(;iterator.hasNext();){
			Media m = iterator.next();
			if(media.getName().equals(m.getName())){
				iterator.remove();
			}
		}
	}

	public StreamingLibrary getStreamingLibrary() {
		return streamingLibrary;
	}

	public void setStreamingLibrary(StreamingLibrary streamingLibrary) {
		this.streamingLibrary = streamingLibrary;
	}
}
