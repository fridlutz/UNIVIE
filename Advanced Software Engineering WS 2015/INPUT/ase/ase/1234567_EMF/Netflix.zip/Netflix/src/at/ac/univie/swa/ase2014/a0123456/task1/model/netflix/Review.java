/**
 */
package at.ac.univie.swa.ase2014.a0123456.task1.model.netflix;

import org.eclipse.emf.ecore.EObject;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Review</b></em>'.
 * <!-- end-user-doc -->
 *
 * <p>
 * The following features are supported:
 * <ul>
 *   <li>{@link at.ac.univie.swa.ase2014.a0123456.task1.model.netflix.Review#getMedia <em>Media</em>}</li>
 * </ul>
 * </p>
 *
 * @see at.ac.univie.swa.ase2014.a0123456.task1.model.netflix.NetflixPackage#getReview()
 * @model
 * @generated
 */
public interface Review extends EObject {
	/**
	 * Returns the value of the '<em><b>Media</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Media</em>' reference isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Media</em>' reference.
	 * @see #setMedia(Media)
	 * @see at.ac.univie.swa.ase2014.a0123456.task1.model.netflix.NetflixPackage#getReview_Media()
	 * @model required="true"
	 * @generated
	 */
	Media getMedia();

	/**
	 * Sets the value of the '{@link at.ac.univie.swa.ase2014.a0123456.task1.model.netflix.Review#getMedia <em>Media</em>}' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Media</em>' reference.
	 * @see #getMedia()
	 * @generated
	 */
	void setMedia(Media value);

} // Review
