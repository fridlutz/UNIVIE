/**
 */
package netflix;


/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>In House</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see netflix.NetflixPackage#getInHouse()
 * @model
 * @generated
 */
public interface InHouse extends LicenseHolder {
} // InHouse
