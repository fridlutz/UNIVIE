/**
 */
package at.ac.univie.swa.ase2014.a0123456.task1.model.netflix;


/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Rental Media</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see at.ac.univie.swa.ase2014.a0123456.task1.model.netflix.NetflixPackage#getRentalMedia()
 * @model abstract="true"
 * @generated
 */
public interface RentalMedia extends Media {
} // RentalMedia
