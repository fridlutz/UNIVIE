/**
 */
package netflix.impl;

import netflix.NetflixPackage;
import netflix.NetflixService;
import netflix.StreamService;
import netflix.StreamingLibrary;
import netflix.SubscriptionManagement;

import org.eclipse.emf.common.notify.Notification;
import org.eclipse.emf.common.notify.NotificationChain;

import org.eclipse.emf.ecore.EClass;
import org.eclipse.emf.ecore.InternalEObject;

import org.eclipse.emf.ecore.impl.ENotificationImpl;
import org.eclipse.emf.ecore.impl.MinimalEObjectImpl;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>Service</b></em>'.
 * <!-- end-user-doc -->
 * <p>
 * The following features are implemented:
 * <ul>
 *   <li>{@link netflix.impl.NetflixServiceImpl#getStreamService <em>Stream Service</em>}</li>
 *   <li>{@link netflix.impl.NetflixServiceImpl#getSubscriptionManagement <em>Subscription Management</em>}</li>
 *   <li>{@link netflix.impl.NetflixServiceImpl#getStreamLibrary <em>Stream Library</em>}</li>
 * </ul>
 * </p>
 *
 * @generated
 */
public class NetflixServiceImpl extends MinimalEObjectImpl.Container implements NetflixService {
	/**
	 * The cached value of the '{@link #getStreamService() <em>Stream Service</em>}' containment reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getStreamService()
	 * @generated
	 * @ordered
	 */
	protected StreamService streamService;

	/**
	 * The cached value of the '{@link #getSubscriptionManagement() <em>Subscription Management</em>}' containment reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getSubscriptionManagement()
	 * @generated
	 * @ordered
	 */
	protected SubscriptionManagement subscriptionManagement;

	/**
	 * The cached value of the '{@link #getStreamLibrary() <em>Stream Library</em>}' containment reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getStreamLibrary()
	 * @generated
	 * @ordered
	 */
	protected StreamingLibrary streamLibrary;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected NetflixServiceImpl() {
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected EClass eStaticClass() {
		return NetflixPackage.Literals.NETFLIX_SERVICE;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public StreamService getStreamService() {
		return streamService;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public NotificationChain basicSetStreamService(StreamService newStreamService, NotificationChain msgs) {
		StreamService oldStreamService = streamService;
		streamService = newStreamService;
		if (eNotificationRequired()) {
			ENotificationImpl notification = new ENotificationImpl(this, Notification.SET, NetflixPackage.NETFLIX_SERVICE__STREAM_SERVICE, oldStreamService, newStreamService);
			if (msgs == null) msgs = notification; else msgs.add(notification);
		}
		return msgs;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setStreamService(StreamService newStreamService) {
		if (newStreamService != streamService) {
			NotificationChain msgs = null;
			if (streamService != null)
				msgs = ((InternalEObject)streamService).eInverseRemove(this, EOPPOSITE_FEATURE_BASE - NetflixPackage.NETFLIX_SERVICE__STREAM_SERVICE, null, msgs);
			if (newStreamService != null)
				msgs = ((InternalEObject)newStreamService).eInverseAdd(this, EOPPOSITE_FEATURE_BASE - NetflixPackage.NETFLIX_SERVICE__STREAM_SERVICE, null, msgs);
			msgs = basicSetStreamService(newStreamService, msgs);
			if (msgs != null) msgs.dispatch();
		}
		else if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, NetflixPackage.NETFLIX_SERVICE__STREAM_SERVICE, newStreamService, newStreamService));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public SubscriptionManagement getSubscriptionManagement() {
		return subscriptionManagement;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public NotificationChain basicSetSubscriptionManagement(SubscriptionManagement newSubscriptionManagement, NotificationChain msgs) {
		SubscriptionManagement oldSubscriptionManagement = subscriptionManagement;
		subscriptionManagement = newSubscriptionManagement;
		if (eNotificationRequired()) {
			ENotificationImpl notification = new ENotificationImpl(this, Notification.SET, NetflixPackage.NETFLIX_SERVICE__SUBSCRIPTION_MANAGEMENT, oldSubscriptionManagement, newSubscriptionManagement);
			if (msgs == null) msgs = notification; else msgs.add(notification);
		}
		return msgs;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setSubscriptionManagement(SubscriptionManagement newSubscriptionManagement) {
		if (newSubscriptionManagement != subscriptionManagement) {
			NotificationChain msgs = null;
			if (subscriptionManagement != null)
				msgs = ((InternalEObject)subscriptionManagement).eInverseRemove(this, EOPPOSITE_FEATURE_BASE - NetflixPackage.NETFLIX_SERVICE__SUBSCRIPTION_MANAGEMENT, null, msgs);
			if (newSubscriptionManagement != null)
				msgs = ((InternalEObject)newSubscriptionManagement).eInverseAdd(this, EOPPOSITE_FEATURE_BASE - NetflixPackage.NETFLIX_SERVICE__SUBSCRIPTION_MANAGEMENT, null, msgs);
			msgs = basicSetSubscriptionManagement(newSubscriptionManagement, msgs);
			if (msgs != null) msgs.dispatch();
		}
		else if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, NetflixPackage.NETFLIX_SERVICE__SUBSCRIPTION_MANAGEMENT, newSubscriptionManagement, newSubscriptionManagement));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public StreamingLibrary getStreamLibrary() {
		return streamLibrary;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public NotificationChain basicSetStreamLibrary(StreamingLibrary newStreamLibrary, NotificationChain msgs) {
		StreamingLibrary oldStreamLibrary = streamLibrary;
		streamLibrary = newStreamLibrary;
		if (eNotificationRequired()) {
			ENotificationImpl notification = new ENotificationImpl(this, Notification.SET, NetflixPackage.NETFLIX_SERVICE__STREAM_LIBRARY, oldStreamLibrary, newStreamLibrary);
			if (msgs == null) msgs = notification; else msgs.add(notification);
		}
		return msgs;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setStreamLibrary(StreamingLibrary newStreamLibrary) {
		if (newStreamLibrary != streamLibrary) {
			NotificationChain msgs = null;
			if (streamLibrary != null)
				msgs = ((InternalEObject)streamLibrary).eInverseRemove(this, EOPPOSITE_FEATURE_BASE - NetflixPackage.NETFLIX_SERVICE__STREAM_LIBRARY, null, msgs);
			if (newStreamLibrary != null)
				msgs = ((InternalEObject)newStreamLibrary).eInverseAdd(this, EOPPOSITE_FEATURE_BASE - NetflixPackage.NETFLIX_SERVICE__STREAM_LIBRARY, null, msgs);
			msgs = basicSetStreamLibrary(newStreamLibrary, msgs);
			if (msgs != null) msgs.dispatch();
		}
		else if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, NetflixPackage.NETFLIX_SERVICE__STREAM_LIBRARY, newStreamLibrary, newStreamLibrary));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public NotificationChain eInverseRemove(InternalEObject otherEnd, int featureID, NotificationChain msgs) {
		switch (featureID) {
			case NetflixPackage.NETFLIX_SERVICE__STREAM_SERVICE:
				return basicSetStreamService(null, msgs);
			case NetflixPackage.NETFLIX_SERVICE__SUBSCRIPTION_MANAGEMENT:
				return basicSetSubscriptionManagement(null, msgs);
			case NetflixPackage.NETFLIX_SERVICE__STREAM_LIBRARY:
				return basicSetStreamLibrary(null, msgs);
		}
		return super.eInverseRemove(otherEnd, featureID, msgs);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public Object eGet(int featureID, boolean resolve, boolean coreType) {
		switch (featureID) {
			case NetflixPackage.NETFLIX_SERVICE__STREAM_SERVICE:
				return getStreamService();
			case NetflixPackage.NETFLIX_SERVICE__SUBSCRIPTION_MANAGEMENT:
				return getSubscriptionManagement();
			case NetflixPackage.NETFLIX_SERVICE__STREAM_LIBRARY:
				return getStreamLibrary();
		}
		return super.eGet(featureID, resolve, coreType);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void eSet(int featureID, Object newValue) {
		switch (featureID) {
			case NetflixPackage.NETFLIX_SERVICE__STREAM_SERVICE:
				setStreamService((StreamService)newValue);
				return;
			case NetflixPackage.NETFLIX_SERVICE__SUBSCRIPTION_MANAGEMENT:
				setSubscriptionManagement((SubscriptionManagement)newValue);
				return;
			case NetflixPackage.NETFLIX_SERVICE__STREAM_LIBRARY:
				setStreamLibrary((StreamingLibrary)newValue);
				return;
		}
		super.eSet(featureID, newValue);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void eUnset(int featureID) {
		switch (featureID) {
			case NetflixPackage.NETFLIX_SERVICE__STREAM_SERVICE:
				setStreamService((StreamService)null);
				return;
			case NetflixPackage.NETFLIX_SERVICE__SUBSCRIPTION_MANAGEMENT:
				setSubscriptionManagement((SubscriptionManagement)null);
				return;
			case NetflixPackage.NETFLIX_SERVICE__STREAM_LIBRARY:
				setStreamLibrary((StreamingLibrary)null);
				return;
		}
		super.eUnset(featureID);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public boolean eIsSet(int featureID) {
		switch (featureID) {
			case NetflixPackage.NETFLIX_SERVICE__STREAM_SERVICE:
				return streamService != null;
			case NetflixPackage.NETFLIX_SERVICE__SUBSCRIPTION_MANAGEMENT:
				return subscriptionManagement != null;
			case NetflixPackage.NETFLIX_SERVICE__STREAM_LIBRARY:
				return streamLibrary != null;
		}
		return super.eIsSet(featureID);
	}

} //NetflixServiceImpl
