/**
 */
package netflix;


/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Streaming Media</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see netflix.NetflixPackage#getStreamingMedia()
 * @model abstract="true"
 * @generated
 */
public interface StreamingMedia extends Media {
} // StreamingMedia
