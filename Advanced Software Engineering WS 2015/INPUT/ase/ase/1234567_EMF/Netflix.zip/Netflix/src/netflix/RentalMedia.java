/**
 */
package netflix;


/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Rental Media</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see netflix.NetflixPackage#getRentalMedia()
 * @model abstract="true"
 * @generated
 */
public interface RentalMedia extends Media {
} // RentalMedia
