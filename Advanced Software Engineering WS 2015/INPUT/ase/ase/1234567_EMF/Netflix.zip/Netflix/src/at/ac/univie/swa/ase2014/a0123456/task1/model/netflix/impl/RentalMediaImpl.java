/**
 */
package at.ac.univie.swa.ase2014.a0123456.task1.model.netflix.impl;

import at.ac.univie.swa.ase2014.a0123456.task1.model.netflix.NetflixPackage;
import at.ac.univie.swa.ase2014.a0123456.task1.model.netflix.RentalMedia;

import org.eclipse.emf.ecore.EClass;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>Rental Media</b></em>'.
 * <!-- end-user-doc -->
 * <p>
 * </p>
 *
 * @generated
 */
public abstract class RentalMediaImpl extends MediaImpl implements RentalMedia {
	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected RentalMediaImpl() {
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected EClass eStaticClass() {
		return NetflixPackage.Literals.RENTAL_MEDIA;
	}

} //RentalMediaImpl
