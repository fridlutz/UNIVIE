/**
 */
package at.ac.univie.swa.ase2014.a0123456.task1.model.netflix.impl;

import at.ac.univie.swa.ase2014.a0123456.task1.model.netflix.DVD;
import at.ac.univie.swa.ase2014.a0123456.task1.model.netflix.NetflixPackage;

import org.eclipse.emf.ecore.EClass;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>DVD</b></em>'.
 * <!-- end-user-doc -->
 * <p>
 * </p>
 *
 * @generated
 */
public class DVDImpl extends RentalMediaImpl implements DVD {
	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected DVDImpl() {
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected EClass eStaticClass() {
		return NetflixPackage.Literals.DVD;
	}

} //DVDImpl
