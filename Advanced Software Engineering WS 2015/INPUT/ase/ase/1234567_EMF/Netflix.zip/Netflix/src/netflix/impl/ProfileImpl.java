/**
 */
package netflix.impl;

import java.util.Collection;

import netflix.FavoriteQueue;
import netflix.FriendList;
import netflix.NetflixPackage;
import netflix.Profile;
import netflix.Recommendation;
import netflix.Review;

import org.eclipse.emf.common.notify.Notification;
import org.eclipse.emf.common.notify.NotificationChain;

import org.eclipse.emf.common.util.EList;

import org.eclipse.emf.ecore.EClass;
import org.eclipse.emf.ecore.InternalEObject;

import org.eclipse.emf.ecore.impl.ENotificationImpl;
import org.eclipse.emf.ecore.impl.MinimalEObjectImpl;

import org.eclipse.emf.ecore.util.EObjectContainmentEList;
import org.eclipse.emf.ecore.util.InternalEList;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>Profile</b></em>'.
 * <!-- end-user-doc -->
 * <p>
 * The following features are implemented:
 * <ul>
 *   <li>{@link netflix.impl.ProfileImpl#getQueue <em>Queue</em>}</li>
 *   <li>{@link netflix.impl.ProfileImpl#getFriendList <em>Friend List</em>}</li>
 *   <li>{@link netflix.impl.ProfileImpl#getReviews <em>Reviews</em>}</li>
 *   <li>{@link netflix.impl.ProfileImpl#getRecommendations <em>Recommendations</em>}</li>
 * </ul>
 * </p>
 *
 * @generated
 */
public class ProfileImpl extends MinimalEObjectImpl.Container implements Profile {
	/**
	 * The cached value of the '{@link #getQueue() <em>Queue</em>}' containment reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getQueue()
	 * @generated
	 * @ordered
	 */
	protected FavoriteQueue queue;

	/**
	 * The cached value of the '{@link #getFriendList() <em>Friend List</em>}' containment reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getFriendList()
	 * @generated
	 * @ordered
	 */
	protected FriendList friendList;

	/**
	 * The cached value of the '{@link #getReviews() <em>Reviews</em>}' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getReviews()
	 * @generated
	 * @ordered
	 */
	protected EList<Review> reviews;

	/**
	 * The cached value of the '{@link #getRecommendations() <em>Recommendations</em>}' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getRecommendations()
	 * @generated
	 * @ordered
	 */
	protected EList<Recommendation> recommendations;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected ProfileImpl() {
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected EClass eStaticClass() {
		return NetflixPackage.Literals.PROFILE;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public FavoriteQueue getQueue() {
		return queue;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public NotificationChain basicSetQueue(FavoriteQueue newQueue, NotificationChain msgs) {
		FavoriteQueue oldQueue = queue;
		queue = newQueue;
		if (eNotificationRequired()) {
			ENotificationImpl notification = new ENotificationImpl(this, Notification.SET, NetflixPackage.PROFILE__QUEUE, oldQueue, newQueue);
			if (msgs == null) msgs = notification; else msgs.add(notification);
		}
		return msgs;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setQueue(FavoriteQueue newQueue) {
		if (newQueue != queue) {
			NotificationChain msgs = null;
			if (queue != null)
				msgs = ((InternalEObject)queue).eInverseRemove(this, EOPPOSITE_FEATURE_BASE - NetflixPackage.PROFILE__QUEUE, null, msgs);
			if (newQueue != null)
				msgs = ((InternalEObject)newQueue).eInverseAdd(this, EOPPOSITE_FEATURE_BASE - NetflixPackage.PROFILE__QUEUE, null, msgs);
			msgs = basicSetQueue(newQueue, msgs);
			if (msgs != null) msgs.dispatch();
		}
		else if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, NetflixPackage.PROFILE__QUEUE, newQueue, newQueue));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public FriendList getFriendList() {
		return friendList;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public NotificationChain basicSetFriendList(FriendList newFriendList, NotificationChain msgs) {
		FriendList oldFriendList = friendList;
		friendList = newFriendList;
		if (eNotificationRequired()) {
			ENotificationImpl notification = new ENotificationImpl(this, Notification.SET, NetflixPackage.PROFILE__FRIEND_LIST, oldFriendList, newFriendList);
			if (msgs == null) msgs = notification; else msgs.add(notification);
		}
		return msgs;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setFriendList(FriendList newFriendList) {
		if (newFriendList != friendList) {
			NotificationChain msgs = null;
			if (friendList != null)
				msgs = ((InternalEObject)friendList).eInverseRemove(this, EOPPOSITE_FEATURE_BASE - NetflixPackage.PROFILE__FRIEND_LIST, null, msgs);
			if (newFriendList != null)
				msgs = ((InternalEObject)newFriendList).eInverseAdd(this, EOPPOSITE_FEATURE_BASE - NetflixPackage.PROFILE__FRIEND_LIST, null, msgs);
			msgs = basicSetFriendList(newFriendList, msgs);
			if (msgs != null) msgs.dispatch();
		}
		else if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, NetflixPackage.PROFILE__FRIEND_LIST, newFriendList, newFriendList));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EList<Review> getReviews() {
		if (reviews == null) {
			reviews = new EObjectContainmentEList<Review>(Review.class, this, NetflixPackage.PROFILE__REVIEWS);
		}
		return reviews;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EList<Recommendation> getRecommendations() {
		if (recommendations == null) {
			recommendations = new EObjectContainmentEList<Recommendation>(Recommendation.class, this, NetflixPackage.PROFILE__RECOMMENDATIONS);
		}
		return recommendations;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public NotificationChain eInverseRemove(InternalEObject otherEnd, int featureID, NotificationChain msgs) {
		switch (featureID) {
			case NetflixPackage.PROFILE__QUEUE:
				return basicSetQueue(null, msgs);
			case NetflixPackage.PROFILE__FRIEND_LIST:
				return basicSetFriendList(null, msgs);
			case NetflixPackage.PROFILE__REVIEWS:
				return ((InternalEList<?>)getReviews()).basicRemove(otherEnd, msgs);
			case NetflixPackage.PROFILE__RECOMMENDATIONS:
				return ((InternalEList<?>)getRecommendations()).basicRemove(otherEnd, msgs);
		}
		return super.eInverseRemove(otherEnd, featureID, msgs);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public Object eGet(int featureID, boolean resolve, boolean coreType) {
		switch (featureID) {
			case NetflixPackage.PROFILE__QUEUE:
				return getQueue();
			case NetflixPackage.PROFILE__FRIEND_LIST:
				return getFriendList();
			case NetflixPackage.PROFILE__REVIEWS:
				return getReviews();
			case NetflixPackage.PROFILE__RECOMMENDATIONS:
				return getRecommendations();
		}
		return super.eGet(featureID, resolve, coreType);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@SuppressWarnings("unchecked")
	@Override
	public void eSet(int featureID, Object newValue) {
		switch (featureID) {
			case NetflixPackage.PROFILE__QUEUE:
				setQueue((FavoriteQueue)newValue);
				return;
			case NetflixPackage.PROFILE__FRIEND_LIST:
				setFriendList((FriendList)newValue);
				return;
			case NetflixPackage.PROFILE__REVIEWS:
				getReviews().clear();
				getReviews().addAll((Collection<? extends Review>)newValue);
				return;
			case NetflixPackage.PROFILE__RECOMMENDATIONS:
				getRecommendations().clear();
				getRecommendations().addAll((Collection<? extends Recommendation>)newValue);
				return;
		}
		super.eSet(featureID, newValue);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void eUnset(int featureID) {
		switch (featureID) {
			case NetflixPackage.PROFILE__QUEUE:
				setQueue((FavoriteQueue)null);
				return;
			case NetflixPackage.PROFILE__FRIEND_LIST:
				setFriendList((FriendList)null);
				return;
			case NetflixPackage.PROFILE__REVIEWS:
				getReviews().clear();
				return;
			case NetflixPackage.PROFILE__RECOMMENDATIONS:
				getRecommendations().clear();
				return;
		}
		super.eUnset(featureID);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public boolean eIsSet(int featureID) {
		switch (featureID) {
			case NetflixPackage.PROFILE__QUEUE:
				return queue != null;
			case NetflixPackage.PROFILE__FRIEND_LIST:
				return friendList != null;
			case NetflixPackage.PROFILE__REVIEWS:
				return reviews != null && !reviews.isEmpty();
			case NetflixPackage.PROFILE__RECOMMENDATIONS:
				return recommendations != null && !recommendations.isEmpty();
		}
		return super.eIsSet(featureID);
	}

} //ProfileImpl
