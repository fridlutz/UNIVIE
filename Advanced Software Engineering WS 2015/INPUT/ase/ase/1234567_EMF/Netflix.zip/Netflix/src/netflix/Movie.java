/**
 */
package netflix;


/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Movie</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see netflix.NetflixPackage#getMovie()
 * @model
 * @generated
 */
public interface Movie extends StreamingMedia {
} // Movie
