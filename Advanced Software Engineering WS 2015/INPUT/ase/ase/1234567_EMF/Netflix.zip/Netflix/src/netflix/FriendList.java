/**
 */
package netflix;

import org.eclipse.emf.common.util.EList;

import org.eclipse.emf.ecore.EObject;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Friend List</b></em>'.
 * <!-- end-user-doc -->
 *
 * <p>
 * The following features are supported:
 * <ul>
 *   <li>{@link netflix.FriendList#getFriendProfiles <em>Friend Profiles</em>}</li>
 * </ul>
 * </p>
 *
 * @see netflix.NetflixPackage#getFriendList()
 * @model
 * @generated
 */
public interface FriendList extends EObject {
	/**
	 * Returns the value of the '<em><b>Friend Profiles</b></em>' reference list.
	 * The list contents are of type {@link netflix.Profile}.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Friend Profiles</em>' reference list isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Friend Profiles</em>' reference list.
	 * @see netflix.NetflixPackage#getFriendList_FriendProfiles()
	 * @model
	 * @generated
	 */
	EList<Profile> getFriendProfiles();

} // FriendList
