/**
 */
package netflix;

import org.eclipse.emf.ecore.EAttribute;
import org.eclipse.emf.ecore.EClass;
import org.eclipse.emf.ecore.EPackage;
import org.eclipse.emf.ecore.EReference;

/**
 * <!-- begin-user-doc -->
 * The <b>Package</b> for the model.
 * It contains accessors for the meta objects to represent
 * <ul>
 *   <li>each class,</li>
 *   <li>each feature of each class,</li>
 *   <li>each operation of each class,</li>
 *   <li>each enum,</li>
 *   <li>and each data type</li>
 * </ul>
 * <!-- end-user-doc -->
 * @see netflix.NetflixFactory
 * @model kind="package"
 *        annotation="http://www.eclipse.org/emf/2002/Ecore invocationDelegates='http://www.eclipse.org/emf/2002/Ecore/OCL/Pivot' settingDelegates='http://www.eclipse.org/emf/2002/Ecore/OCL/Pivot' validationDelegates='http://www.eclipse.org/emf/2002/Ecore/OCL/Pivot'"
 * @generated
 */
public interface NetflixPackage extends EPackage {
	/**
	 * The package name.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	String eNAME = "netflix";

	/**
	 * The package namespace URI.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	String eNS_URI = "http://netflix/1.0";

	/**
	 * The package namespace name.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	String eNS_PREFIX = "netflix";

	/**
	 * The singleton instance of the package.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	NetflixPackage eINSTANCE = netflix.impl.NetflixPackageImpl.init();

	/**
	 * The meta object id for the '{@link netflix.impl.MediaImpl <em>Media</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see netflix.impl.MediaImpl
	 * @see netflix.impl.NetflixPackageImpl#getMedia()
	 * @generated
	 */
	int MEDIA = 0;

	/**
	 * The feature id for the '<em><b>Name</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int MEDIA__NAME = 0;

	/**
	 * The feature id for the '<em><b>Length</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int MEDIA__LENGTH = 1;

	/**
	 * The number of structural features of the '<em>Media</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int MEDIA_FEATURE_COUNT = 2;

	/**
	 * The number of operations of the '<em>Media</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int MEDIA_OPERATION_COUNT = 0;

	/**
	 * The meta object id for the '{@link netflix.impl.StreamingMediaImpl <em>Streaming Media</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see netflix.impl.StreamingMediaImpl
	 * @see netflix.impl.NetflixPackageImpl#getStreamingMedia()
	 * @generated
	 */
	int STREAMING_MEDIA = 1;

	/**
	 * The feature id for the '<em><b>Name</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int STREAMING_MEDIA__NAME = MEDIA__NAME;

	/**
	 * The feature id for the '<em><b>Length</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int STREAMING_MEDIA__LENGTH = MEDIA__LENGTH;

	/**
	 * The number of structural features of the '<em>Streaming Media</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int STREAMING_MEDIA_FEATURE_COUNT = MEDIA_FEATURE_COUNT + 0;

	/**
	 * The number of operations of the '<em>Streaming Media</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int STREAMING_MEDIA_OPERATION_COUNT = MEDIA_OPERATION_COUNT + 0;

	/**
	 * The meta object id for the '{@link netflix.impl.RentalMediaImpl <em>Rental Media</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see netflix.impl.RentalMediaImpl
	 * @see netflix.impl.NetflixPackageImpl#getRentalMedia()
	 * @generated
	 */
	int RENTAL_MEDIA = 2;

	/**
	 * The feature id for the '<em><b>Name</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int RENTAL_MEDIA__NAME = MEDIA__NAME;

	/**
	 * The feature id for the '<em><b>Length</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int RENTAL_MEDIA__LENGTH = MEDIA__LENGTH;

	/**
	 * The number of structural features of the '<em>Rental Media</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int RENTAL_MEDIA_FEATURE_COUNT = MEDIA_FEATURE_COUNT + 0;

	/**
	 * The number of operations of the '<em>Rental Media</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int RENTAL_MEDIA_OPERATION_COUNT = MEDIA_OPERATION_COUNT + 0;

	/**
	 * The meta object id for the '{@link netflix.impl.MovieImpl <em>Movie</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see netflix.impl.MovieImpl
	 * @see netflix.impl.NetflixPackageImpl#getMovie()
	 * @generated
	 */
	int MOVIE = 3;

	/**
	 * The feature id for the '<em><b>Name</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int MOVIE__NAME = STREAMING_MEDIA__NAME;

	/**
	 * The feature id for the '<em><b>Length</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int MOVIE__LENGTH = STREAMING_MEDIA__LENGTH;

	/**
	 * The number of structural features of the '<em>Movie</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int MOVIE_FEATURE_COUNT = STREAMING_MEDIA_FEATURE_COUNT + 0;

	/**
	 * The number of operations of the '<em>Movie</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int MOVIE_OPERATION_COUNT = STREAMING_MEDIA_OPERATION_COUNT + 0;

	/**
	 * The meta object id for the '{@link netflix.impl.TVSerieImpl <em>TV Serie</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see netflix.impl.TVSerieImpl
	 * @see netflix.impl.NetflixPackageImpl#getTVSerie()
	 * @generated
	 */
	int TV_SERIE = 4;

	/**
	 * The feature id for the '<em><b>Name</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int TV_SERIE__NAME = STREAMING_MEDIA__NAME;

	/**
	 * The feature id for the '<em><b>Length</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int TV_SERIE__LENGTH = STREAMING_MEDIA__LENGTH;

	/**
	 * The number of structural features of the '<em>TV Serie</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int TV_SERIE_FEATURE_COUNT = STREAMING_MEDIA_FEATURE_COUNT + 0;

	/**
	 * The number of operations of the '<em>TV Serie</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int TV_SERIE_OPERATION_COUNT = STREAMING_MEDIA_OPERATION_COUNT + 0;

	/**
	 * The meta object id for the '{@link netflix.impl.MusicImpl <em>Music</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see netflix.impl.MusicImpl
	 * @see netflix.impl.NetflixPackageImpl#getMusic()
	 * @generated
	 */
	int MUSIC = 5;

	/**
	 * The feature id for the '<em><b>Name</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int MUSIC__NAME = STREAMING_MEDIA__NAME;

	/**
	 * The feature id for the '<em><b>Length</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int MUSIC__LENGTH = STREAMING_MEDIA__LENGTH;

	/**
	 * The number of structural features of the '<em>Music</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int MUSIC_FEATURE_COUNT = STREAMING_MEDIA_FEATURE_COUNT + 0;

	/**
	 * The number of operations of the '<em>Music</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int MUSIC_OPERATION_COUNT = STREAMING_MEDIA_OPERATION_COUNT + 0;

	/**
	 * The meta object id for the '{@link netflix.impl.DVDImpl <em>DVD</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see netflix.impl.DVDImpl
	 * @see netflix.impl.NetflixPackageImpl#getDVD()
	 * @generated
	 */
	int DVD = 6;

	/**
	 * The feature id for the '<em><b>Name</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int DVD__NAME = RENTAL_MEDIA__NAME;

	/**
	 * The feature id for the '<em><b>Length</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int DVD__LENGTH = RENTAL_MEDIA__LENGTH;

	/**
	 * The number of structural features of the '<em>DVD</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int DVD_FEATURE_COUNT = RENTAL_MEDIA_FEATURE_COUNT + 0;

	/**
	 * The number of operations of the '<em>DVD</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int DVD_OPERATION_COUNT = RENTAL_MEDIA_OPERATION_COUNT + 0;

	/**
	 * The meta object id for the '{@link netflix.impl.BlueRayImpl <em>Blue Ray</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see netflix.impl.BlueRayImpl
	 * @see netflix.impl.NetflixPackageImpl#getBlueRay()
	 * @generated
	 */
	int BLUE_RAY = 7;

	/**
	 * The feature id for the '<em><b>Name</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int BLUE_RAY__NAME = RENTAL_MEDIA__NAME;

	/**
	 * The feature id for the '<em><b>Length</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int BLUE_RAY__LENGTH = RENTAL_MEDIA__LENGTH;

	/**
	 * The number of structural features of the '<em>Blue Ray</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int BLUE_RAY_FEATURE_COUNT = RENTAL_MEDIA_FEATURE_COUNT + 0;

	/**
	 * The number of operations of the '<em>Blue Ray</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int BLUE_RAY_OPERATION_COUNT = RENTAL_MEDIA_OPERATION_COUNT + 0;

	/**
	 * The meta object id for the '{@link netflix.impl.LicenseHolderImpl <em>License Holder</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see netflix.impl.LicenseHolderImpl
	 * @see netflix.impl.NetflixPackageImpl#getLicenseHolder()
	 * @generated
	 */
	int LICENSE_HOLDER = 8;

	/**
	 * The feature id for the '<em><b>Medien</b></em>' reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int LICENSE_HOLDER__MEDIEN = 0;

	/**
	 * The number of structural features of the '<em>License Holder</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int LICENSE_HOLDER_FEATURE_COUNT = 1;

	/**
	 * The number of operations of the '<em>License Holder</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int LICENSE_HOLDER_OPERATION_COUNT = 0;

	/**
	 * The meta object id for the '{@link netflix.impl.DistributorImpl <em>Distributor</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see netflix.impl.DistributorImpl
	 * @see netflix.impl.NetflixPackageImpl#getDistributor()
	 * @generated
	 */
	int DISTRIBUTOR = 9;

	/**
	 * The feature id for the '<em><b>Medien</b></em>' reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int DISTRIBUTOR__MEDIEN = LICENSE_HOLDER__MEDIEN;

	/**
	 * The number of structural features of the '<em>Distributor</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int DISTRIBUTOR_FEATURE_COUNT = LICENSE_HOLDER_FEATURE_COUNT + 0;

	/**
	 * The number of operations of the '<em>Distributor</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int DISTRIBUTOR_OPERATION_COUNT = LICENSE_HOLDER_OPERATION_COUNT + 0;

	/**
	 * The meta object id for the '{@link netflix.impl.InHouseImpl <em>In House</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see netflix.impl.InHouseImpl
	 * @see netflix.impl.NetflixPackageImpl#getInHouse()
	 * @generated
	 */
	int IN_HOUSE = 10;

	/**
	 * The feature id for the '<em><b>Medien</b></em>' reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int IN_HOUSE__MEDIEN = LICENSE_HOLDER__MEDIEN;

	/**
	 * The number of structural features of the '<em>In House</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int IN_HOUSE_FEATURE_COUNT = LICENSE_HOLDER_FEATURE_COUNT + 0;

	/**
	 * The number of operations of the '<em>In House</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int IN_HOUSE_OPERATION_COUNT = LICENSE_HOLDER_OPERATION_COUNT + 0;

	/**
	 * The meta object id for the '{@link netflix.impl.SubscriptionManagementImpl <em>Subscription Management</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see netflix.impl.SubscriptionManagementImpl
	 * @see netflix.impl.NetflixPackageImpl#getSubscriptionManagement()
	 * @generated
	 */
	int SUBSCRIPTION_MANAGEMENT = 11;

	/**
	 * The feature id for the '<em><b>Accounts</b></em>' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int SUBSCRIPTION_MANAGEMENT__ACCOUNTS = 0;

	/**
	 * The number of structural features of the '<em>Subscription Management</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int SUBSCRIPTION_MANAGEMENT_FEATURE_COUNT = 1;

	/**
	 * The number of operations of the '<em>Subscription Management</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int SUBSCRIPTION_MANAGEMENT_OPERATION_COUNT = 0;

	/**
	 * The meta object id for the '{@link netflix.impl.AccoutImpl <em>Accout</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see netflix.impl.AccoutImpl
	 * @see netflix.impl.NetflixPackageImpl#getAccout()
	 * @generated
	 */
	int ACCOUT = 12;

	/**
	 * The feature id for the '<em><b>Profiles</b></em>' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int ACCOUT__PROFILES = 0;

	/**
	 * The feature id for the '<em><b>Devices</b></em>' reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int ACCOUT__DEVICES = 1;

	/**
	 * The feature id for the '<em><b>Email</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int ACCOUT__EMAIL = 2;

	/**
	 * The feature id for the '<em><b>Pwd</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int ACCOUT__PWD = 3;

	/**
	 * The feature id for the '<em><b>Rented Medias</b></em>' reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int ACCOUT__RENTED_MEDIAS = 4;

	/**
	 * The feature id for the '<em><b>Country</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int ACCOUT__COUNTRY = 5;

	/**
	 * The number of structural features of the '<em>Accout</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int ACCOUT_FEATURE_COUNT = 6;

	/**
	 * The number of operations of the '<em>Accout</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int ACCOUT_OPERATION_COUNT = 0;

	/**
	 * The meta object id for the '{@link netflix.impl.ProfileImpl <em>Profile</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see netflix.impl.ProfileImpl
	 * @see netflix.impl.NetflixPackageImpl#getProfile()
	 * @generated
	 */
	int PROFILE = 13;

	/**
	 * The feature id for the '<em><b>Queue</b></em>' containment reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int PROFILE__QUEUE = 0;

	/**
	 * The feature id for the '<em><b>Friend List</b></em>' containment reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int PROFILE__FRIEND_LIST = 1;

	/**
	 * The feature id for the '<em><b>Reviews</b></em>' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int PROFILE__REVIEWS = 2;

	/**
	 * The feature id for the '<em><b>Recommendations</b></em>' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int PROFILE__RECOMMENDATIONS = 3;

	/**
	 * The number of structural features of the '<em>Profile</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int PROFILE_FEATURE_COUNT = 4;

	/**
	 * The number of operations of the '<em>Profile</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int PROFILE_OPERATION_COUNT = 0;

	/**
	 * The meta object id for the '{@link netflix.impl.FavoriteQueueImpl <em>Favorite Queue</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see netflix.impl.FavoriteQueueImpl
	 * @see netflix.impl.NetflixPackageImpl#getFavoriteQueue()
	 * @generated
	 */
	int FAVORITE_QUEUE = 14;

	/**
	 * The feature id for the '<em><b>Medien</b></em>' reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int FAVORITE_QUEUE__MEDIEN = 0;

	/**
	 * The number of structural features of the '<em>Favorite Queue</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int FAVORITE_QUEUE_FEATURE_COUNT = 1;

	/**
	 * The number of operations of the '<em>Favorite Queue</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int FAVORITE_QUEUE_OPERATION_COUNT = 0;

	/**
	 * The meta object id for the '{@link netflix.impl.FriendListImpl <em>Friend List</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see netflix.impl.FriendListImpl
	 * @see netflix.impl.NetflixPackageImpl#getFriendList()
	 * @generated
	 */
	int FRIEND_LIST = 15;

	/**
	 * The feature id for the '<em><b>Friend Profiles</b></em>' reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int FRIEND_LIST__FRIEND_PROFILES = 0;

	/**
	 * The number of structural features of the '<em>Friend List</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int FRIEND_LIST_FEATURE_COUNT = 1;

	/**
	 * The number of operations of the '<em>Friend List</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int FRIEND_LIST_OPERATION_COUNT = 0;

	/**
	 * The meta object id for the '{@link netflix.impl.ReviewImpl <em>Review</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see netflix.impl.ReviewImpl
	 * @see netflix.impl.NetflixPackageImpl#getReview()
	 * @generated
	 */
	int REVIEW = 16;

	/**
	 * The feature id for the '<em><b>Media</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int REVIEW__MEDIA = 0;

	/**
	 * The number of structural features of the '<em>Review</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int REVIEW_FEATURE_COUNT = 1;

	/**
	 * The number of operations of the '<em>Review</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int REVIEW_OPERATION_COUNT = 0;

	/**
	 * The meta object id for the '{@link netflix.impl.RecommendationImpl <em>Recommendation</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see netflix.impl.RecommendationImpl
	 * @see netflix.impl.NetflixPackageImpl#getRecommendation()
	 * @generated
	 */
	int RECOMMENDATION = 17;

	/**
	 * The feature id for the '<em><b>Media Recommendation</b></em>' reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int RECOMMENDATION__MEDIA_RECOMMENDATION = 0;

	/**
	 * The feature id for the '<em><b>Media</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int RECOMMENDATION__MEDIA = 1;

	/**
	 * The number of structural features of the '<em>Recommendation</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int RECOMMENDATION_FEATURE_COUNT = 2;

	/**
	 * The number of operations of the '<em>Recommendation</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int RECOMMENDATION_OPERATION_COUNT = 0;

	/**
	 * The meta object id for the '{@link netflix.impl.StreamServiceImpl <em>Stream Service</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see netflix.impl.StreamServiceImpl
	 * @see netflix.impl.NetflixPackageImpl#getStreamService()
	 * @generated
	 */
	int STREAM_SERVICE = 18;

	/**
	 * The feature id for the '<em><b>Devices</b></em>' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int STREAM_SERVICE__DEVICES = 0;

	/**
	 * The number of structural features of the '<em>Stream Service</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int STREAM_SERVICE_FEATURE_COUNT = 1;

	/**
	 * The number of operations of the '<em>Stream Service</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int STREAM_SERVICE_OPERATION_COUNT = 0;

	/**
	 * The meta object id for the '{@link netflix.impl.DeviceImpl <em>Device</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see netflix.impl.DeviceImpl
	 * @see netflix.impl.NetflixPackageImpl#getDevice()
	 * @generated
	 */
	int DEVICE = 19;

	/**
	 * The number of structural features of the '<em>Device</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int DEVICE_FEATURE_COUNT = 0;

	/**
	 * The number of operations of the '<em>Device</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int DEVICE_OPERATION_COUNT = 0;

	/**
	 * The meta object id for the '{@link netflix.impl.StreamingLibraryImpl <em>Streaming Library</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see netflix.impl.StreamingLibraryImpl
	 * @see netflix.impl.NetflixPackageImpl#getStreamingLibrary()
	 * @generated
	 */
	int STREAMING_LIBRARY = 20;

	/**
	 * The feature id for the '<em><b>Medien</b></em>' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int STREAMING_LIBRARY__MEDIEN = 0;

	/**
	 * The feature id for the '<em><b>License Holders</b></em>' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int STREAMING_LIBRARY__LICENSE_HOLDERS = 1;

	/**
	 * The number of structural features of the '<em>Streaming Library</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int STREAMING_LIBRARY_FEATURE_COUNT = 2;

	/**
	 * The number of operations of the '<em>Streaming Library</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int STREAMING_LIBRARY_OPERATION_COUNT = 0;

	/**
	 * The meta object id for the '{@link netflix.impl.NetflixServiceImpl <em>Service</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see netflix.impl.NetflixServiceImpl
	 * @see netflix.impl.NetflixPackageImpl#getNetflixService()
	 * @generated
	 */
	int NETFLIX_SERVICE = 21;

	/**
	 * The feature id for the '<em><b>Stream Service</b></em>' containment reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int NETFLIX_SERVICE__STREAM_SERVICE = 0;

	/**
	 * The feature id for the '<em><b>Subscription Management</b></em>' containment reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int NETFLIX_SERVICE__SUBSCRIPTION_MANAGEMENT = 1;

	/**
	 * The feature id for the '<em><b>Stream Library</b></em>' containment reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int NETFLIX_SERVICE__STREAM_LIBRARY = 2;

	/**
	 * The number of structural features of the '<em>Service</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int NETFLIX_SERVICE_FEATURE_COUNT = 3;

	/**
	 * The number of operations of the '<em>Service</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int NETFLIX_SERVICE_OPERATION_COUNT = 0;


	/**
	 * Returns the meta object for class '{@link netflix.Media <em>Media</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Media</em>'.
	 * @see netflix.Media
	 * @generated
	 */
	EClass getMedia();

	/**
	 * Returns the meta object for the attribute '{@link netflix.Media#getName <em>Name</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Name</em>'.
	 * @see netflix.Media#getName()
	 * @see #getMedia()
	 * @generated
	 */
	EAttribute getMedia_Name();

	/**
	 * Returns the meta object for the attribute '{@link netflix.Media#getLength <em>Length</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Length</em>'.
	 * @see netflix.Media#getLength()
	 * @see #getMedia()
	 * @generated
	 */
	EAttribute getMedia_Length();

	/**
	 * Returns the meta object for class '{@link netflix.StreamingMedia <em>Streaming Media</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Streaming Media</em>'.
	 * @see netflix.StreamingMedia
	 * @generated
	 */
	EClass getStreamingMedia();

	/**
	 * Returns the meta object for class '{@link netflix.RentalMedia <em>Rental Media</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Rental Media</em>'.
	 * @see netflix.RentalMedia
	 * @generated
	 */
	EClass getRentalMedia();

	/**
	 * Returns the meta object for class '{@link netflix.Movie <em>Movie</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Movie</em>'.
	 * @see netflix.Movie
	 * @generated
	 */
	EClass getMovie();

	/**
	 * Returns the meta object for class '{@link netflix.TVSerie <em>TV Serie</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>TV Serie</em>'.
	 * @see netflix.TVSerie
	 * @generated
	 */
	EClass getTVSerie();

	/**
	 * Returns the meta object for class '{@link netflix.Music <em>Music</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Music</em>'.
	 * @see netflix.Music
	 * @generated
	 */
	EClass getMusic();

	/**
	 * Returns the meta object for class '{@link netflix.DVD <em>DVD</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>DVD</em>'.
	 * @see netflix.DVD
	 * @generated
	 */
	EClass getDVD();

	/**
	 * Returns the meta object for class '{@link netflix.BlueRay <em>Blue Ray</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Blue Ray</em>'.
	 * @see netflix.BlueRay
	 * @generated
	 */
	EClass getBlueRay();

	/**
	 * Returns the meta object for class '{@link netflix.LicenseHolder <em>License Holder</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>License Holder</em>'.
	 * @see netflix.LicenseHolder
	 * @generated
	 */
	EClass getLicenseHolder();

	/**
	 * Returns the meta object for the reference list '{@link netflix.LicenseHolder#getMedien <em>Medien</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the reference list '<em>Medien</em>'.
	 * @see netflix.LicenseHolder#getMedien()
	 * @see #getLicenseHolder()
	 * @generated
	 */
	EReference getLicenseHolder_Medien();

	/**
	 * Returns the meta object for class '{@link netflix.Distributor <em>Distributor</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Distributor</em>'.
	 * @see netflix.Distributor
	 * @generated
	 */
	EClass getDistributor();

	/**
	 * Returns the meta object for class '{@link netflix.InHouse <em>In House</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>In House</em>'.
	 * @see netflix.InHouse
	 * @generated
	 */
	EClass getInHouse();

	/**
	 * Returns the meta object for class '{@link netflix.SubscriptionManagement <em>Subscription Management</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Subscription Management</em>'.
	 * @see netflix.SubscriptionManagement
	 * @generated
	 */
	EClass getSubscriptionManagement();

	/**
	 * Returns the meta object for the containment reference list '{@link netflix.SubscriptionManagement#getAccounts <em>Accounts</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the containment reference list '<em>Accounts</em>'.
	 * @see netflix.SubscriptionManagement#getAccounts()
	 * @see #getSubscriptionManagement()
	 * @generated
	 */
	EReference getSubscriptionManagement_Accounts();

	/**
	 * Returns the meta object for class '{@link netflix.Accout <em>Accout</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Accout</em>'.
	 * @see netflix.Accout
	 * @generated
	 */
	EClass getAccout();

	/**
	 * Returns the meta object for the containment reference list '{@link netflix.Accout#getProfiles <em>Profiles</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the containment reference list '<em>Profiles</em>'.
	 * @see netflix.Accout#getProfiles()
	 * @see #getAccout()
	 * @generated
	 */
	EReference getAccout_Profiles();

	/**
	 * Returns the meta object for the reference list '{@link netflix.Accout#getDevices <em>Devices</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the reference list '<em>Devices</em>'.
	 * @see netflix.Accout#getDevices()
	 * @see #getAccout()
	 * @generated
	 */
	EReference getAccout_Devices();

	/**
	 * Returns the meta object for the attribute '{@link netflix.Accout#getEmail <em>Email</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Email</em>'.
	 * @see netflix.Accout#getEmail()
	 * @see #getAccout()
	 * @generated
	 */
	EAttribute getAccout_Email();

	/**
	 * Returns the meta object for the attribute '{@link netflix.Accout#getPwd <em>Pwd</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Pwd</em>'.
	 * @see netflix.Accout#getPwd()
	 * @see #getAccout()
	 * @generated
	 */
	EAttribute getAccout_Pwd();

	/**
	 * Returns the meta object for the reference list '{@link netflix.Accout#getRentedMedias <em>Rented Medias</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the reference list '<em>Rented Medias</em>'.
	 * @see netflix.Accout#getRentedMedias()
	 * @see #getAccout()
	 * @generated
	 */
	EReference getAccout_RentedMedias();

	/**
	 * Returns the meta object for the attribute '{@link netflix.Accout#getCountry <em>Country</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Country</em>'.
	 * @see netflix.Accout#getCountry()
	 * @see #getAccout()
	 * @generated
	 */
	EAttribute getAccout_Country();

	/**
	 * Returns the meta object for class '{@link netflix.Profile <em>Profile</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Profile</em>'.
	 * @see netflix.Profile
	 * @generated
	 */
	EClass getProfile();

	/**
	 * Returns the meta object for the containment reference '{@link netflix.Profile#getQueue <em>Queue</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the containment reference '<em>Queue</em>'.
	 * @see netflix.Profile#getQueue()
	 * @see #getProfile()
	 * @generated
	 */
	EReference getProfile_Queue();

	/**
	 * Returns the meta object for the containment reference '{@link netflix.Profile#getFriendList <em>Friend List</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the containment reference '<em>Friend List</em>'.
	 * @see netflix.Profile#getFriendList()
	 * @see #getProfile()
	 * @generated
	 */
	EReference getProfile_FriendList();

	/**
	 * Returns the meta object for the containment reference list '{@link netflix.Profile#getReviews <em>Reviews</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the containment reference list '<em>Reviews</em>'.
	 * @see netflix.Profile#getReviews()
	 * @see #getProfile()
	 * @generated
	 */
	EReference getProfile_Reviews();

	/**
	 * Returns the meta object for the containment reference list '{@link netflix.Profile#getRecommendations <em>Recommendations</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the containment reference list '<em>Recommendations</em>'.
	 * @see netflix.Profile#getRecommendations()
	 * @see #getProfile()
	 * @generated
	 */
	EReference getProfile_Recommendations();

	/**
	 * Returns the meta object for class '{@link netflix.FavoriteQueue <em>Favorite Queue</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Favorite Queue</em>'.
	 * @see netflix.FavoriteQueue
	 * @generated
	 */
	EClass getFavoriteQueue();

	/**
	 * Returns the meta object for the reference list '{@link netflix.FavoriteQueue#getMedien <em>Medien</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the reference list '<em>Medien</em>'.
	 * @see netflix.FavoriteQueue#getMedien()
	 * @see #getFavoriteQueue()
	 * @generated
	 */
	EReference getFavoriteQueue_Medien();

	/**
	 * Returns the meta object for class '{@link netflix.FriendList <em>Friend List</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Friend List</em>'.
	 * @see netflix.FriendList
	 * @generated
	 */
	EClass getFriendList();

	/**
	 * Returns the meta object for the reference list '{@link netflix.FriendList#getFriendProfiles <em>Friend Profiles</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the reference list '<em>Friend Profiles</em>'.
	 * @see netflix.FriendList#getFriendProfiles()
	 * @see #getFriendList()
	 * @generated
	 */
	EReference getFriendList_FriendProfiles();

	/**
	 * Returns the meta object for class '{@link netflix.Review <em>Review</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Review</em>'.
	 * @see netflix.Review
	 * @generated
	 */
	EClass getReview();

	/**
	 * Returns the meta object for the reference '{@link netflix.Review#getMedia <em>Media</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the reference '<em>Media</em>'.
	 * @see netflix.Review#getMedia()
	 * @see #getReview()
	 * @generated
	 */
	EReference getReview_Media();

	/**
	 * Returns the meta object for class '{@link netflix.Recommendation <em>Recommendation</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Recommendation</em>'.
	 * @see netflix.Recommendation
	 * @generated
	 */
	EClass getRecommendation();

	/**
	 * Returns the meta object for the reference list '{@link netflix.Recommendation#getMediaRecommendation <em>Media Recommendation</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the reference list '<em>Media Recommendation</em>'.
	 * @see netflix.Recommendation#getMediaRecommendation()
	 * @see #getRecommendation()
	 * @generated
	 */
	EReference getRecommendation_MediaRecommendation();

	/**
	 * Returns the meta object for the reference '{@link netflix.Recommendation#getMedia <em>Media</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the reference '<em>Media</em>'.
	 * @see netflix.Recommendation#getMedia()
	 * @see #getRecommendation()
	 * @generated
	 */
	EReference getRecommendation_Media();

	/**
	 * Returns the meta object for class '{@link netflix.StreamService <em>Stream Service</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Stream Service</em>'.
	 * @see netflix.StreamService
	 * @generated
	 */
	EClass getStreamService();

	/**
	 * Returns the meta object for the containment reference list '{@link netflix.StreamService#getDevices <em>Devices</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the containment reference list '<em>Devices</em>'.
	 * @see netflix.StreamService#getDevices()
	 * @see #getStreamService()
	 * @generated
	 */
	EReference getStreamService_Devices();

	/**
	 * Returns the meta object for class '{@link netflix.Device <em>Device</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Device</em>'.
	 * @see netflix.Device
	 * @generated
	 */
	EClass getDevice();

	/**
	 * Returns the meta object for class '{@link netflix.StreamingLibrary <em>Streaming Library</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Streaming Library</em>'.
	 * @see netflix.StreamingLibrary
	 * @generated
	 */
	EClass getStreamingLibrary();

	/**
	 * Returns the meta object for the containment reference list '{@link netflix.StreamingLibrary#getMedien <em>Medien</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the containment reference list '<em>Medien</em>'.
	 * @see netflix.StreamingLibrary#getMedien()
	 * @see #getStreamingLibrary()
	 * @generated
	 */
	EReference getStreamingLibrary_Medien();

	/**
	 * Returns the meta object for the containment reference list '{@link netflix.StreamingLibrary#getLicenseHolders <em>License Holders</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the containment reference list '<em>License Holders</em>'.
	 * @see netflix.StreamingLibrary#getLicenseHolders()
	 * @see #getStreamingLibrary()
	 * @generated
	 */
	EReference getStreamingLibrary_LicenseHolders();

	/**
	 * Returns the meta object for class '{@link netflix.NetflixService <em>Service</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Service</em>'.
	 * @see netflix.NetflixService
	 * @generated
	 */
	EClass getNetflixService();

	/**
	 * Returns the meta object for the containment reference '{@link netflix.NetflixService#getStreamService <em>Stream Service</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the containment reference '<em>Stream Service</em>'.
	 * @see netflix.NetflixService#getStreamService()
	 * @see #getNetflixService()
	 * @generated
	 */
	EReference getNetflixService_StreamService();

	/**
	 * Returns the meta object for the containment reference '{@link netflix.NetflixService#getSubscriptionManagement <em>Subscription Management</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the containment reference '<em>Subscription Management</em>'.
	 * @see netflix.NetflixService#getSubscriptionManagement()
	 * @see #getNetflixService()
	 * @generated
	 */
	EReference getNetflixService_SubscriptionManagement();

	/**
	 * Returns the meta object for the containment reference '{@link netflix.NetflixService#getStreamLibrary <em>Stream Library</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the containment reference '<em>Stream Library</em>'.
	 * @see netflix.NetflixService#getStreamLibrary()
	 * @see #getNetflixService()
	 * @generated
	 */
	EReference getNetflixService_StreamLibrary();

	/**
	 * Returns the factory that creates the instances of the model.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the factory that creates the instances of the model.
	 * @generated
	 */
	NetflixFactory getNetflixFactory();

	/**
	 * <!-- begin-user-doc -->
	 * Defines literals for the meta objects that represent
	 * <ul>
	 *   <li>each class,</li>
	 *   <li>each feature of each class,</li>
	 *   <li>each operation of each class,</li>
	 *   <li>each enum,</li>
	 *   <li>and each data type</li>
	 * </ul>
	 * <!-- end-user-doc -->
	 * @generated
	 */
	interface Literals {
		/**
		 * The meta object literal for the '{@link netflix.impl.MediaImpl <em>Media</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see netflix.impl.MediaImpl
		 * @see netflix.impl.NetflixPackageImpl#getMedia()
		 * @generated
		 */
		EClass MEDIA = eINSTANCE.getMedia();

		/**
		 * The meta object literal for the '<em><b>Name</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute MEDIA__NAME = eINSTANCE.getMedia_Name();

		/**
		 * The meta object literal for the '<em><b>Length</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute MEDIA__LENGTH = eINSTANCE.getMedia_Length();

		/**
		 * The meta object literal for the '{@link netflix.impl.StreamingMediaImpl <em>Streaming Media</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see netflix.impl.StreamingMediaImpl
		 * @see netflix.impl.NetflixPackageImpl#getStreamingMedia()
		 * @generated
		 */
		EClass STREAMING_MEDIA = eINSTANCE.getStreamingMedia();

		/**
		 * The meta object literal for the '{@link netflix.impl.RentalMediaImpl <em>Rental Media</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see netflix.impl.RentalMediaImpl
		 * @see netflix.impl.NetflixPackageImpl#getRentalMedia()
		 * @generated
		 */
		EClass RENTAL_MEDIA = eINSTANCE.getRentalMedia();

		/**
		 * The meta object literal for the '{@link netflix.impl.MovieImpl <em>Movie</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see netflix.impl.MovieImpl
		 * @see netflix.impl.NetflixPackageImpl#getMovie()
		 * @generated
		 */
		EClass MOVIE = eINSTANCE.getMovie();

		/**
		 * The meta object literal for the '{@link netflix.impl.TVSerieImpl <em>TV Serie</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see netflix.impl.TVSerieImpl
		 * @see netflix.impl.NetflixPackageImpl#getTVSerie()
		 * @generated
		 */
		EClass TV_SERIE = eINSTANCE.getTVSerie();

		/**
		 * The meta object literal for the '{@link netflix.impl.MusicImpl <em>Music</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see netflix.impl.MusicImpl
		 * @see netflix.impl.NetflixPackageImpl#getMusic()
		 * @generated
		 */
		EClass MUSIC = eINSTANCE.getMusic();

		/**
		 * The meta object literal for the '{@link netflix.impl.DVDImpl <em>DVD</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see netflix.impl.DVDImpl
		 * @see netflix.impl.NetflixPackageImpl#getDVD()
		 * @generated
		 */
		EClass DVD = eINSTANCE.getDVD();

		/**
		 * The meta object literal for the '{@link netflix.impl.BlueRayImpl <em>Blue Ray</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see netflix.impl.BlueRayImpl
		 * @see netflix.impl.NetflixPackageImpl#getBlueRay()
		 * @generated
		 */
		EClass BLUE_RAY = eINSTANCE.getBlueRay();

		/**
		 * The meta object literal for the '{@link netflix.impl.LicenseHolderImpl <em>License Holder</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see netflix.impl.LicenseHolderImpl
		 * @see netflix.impl.NetflixPackageImpl#getLicenseHolder()
		 * @generated
		 */
		EClass LICENSE_HOLDER = eINSTANCE.getLicenseHolder();

		/**
		 * The meta object literal for the '<em><b>Medien</b></em>' reference list feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference LICENSE_HOLDER__MEDIEN = eINSTANCE.getLicenseHolder_Medien();

		/**
		 * The meta object literal for the '{@link netflix.impl.DistributorImpl <em>Distributor</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see netflix.impl.DistributorImpl
		 * @see netflix.impl.NetflixPackageImpl#getDistributor()
		 * @generated
		 */
		EClass DISTRIBUTOR = eINSTANCE.getDistributor();

		/**
		 * The meta object literal for the '{@link netflix.impl.InHouseImpl <em>In House</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see netflix.impl.InHouseImpl
		 * @see netflix.impl.NetflixPackageImpl#getInHouse()
		 * @generated
		 */
		EClass IN_HOUSE = eINSTANCE.getInHouse();

		/**
		 * The meta object literal for the '{@link netflix.impl.SubscriptionManagementImpl <em>Subscription Management</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see netflix.impl.SubscriptionManagementImpl
		 * @see netflix.impl.NetflixPackageImpl#getSubscriptionManagement()
		 * @generated
		 */
		EClass SUBSCRIPTION_MANAGEMENT = eINSTANCE.getSubscriptionManagement();

		/**
		 * The meta object literal for the '<em><b>Accounts</b></em>' containment reference list feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference SUBSCRIPTION_MANAGEMENT__ACCOUNTS = eINSTANCE.getSubscriptionManagement_Accounts();

		/**
		 * The meta object literal for the '{@link netflix.impl.AccoutImpl <em>Accout</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see netflix.impl.AccoutImpl
		 * @see netflix.impl.NetflixPackageImpl#getAccout()
		 * @generated
		 */
		EClass ACCOUT = eINSTANCE.getAccout();

		/**
		 * The meta object literal for the '<em><b>Profiles</b></em>' containment reference list feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference ACCOUT__PROFILES = eINSTANCE.getAccout_Profiles();

		/**
		 * The meta object literal for the '<em><b>Devices</b></em>' reference list feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference ACCOUT__DEVICES = eINSTANCE.getAccout_Devices();

		/**
		 * The meta object literal for the '<em><b>Email</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute ACCOUT__EMAIL = eINSTANCE.getAccout_Email();

		/**
		 * The meta object literal for the '<em><b>Pwd</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute ACCOUT__PWD = eINSTANCE.getAccout_Pwd();

		/**
		 * The meta object literal for the '<em><b>Rented Medias</b></em>' reference list feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference ACCOUT__RENTED_MEDIAS = eINSTANCE.getAccout_RentedMedias();

		/**
		 * The meta object literal for the '<em><b>Country</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute ACCOUT__COUNTRY = eINSTANCE.getAccout_Country();

		/**
		 * The meta object literal for the '{@link netflix.impl.ProfileImpl <em>Profile</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see netflix.impl.ProfileImpl
		 * @see netflix.impl.NetflixPackageImpl#getProfile()
		 * @generated
		 */
		EClass PROFILE = eINSTANCE.getProfile();

		/**
		 * The meta object literal for the '<em><b>Queue</b></em>' containment reference feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference PROFILE__QUEUE = eINSTANCE.getProfile_Queue();

		/**
		 * The meta object literal for the '<em><b>Friend List</b></em>' containment reference feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference PROFILE__FRIEND_LIST = eINSTANCE.getProfile_FriendList();

		/**
		 * The meta object literal for the '<em><b>Reviews</b></em>' containment reference list feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference PROFILE__REVIEWS = eINSTANCE.getProfile_Reviews();

		/**
		 * The meta object literal for the '<em><b>Recommendations</b></em>' containment reference list feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference PROFILE__RECOMMENDATIONS = eINSTANCE.getProfile_Recommendations();

		/**
		 * The meta object literal for the '{@link netflix.impl.FavoriteQueueImpl <em>Favorite Queue</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see netflix.impl.FavoriteQueueImpl
		 * @see netflix.impl.NetflixPackageImpl#getFavoriteQueue()
		 * @generated
		 */
		EClass FAVORITE_QUEUE = eINSTANCE.getFavoriteQueue();

		/**
		 * The meta object literal for the '<em><b>Medien</b></em>' reference list feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference FAVORITE_QUEUE__MEDIEN = eINSTANCE.getFavoriteQueue_Medien();

		/**
		 * The meta object literal for the '{@link netflix.impl.FriendListImpl <em>Friend List</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see netflix.impl.FriendListImpl
		 * @see netflix.impl.NetflixPackageImpl#getFriendList()
		 * @generated
		 */
		EClass FRIEND_LIST = eINSTANCE.getFriendList();

		/**
		 * The meta object literal for the '<em><b>Friend Profiles</b></em>' reference list feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference FRIEND_LIST__FRIEND_PROFILES = eINSTANCE.getFriendList_FriendProfiles();

		/**
		 * The meta object literal for the '{@link netflix.impl.ReviewImpl <em>Review</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see netflix.impl.ReviewImpl
		 * @see netflix.impl.NetflixPackageImpl#getReview()
		 * @generated
		 */
		EClass REVIEW = eINSTANCE.getReview();

		/**
		 * The meta object literal for the '<em><b>Media</b></em>' reference feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference REVIEW__MEDIA = eINSTANCE.getReview_Media();

		/**
		 * The meta object literal for the '{@link netflix.impl.RecommendationImpl <em>Recommendation</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see netflix.impl.RecommendationImpl
		 * @see netflix.impl.NetflixPackageImpl#getRecommendation()
		 * @generated
		 */
		EClass RECOMMENDATION = eINSTANCE.getRecommendation();

		/**
		 * The meta object literal for the '<em><b>Media Recommendation</b></em>' reference list feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference RECOMMENDATION__MEDIA_RECOMMENDATION = eINSTANCE.getRecommendation_MediaRecommendation();

		/**
		 * The meta object literal for the '<em><b>Media</b></em>' reference feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference RECOMMENDATION__MEDIA = eINSTANCE.getRecommendation_Media();

		/**
		 * The meta object literal for the '{@link netflix.impl.StreamServiceImpl <em>Stream Service</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see netflix.impl.StreamServiceImpl
		 * @see netflix.impl.NetflixPackageImpl#getStreamService()
		 * @generated
		 */
		EClass STREAM_SERVICE = eINSTANCE.getStreamService();

		/**
		 * The meta object literal for the '<em><b>Devices</b></em>' containment reference list feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference STREAM_SERVICE__DEVICES = eINSTANCE.getStreamService_Devices();

		/**
		 * The meta object literal for the '{@link netflix.impl.DeviceImpl <em>Device</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see netflix.impl.DeviceImpl
		 * @see netflix.impl.NetflixPackageImpl#getDevice()
		 * @generated
		 */
		EClass DEVICE = eINSTANCE.getDevice();

		/**
		 * The meta object literal for the '{@link netflix.impl.StreamingLibraryImpl <em>Streaming Library</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see netflix.impl.StreamingLibraryImpl
		 * @see netflix.impl.NetflixPackageImpl#getStreamingLibrary()
		 * @generated
		 */
		EClass STREAMING_LIBRARY = eINSTANCE.getStreamingLibrary();

		/**
		 * The meta object literal for the '<em><b>Medien</b></em>' containment reference list feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference STREAMING_LIBRARY__MEDIEN = eINSTANCE.getStreamingLibrary_Medien();

		/**
		 * The meta object literal for the '<em><b>License Holders</b></em>' containment reference list feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference STREAMING_LIBRARY__LICENSE_HOLDERS = eINSTANCE.getStreamingLibrary_LicenseHolders();

		/**
		 * The meta object literal for the '{@link netflix.impl.NetflixServiceImpl <em>Service</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see netflix.impl.NetflixServiceImpl
		 * @see netflix.impl.NetflixPackageImpl#getNetflixService()
		 * @generated
		 */
		EClass NETFLIX_SERVICE = eINSTANCE.getNetflixService();

		/**
		 * The meta object literal for the '<em><b>Stream Service</b></em>' containment reference feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference NETFLIX_SERVICE__STREAM_SERVICE = eINSTANCE.getNetflixService_StreamService();

		/**
		 * The meta object literal for the '<em><b>Subscription Management</b></em>' containment reference feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference NETFLIX_SERVICE__SUBSCRIPTION_MANAGEMENT = eINSTANCE.getNetflixService_SubscriptionManagement();

		/**
		 * The meta object literal for the '<em><b>Stream Library</b></em>' containment reference feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference NETFLIX_SERVICE__STREAM_LIBRARY = eINSTANCE.getNetflixService_StreamLibrary();

	}

} //NetflixPackage
