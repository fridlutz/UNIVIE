/**
 */
package at.ac.univie.swa.ase2014.a0123456.task1.model.netflix;

import org.eclipse.emf.common.util.EList;

import org.eclipse.emf.ecore.EObject;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Recommendation</b></em>'.
 * <!-- end-user-doc -->
 *
 * <p>
 * The following features are supported:
 * <ul>
 *   <li>{@link at.ac.univie.swa.ase2014.a0123456.task1.model.netflix.Recommendation#getMediaRecommendation <em>Media Recommendation</em>}</li>
 *   <li>{@link at.ac.univie.swa.ase2014.a0123456.task1.model.netflix.Recommendation#getMedia <em>Media</em>}</li>
 * </ul>
 * </p>
 *
 * @see at.ac.univie.swa.ase2014.a0123456.task1.model.netflix.NetflixPackage#getRecommendation()
 * @model
 * @generated
 */
public interface Recommendation extends EObject {
	/**
	 * Returns the value of the '<em><b>Media Recommendation</b></em>' reference list.
	 * The list contents are of type {@link at.ac.univie.swa.ase2014.a0123456.task1.model.netflix.Profile}.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Media Recommendation</em>' reference list isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Media Recommendation</em>' reference list.
	 * @see at.ac.univie.swa.ase2014.a0123456.task1.model.netflix.NetflixPackage#getRecommendation_MediaRecommendation()
	 * @model required="true"
	 * @generated
	 */
	EList<Profile> getMediaRecommendation();

	/**
	 * Returns the value of the '<em><b>Media</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Media</em>' reference isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Media</em>' reference.
	 * @see #setMedia(Media)
	 * @see at.ac.univie.swa.ase2014.a0123456.task1.model.netflix.NetflixPackage#getRecommendation_Media()
	 * @model required="true"
	 * @generated
	 */
	Media getMedia();

	/**
	 * Sets the value of the '{@link at.ac.univie.swa.ase2014.a0123456.task1.model.netflix.Recommendation#getMedia <em>Media</em>}' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Media</em>' reference.
	 * @see #getMedia()
	 * @generated
	 */
	void setMedia(Media value);

} // Recommendation
