/**
 */
package at.ac.univie.swa.ase2014.a0123456.task1.model.netflix.util;

import at.ac.univie.swa.ase2014.a0123456.task1.model.netflix.*;

import org.eclipse.emf.ecore.EObject;
import org.eclipse.emf.ecore.EPackage;

import org.eclipse.emf.ecore.util.Switch;

/**
 * <!-- begin-user-doc -->
 * The <b>Switch</b> for the model's inheritance hierarchy.
 * It supports the call {@link #doSwitch(EObject) doSwitch(object)}
 * to invoke the <code>caseXXX</code> method for each class of the model,
 * starting with the actual class of the object
 * and proceeding up the inheritance hierarchy
 * until a non-null result is returned,
 * which is the result of the switch.
 * <!-- end-user-doc -->
 * @see at.ac.univie.swa.ase2014.a0123456.task1.model.netflix.NetflixPackage
 * @generated
 */
public class NetflixSwitch<T> extends Switch<T> {
	/**
	 * The cached model package
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected static NetflixPackage modelPackage;

	/**
	 * Creates an instance of the switch.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public NetflixSwitch() {
		if (modelPackage == null) {
			modelPackage = NetflixPackage.eINSTANCE;
		}
	}

	/**
	 * Checks whether this is a switch for the given package.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @parameter ePackage the package in question.
	 * @return whether this is a switch for the given package.
	 * @generated
	 */
	@Override
	protected boolean isSwitchFor(EPackage ePackage) {
		return ePackage == modelPackage;
	}

	/**
	 * Calls <code>caseXXX</code> for each class of the model until one returns a non null result; it yields that result.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the first non-null result returned by a <code>caseXXX</code> call.
	 * @generated
	 */
	@Override
	protected T doSwitch(int classifierID, EObject theEObject) {
		switch (classifierID) {
			case NetflixPackage.MEDIA: {
				Media media = (Media)theEObject;
				T result = caseMedia(media);
				if (result == null) result = defaultCase(theEObject);
				return result;
			}
			case NetflixPackage.STREAMING_MEDIA: {
				StreamingMedia streamingMedia = (StreamingMedia)theEObject;
				T result = caseStreamingMedia(streamingMedia);
				if (result == null) result = caseMedia(streamingMedia);
				if (result == null) result = defaultCase(theEObject);
				return result;
			}
			case NetflixPackage.RENTAL_MEDIA: {
				RentalMedia rentalMedia = (RentalMedia)theEObject;
				T result = caseRentalMedia(rentalMedia);
				if (result == null) result = caseMedia(rentalMedia);
				if (result == null) result = defaultCase(theEObject);
				return result;
			}
			case NetflixPackage.MOVIE: {
				Movie movie = (Movie)theEObject;
				T result = caseMovie(movie);
				if (result == null) result = caseStreamingMedia(movie);
				if (result == null) result = caseMedia(movie);
				if (result == null) result = defaultCase(theEObject);
				return result;
			}
			case NetflixPackage.TV_SERIE: {
				TVSerie tvSerie = (TVSerie)theEObject;
				T result = caseTVSerie(tvSerie);
				if (result == null) result = caseStreamingMedia(tvSerie);
				if (result == null) result = caseMedia(tvSerie);
				if (result == null) result = defaultCase(theEObject);
				return result;
			}
			case NetflixPackage.MUSIC: {
				Music music = (Music)theEObject;
				T result = caseMusic(music);
				if (result == null) result = caseStreamingMedia(music);
				if (result == null) result = caseMedia(music);
				if (result == null) result = defaultCase(theEObject);
				return result;
			}
			case NetflixPackage.DVD: {
				DVD dvd = (DVD)theEObject;
				T result = caseDVD(dvd);
				if (result == null) result = caseRentalMedia(dvd);
				if (result == null) result = caseMedia(dvd);
				if (result == null) result = defaultCase(theEObject);
				return result;
			}
			case NetflixPackage.BLUE_RAY: {
				BlueRay blueRay = (BlueRay)theEObject;
				T result = caseBlueRay(blueRay);
				if (result == null) result = caseRentalMedia(blueRay);
				if (result == null) result = caseMedia(blueRay);
				if (result == null) result = defaultCase(theEObject);
				return result;
			}
			case NetflixPackage.LICENSE_HOLDER: {
				LicenseHolder licenseHolder = (LicenseHolder)theEObject;
				T result = caseLicenseHolder(licenseHolder);
				if (result == null) result = defaultCase(theEObject);
				return result;
			}
			case NetflixPackage.DISTRIBUTOR: {
				Distributor distributor = (Distributor)theEObject;
				T result = caseDistributor(distributor);
				if (result == null) result = caseLicenseHolder(distributor);
				if (result == null) result = defaultCase(theEObject);
				return result;
			}
			case NetflixPackage.IN_HOUSE: {
				InHouse inHouse = (InHouse)theEObject;
				T result = caseInHouse(inHouse);
				if (result == null) result = caseLicenseHolder(inHouse);
				if (result == null) result = defaultCase(theEObject);
				return result;
			}
			case NetflixPackage.SUBSCRIPTION_MANAGEMENT: {
				SubscriptionManagement subscriptionManagement = (SubscriptionManagement)theEObject;
				T result = caseSubscriptionManagement(subscriptionManagement);
				if (result == null) result = defaultCase(theEObject);
				return result;
			}
			case NetflixPackage.ACCOUT: {
				Accout accout = (Accout)theEObject;
				T result = caseAccout(accout);
				if (result == null) result = defaultCase(theEObject);
				return result;
			}
			case NetflixPackage.PROFILE: {
				Profile profile = (Profile)theEObject;
				T result = caseProfile(profile);
				if (result == null) result = defaultCase(theEObject);
				return result;
			}
			case NetflixPackage.FAVORITE_QUEUE: {
				FavoriteQueue favoriteQueue = (FavoriteQueue)theEObject;
				T result = caseFavoriteQueue(favoriteQueue);
				if (result == null) result = defaultCase(theEObject);
				return result;
			}
			case NetflixPackage.FRIEND_LIST: {
				FriendList friendList = (FriendList)theEObject;
				T result = caseFriendList(friendList);
				if (result == null) result = defaultCase(theEObject);
				return result;
			}
			case NetflixPackage.REVIEW: {
				Review review = (Review)theEObject;
				T result = caseReview(review);
				if (result == null) result = defaultCase(theEObject);
				return result;
			}
			case NetflixPackage.RECOMMENDATION: {
				Recommendation recommendation = (Recommendation)theEObject;
				T result = caseRecommendation(recommendation);
				if (result == null) result = defaultCase(theEObject);
				return result;
			}
			case NetflixPackage.STREAM_SERVICE: {
				StreamService streamService = (StreamService)theEObject;
				T result = caseStreamService(streamService);
				if (result == null) result = defaultCase(theEObject);
				return result;
			}
			case NetflixPackage.DEVICE: {
				Device device = (Device)theEObject;
				T result = caseDevice(device);
				if (result == null) result = defaultCase(theEObject);
				return result;
			}
			case NetflixPackage.STREAMING_LIBRARY: {
				StreamingLibrary streamingLibrary = (StreamingLibrary)theEObject;
				T result = caseStreamingLibrary(streamingLibrary);
				if (result == null) result = defaultCase(theEObject);
				return result;
			}
			case NetflixPackage.NETFLIX_SERVICE: {
				NetflixService netflixService = (NetflixService)theEObject;
				T result = caseNetflixService(netflixService);
				if (result == null) result = defaultCase(theEObject);
				return result;
			}
			default: return defaultCase(theEObject);
		}
	}

	/**
	 * Returns the result of interpreting the object as an instance of '<em>Media</em>'.
	 * <!-- begin-user-doc -->
	 * This implementation returns null;
	 * returning a non-null result will terminate the switch.
	 * <!-- end-user-doc -->
	 * @param object the target of the switch.
	 * @return the result of interpreting the object as an instance of '<em>Media</em>'.
	 * @see #doSwitch(org.eclipse.emf.ecore.EObject) doSwitch(EObject)
	 * @generated
	 */
	public T caseMedia(Media object) {
		return null;
	}

	/**
	 * Returns the result of interpreting the object as an instance of '<em>Streaming Media</em>'.
	 * <!-- begin-user-doc -->
	 * This implementation returns null;
	 * returning a non-null result will terminate the switch.
	 * <!-- end-user-doc -->
	 * @param object the target of the switch.
	 * @return the result of interpreting the object as an instance of '<em>Streaming Media</em>'.
	 * @see #doSwitch(org.eclipse.emf.ecore.EObject) doSwitch(EObject)
	 * @generated
	 */
	public T caseStreamingMedia(StreamingMedia object) {
		return null;
	}

	/**
	 * Returns the result of interpreting the object as an instance of '<em>Rental Media</em>'.
	 * <!-- begin-user-doc -->
	 * This implementation returns null;
	 * returning a non-null result will terminate the switch.
	 * <!-- end-user-doc -->
	 * @param object the target of the switch.
	 * @return the result of interpreting the object as an instance of '<em>Rental Media</em>'.
	 * @see #doSwitch(org.eclipse.emf.ecore.EObject) doSwitch(EObject)
	 * @generated
	 */
	public T caseRentalMedia(RentalMedia object) {
		return null;
	}

	/**
	 * Returns the result of interpreting the object as an instance of '<em>Movie</em>'.
	 * <!-- begin-user-doc -->
	 * This implementation returns null;
	 * returning a non-null result will terminate the switch.
	 * <!-- end-user-doc -->
	 * @param object the target of the switch.
	 * @return the result of interpreting the object as an instance of '<em>Movie</em>'.
	 * @see #doSwitch(org.eclipse.emf.ecore.EObject) doSwitch(EObject)
	 * @generated
	 */
	public T caseMovie(Movie object) {
		return null;
	}

	/**
	 * Returns the result of interpreting the object as an instance of '<em>TV Serie</em>'.
	 * <!-- begin-user-doc -->
	 * This implementation returns null;
	 * returning a non-null result will terminate the switch.
	 * <!-- end-user-doc -->
	 * @param object the target of the switch.
	 * @return the result of interpreting the object as an instance of '<em>TV Serie</em>'.
	 * @see #doSwitch(org.eclipse.emf.ecore.EObject) doSwitch(EObject)
	 * @generated
	 */
	public T caseTVSerie(TVSerie object) {
		return null;
	}

	/**
	 * Returns the result of interpreting the object as an instance of '<em>Music</em>'.
	 * <!-- begin-user-doc -->
	 * This implementation returns null;
	 * returning a non-null result will terminate the switch.
	 * <!-- end-user-doc -->
	 * @param object the target of the switch.
	 * @return the result of interpreting the object as an instance of '<em>Music</em>'.
	 * @see #doSwitch(org.eclipse.emf.ecore.EObject) doSwitch(EObject)
	 * @generated
	 */
	public T caseMusic(Music object) {
		return null;
	}

	/**
	 * Returns the result of interpreting the object as an instance of '<em>DVD</em>'.
	 * <!-- begin-user-doc -->
	 * This implementation returns null;
	 * returning a non-null result will terminate the switch.
	 * <!-- end-user-doc -->
	 * @param object the target of the switch.
	 * @return the result of interpreting the object as an instance of '<em>DVD</em>'.
	 * @see #doSwitch(org.eclipse.emf.ecore.EObject) doSwitch(EObject)
	 * @generated
	 */
	public T caseDVD(DVD object) {
		return null;
	}

	/**
	 * Returns the result of interpreting the object as an instance of '<em>Blue Ray</em>'.
	 * <!-- begin-user-doc -->
	 * This implementation returns null;
	 * returning a non-null result will terminate the switch.
	 * <!-- end-user-doc -->
	 * @param object the target of the switch.
	 * @return the result of interpreting the object as an instance of '<em>Blue Ray</em>'.
	 * @see #doSwitch(org.eclipse.emf.ecore.EObject) doSwitch(EObject)
	 * @generated
	 */
	public T caseBlueRay(BlueRay object) {
		return null;
	}

	/**
	 * Returns the result of interpreting the object as an instance of '<em>License Holder</em>'.
	 * <!-- begin-user-doc -->
	 * This implementation returns null;
	 * returning a non-null result will terminate the switch.
	 * <!-- end-user-doc -->
	 * @param object the target of the switch.
	 * @return the result of interpreting the object as an instance of '<em>License Holder</em>'.
	 * @see #doSwitch(org.eclipse.emf.ecore.EObject) doSwitch(EObject)
	 * @generated
	 */
	public T caseLicenseHolder(LicenseHolder object) {
		return null;
	}

	/**
	 * Returns the result of interpreting the object as an instance of '<em>Distributor</em>'.
	 * <!-- begin-user-doc -->
	 * This implementation returns null;
	 * returning a non-null result will terminate the switch.
	 * <!-- end-user-doc -->
	 * @param object the target of the switch.
	 * @return the result of interpreting the object as an instance of '<em>Distributor</em>'.
	 * @see #doSwitch(org.eclipse.emf.ecore.EObject) doSwitch(EObject)
	 * @generated
	 */
	public T caseDistributor(Distributor object) {
		return null;
	}

	/**
	 * Returns the result of interpreting the object as an instance of '<em>In House</em>'.
	 * <!-- begin-user-doc -->
	 * This implementation returns null;
	 * returning a non-null result will terminate the switch.
	 * <!-- end-user-doc -->
	 * @param object the target of the switch.
	 * @return the result of interpreting the object as an instance of '<em>In House</em>'.
	 * @see #doSwitch(org.eclipse.emf.ecore.EObject) doSwitch(EObject)
	 * @generated
	 */
	public T caseInHouse(InHouse object) {
		return null;
	}

	/**
	 * Returns the result of interpreting the object as an instance of '<em>Subscription Management</em>'.
	 * <!-- begin-user-doc -->
	 * This implementation returns null;
	 * returning a non-null result will terminate the switch.
	 * <!-- end-user-doc -->
	 * @param object the target of the switch.
	 * @return the result of interpreting the object as an instance of '<em>Subscription Management</em>'.
	 * @see #doSwitch(org.eclipse.emf.ecore.EObject) doSwitch(EObject)
	 * @generated
	 */
	public T caseSubscriptionManagement(SubscriptionManagement object) {
		return null;
	}

	/**
	 * Returns the result of interpreting the object as an instance of '<em>Accout</em>'.
	 * <!-- begin-user-doc -->
	 * This implementation returns null;
	 * returning a non-null result will terminate the switch.
	 * <!-- end-user-doc -->
	 * @param object the target of the switch.
	 * @return the result of interpreting the object as an instance of '<em>Accout</em>'.
	 * @see #doSwitch(org.eclipse.emf.ecore.EObject) doSwitch(EObject)
	 * @generated
	 */
	public T caseAccout(Accout object) {
		return null;
	}

	/**
	 * Returns the result of interpreting the object as an instance of '<em>Profile</em>'.
	 * <!-- begin-user-doc -->
	 * This implementation returns null;
	 * returning a non-null result will terminate the switch.
	 * <!-- end-user-doc -->
	 * @param object the target of the switch.
	 * @return the result of interpreting the object as an instance of '<em>Profile</em>'.
	 * @see #doSwitch(org.eclipse.emf.ecore.EObject) doSwitch(EObject)
	 * @generated
	 */
	public T caseProfile(Profile object) {
		return null;
	}

	/**
	 * Returns the result of interpreting the object as an instance of '<em>Favorite Queue</em>'.
	 * <!-- begin-user-doc -->
	 * This implementation returns null;
	 * returning a non-null result will terminate the switch.
	 * <!-- end-user-doc -->
	 * @param object the target of the switch.
	 * @return the result of interpreting the object as an instance of '<em>Favorite Queue</em>'.
	 * @see #doSwitch(org.eclipse.emf.ecore.EObject) doSwitch(EObject)
	 * @generated
	 */
	public T caseFavoriteQueue(FavoriteQueue object) {
		return null;
	}

	/**
	 * Returns the result of interpreting the object as an instance of '<em>Friend List</em>'.
	 * <!-- begin-user-doc -->
	 * This implementation returns null;
	 * returning a non-null result will terminate the switch.
	 * <!-- end-user-doc -->
	 * @param object the target of the switch.
	 * @return the result of interpreting the object as an instance of '<em>Friend List</em>'.
	 * @see #doSwitch(org.eclipse.emf.ecore.EObject) doSwitch(EObject)
	 * @generated
	 */
	public T caseFriendList(FriendList object) {
		return null;
	}

	/**
	 * Returns the result of interpreting the object as an instance of '<em>Review</em>'.
	 * <!-- begin-user-doc -->
	 * This implementation returns null;
	 * returning a non-null result will terminate the switch.
	 * <!-- end-user-doc -->
	 * @param object the target of the switch.
	 * @return the result of interpreting the object as an instance of '<em>Review</em>'.
	 * @see #doSwitch(org.eclipse.emf.ecore.EObject) doSwitch(EObject)
	 * @generated
	 */
	public T caseReview(Review object) {
		return null;
	}

	/**
	 * Returns the result of interpreting the object as an instance of '<em>Recommendation</em>'.
	 * <!-- begin-user-doc -->
	 * This implementation returns null;
	 * returning a non-null result will terminate the switch.
	 * <!-- end-user-doc -->
	 * @param object the target of the switch.
	 * @return the result of interpreting the object as an instance of '<em>Recommendation</em>'.
	 * @see #doSwitch(org.eclipse.emf.ecore.EObject) doSwitch(EObject)
	 * @generated
	 */
	public T caseRecommendation(Recommendation object) {
		return null;
	}

	/**
	 * Returns the result of interpreting the object as an instance of '<em>Stream Service</em>'.
	 * <!-- begin-user-doc -->
	 * This implementation returns null;
	 * returning a non-null result will terminate the switch.
	 * <!-- end-user-doc -->
	 * @param object the target of the switch.
	 * @return the result of interpreting the object as an instance of '<em>Stream Service</em>'.
	 * @see #doSwitch(org.eclipse.emf.ecore.EObject) doSwitch(EObject)
	 * @generated
	 */
	public T caseStreamService(StreamService object) {
		return null;
	}

	/**
	 * Returns the result of interpreting the object as an instance of '<em>Device</em>'.
	 * <!-- begin-user-doc -->
	 * This implementation returns null;
	 * returning a non-null result will terminate the switch.
	 * <!-- end-user-doc -->
	 * @param object the target of the switch.
	 * @return the result of interpreting the object as an instance of '<em>Device</em>'.
	 * @see #doSwitch(org.eclipse.emf.ecore.EObject) doSwitch(EObject)
	 * @generated
	 */
	public T caseDevice(Device object) {
		return null;
	}

	/**
	 * Returns the result of interpreting the object as an instance of '<em>Streaming Library</em>'.
	 * <!-- begin-user-doc -->
	 * This implementation returns null;
	 * returning a non-null result will terminate the switch.
	 * <!-- end-user-doc -->
	 * @param object the target of the switch.
	 * @return the result of interpreting the object as an instance of '<em>Streaming Library</em>'.
	 * @see #doSwitch(org.eclipse.emf.ecore.EObject) doSwitch(EObject)
	 * @generated
	 */
	public T caseStreamingLibrary(StreamingLibrary object) {
		return null;
	}

	/**
	 * Returns the result of interpreting the object as an instance of '<em>Service</em>'.
	 * <!-- begin-user-doc -->
	 * This implementation returns null;
	 * returning a non-null result will terminate the switch.
	 * <!-- end-user-doc -->
	 * @param object the target of the switch.
	 * @return the result of interpreting the object as an instance of '<em>Service</em>'.
	 * @see #doSwitch(org.eclipse.emf.ecore.EObject) doSwitch(EObject)
	 * @generated
	 */
	public T caseNetflixService(NetflixService object) {
		return null;
	}

	/**
	 * Returns the result of interpreting the object as an instance of '<em>EObject</em>'.
	 * <!-- begin-user-doc -->
	 * This implementation returns null;
	 * returning a non-null result will terminate the switch, but this is the last case anyway.
	 * <!-- end-user-doc -->
	 * @param object the target of the switch.
	 * @return the result of interpreting the object as an instance of '<em>EObject</em>'.
	 * @see #doSwitch(org.eclipse.emf.ecore.EObject)
	 * @generated
	 */
	@Override
	public T defaultCase(EObject object) {
		return null;
	}

} //NetflixSwitch
