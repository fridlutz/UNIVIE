/**
 */
package at.ac.univie.swa.ase2014.a0123456.task1.model.netflix.util;

import at.ac.univie.swa.ase2014.a0123456.task1.model.netflix.*;

import java.util.Map;

import org.eclipse.emf.common.util.Diagnostic;
import org.eclipse.emf.common.util.DiagnosticChain;
import org.eclipse.emf.common.util.ResourceLocator;

import org.eclipse.emf.ecore.EPackage;

import org.eclipse.emf.ecore.util.EObjectValidator;

/**
 * <!-- begin-user-doc -->
 * The <b>Validator</b> for the model.
 * <!-- end-user-doc -->
 * @see at.ac.univie.swa.ase2014.a0123456.task1.model.netflix.NetflixPackage
 * @generated
 */
public class NetflixValidator extends EObjectValidator {
	/**
	 * The cached model package
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public static final NetflixValidator INSTANCE = new NetflixValidator();

	/**
	 * A constant for the {@link org.eclipse.emf.common.util.Diagnostic#getSource() source} of diagnostic {@link org.eclipse.emf.common.util.Diagnostic#getCode() codes} from this package.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see org.eclipse.emf.common.util.Diagnostic#getSource()
	 * @see org.eclipse.emf.common.util.Diagnostic#getCode()
	 * @generated
	 */
	public static final String DIAGNOSTIC_SOURCE = "at.ac.univie.swa.ase2014.a0123456.task1.model.netflix";

	/**
	 * A constant with a fixed name that can be used as the base value for additional hand written constants.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private static final int GENERATED_DIAGNOSTIC_CODE_COUNT = 0;

	/**
	 * A constant with a fixed name that can be used as the base value for additional hand written constants in a derived class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected static final int DIAGNOSTIC_CODE_COUNT = GENERATED_DIAGNOSTIC_CODE_COUNT;

	/**
	 * Creates an instance of the switch.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public NetflixValidator() {
		super();
	}

	/**
	 * Returns the package of this validator switch.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected EPackage getEPackage() {
	  return NetflixPackage.eINSTANCE;
	}

	/**
	 * Calls <code>validateXXX</code> for the corresponding classifier of the model.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected boolean validate(int classifierID, Object value, DiagnosticChain diagnostics, Map<Object, Object> context) {
		switch (classifierID) {
			case NetflixPackage.MEDIA:
				return validateMedia((Media)value, diagnostics, context);
			case NetflixPackage.STREAMING_MEDIA:
				return validateStreamingMedia((StreamingMedia)value, diagnostics, context);
			case NetflixPackage.RENTAL_MEDIA:
				return validateRentalMedia((RentalMedia)value, diagnostics, context);
			case NetflixPackage.MOVIE:
				return validateMovie((Movie)value, diagnostics, context);
			case NetflixPackage.TV_SERIE:
				return validateTVSerie((TVSerie)value, diagnostics, context);
			case NetflixPackage.MUSIC:
				return validateMusic((Music)value, diagnostics, context);
			case NetflixPackage.DVD:
				return validateDVD((DVD)value, diagnostics, context);
			case NetflixPackage.BLUE_RAY:
				return validateBlueRay((BlueRay)value, diagnostics, context);
			case NetflixPackage.LICENSE_HOLDER:
				return validateLicenseHolder((LicenseHolder)value, diagnostics, context);
			case NetflixPackage.DISTRIBUTOR:
				return validateDistributor((Distributor)value, diagnostics, context);
			case NetflixPackage.IN_HOUSE:
				return validateInHouse((InHouse)value, diagnostics, context);
			case NetflixPackage.SUBSCRIPTION_MANAGEMENT:
				return validateSubscriptionManagement((SubscriptionManagement)value, diagnostics, context);
			case NetflixPackage.ACCOUT:
				return validateAccout((Accout)value, diagnostics, context);
			case NetflixPackage.PROFILE:
				return validateProfile((Profile)value, diagnostics, context);
			case NetflixPackage.FAVORITE_QUEUE:
				return validateFavoriteQueue((FavoriteQueue)value, diagnostics, context);
			case NetflixPackage.FRIEND_LIST:
				return validateFriendList((FriendList)value, diagnostics, context);
			case NetflixPackage.REVIEW:
				return validateReview((Review)value, diagnostics, context);
			case NetflixPackage.RECOMMENDATION:
				return validateRecommendation((Recommendation)value, diagnostics, context);
			case NetflixPackage.STREAM_SERVICE:
				return validateStreamService((StreamService)value, diagnostics, context);
			case NetflixPackage.DEVICE:
				return validateDevice((Device)value, diagnostics, context);
			case NetflixPackage.STREAMING_LIBRARY:
				return validateStreamingLibrary((StreamingLibrary)value, diagnostics, context);
			case NetflixPackage.NETFLIX_SERVICE:
				return validateNetflixService((NetflixService)value, diagnostics, context);
			default:
				return true;
		}
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public boolean validateMedia(Media media, DiagnosticChain diagnostics, Map<Object, Object> context) {
		return validate_EveryDefaultConstraint(media, diagnostics, context);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public boolean validateStreamingMedia(StreamingMedia streamingMedia, DiagnosticChain diagnostics, Map<Object, Object> context) {
		return validate_EveryDefaultConstraint(streamingMedia, diagnostics, context);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public boolean validateRentalMedia(RentalMedia rentalMedia, DiagnosticChain diagnostics, Map<Object, Object> context) {
		return validate_EveryDefaultConstraint(rentalMedia, diagnostics, context);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public boolean validateMovie(Movie movie, DiagnosticChain diagnostics, Map<Object, Object> context) {
		return validate_EveryDefaultConstraint(movie, diagnostics, context);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public boolean validateTVSerie(TVSerie tvSerie, DiagnosticChain diagnostics, Map<Object, Object> context) {
		return validate_EveryDefaultConstraint(tvSerie, diagnostics, context);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public boolean validateMusic(Music music, DiagnosticChain diagnostics, Map<Object, Object> context) {
		return validate_EveryDefaultConstraint(music, diagnostics, context);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public boolean validateDVD(DVD dvd, DiagnosticChain diagnostics, Map<Object, Object> context) {
		return validate_EveryDefaultConstraint(dvd, diagnostics, context);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public boolean validateBlueRay(BlueRay blueRay, DiagnosticChain diagnostics, Map<Object, Object> context) {
		return validate_EveryDefaultConstraint(blueRay, diagnostics, context);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public boolean validateLicenseHolder(LicenseHolder licenseHolder, DiagnosticChain diagnostics, Map<Object, Object> context) {
		return validate_EveryDefaultConstraint(licenseHolder, diagnostics, context);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public boolean validateDistributor(Distributor distributor, DiagnosticChain diagnostics, Map<Object, Object> context) {
		return validate_EveryDefaultConstraint(distributor, diagnostics, context);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public boolean validateInHouse(InHouse inHouse, DiagnosticChain diagnostics, Map<Object, Object> context) {
		return validate_EveryDefaultConstraint(inHouse, diagnostics, context);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public boolean validateSubscriptionManagement(SubscriptionManagement subscriptionManagement, DiagnosticChain diagnostics, Map<Object, Object> context) {
		return validate_EveryDefaultConstraint(subscriptionManagement, diagnostics, context);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public boolean validateAccout(Accout accout, DiagnosticChain diagnostics, Map<Object, Object> context) {
		if (!validate_NoCircularContainment(accout, diagnostics, context)) return false;
		boolean result = validate_EveryMultiplicityConforms(accout, diagnostics, context);
		if (result || diagnostics != null) result &= validate_EveryDataValueConforms(accout, diagnostics, context);
		if (result || diagnostics != null) result &= validate_EveryReferenceIsContained(accout, diagnostics, context);
		if (result || diagnostics != null) result &= validate_EveryBidirectionalReferenceIsPaired(accout, diagnostics, context);
		if (result || diagnostics != null) result &= validate_EveryProxyResolves(accout, diagnostics, context);
		if (result || diagnostics != null) result &= validate_UniqueID(accout, diagnostics, context);
		if (result || diagnostics != null) result &= validate_EveryKeyUnique(accout, diagnostics, context);
		if (result || diagnostics != null) result &= validate_EveryMapEntryUnique(accout, diagnostics, context);
		if (result || diagnostics != null) result &= validateAccout_mustHaveName(accout, diagnostics, context);
		return result;
	}

	/**
	 * The cached validation expression for the mustHaveName constraint of '<em>Accout</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected static final String ACCOUT__MUST_HAVE_NAME__EEXPRESSION = "not email.oclIsUndefined()";

	/**
	 * Validates the mustHaveName constraint of '<em>Accout</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public boolean validateAccout_mustHaveName(Accout accout, DiagnosticChain diagnostics, Map<Object, Object> context) {
		return
			validate
				(NetflixPackage.Literals.ACCOUT,
				 accout,
				 diagnostics,
				 context,
				 "http://www.eclipse.org/emf/2002/Ecore/OCL/Pivot",
				 "mustHaveName",
				 ACCOUT__MUST_HAVE_NAME__EEXPRESSION,
				 Diagnostic.ERROR,
				 DIAGNOSTIC_SOURCE,
				 0);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public boolean validateProfile(Profile profile, DiagnosticChain diagnostics, Map<Object, Object> context) {
		return validate_EveryDefaultConstraint(profile, diagnostics, context);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public boolean validateFavoriteQueue(FavoriteQueue favoriteQueue, DiagnosticChain diagnostics, Map<Object, Object> context) {
		return validate_EveryDefaultConstraint(favoriteQueue, diagnostics, context);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public boolean validateFriendList(FriendList friendList, DiagnosticChain diagnostics, Map<Object, Object> context) {
		return validate_EveryDefaultConstraint(friendList, diagnostics, context);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public boolean validateReview(Review review, DiagnosticChain diagnostics, Map<Object, Object> context) {
		return validate_EveryDefaultConstraint(review, diagnostics, context);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public boolean validateRecommendation(Recommendation recommendation, DiagnosticChain diagnostics, Map<Object, Object> context) {
		return validate_EveryDefaultConstraint(recommendation, diagnostics, context);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public boolean validateStreamService(StreamService streamService, DiagnosticChain diagnostics, Map<Object, Object> context) {
		return validate_EveryDefaultConstraint(streamService, diagnostics, context);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public boolean validateDevice(Device device, DiagnosticChain diagnostics, Map<Object, Object> context) {
		return validate_EveryDefaultConstraint(device, diagnostics, context);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public boolean validateStreamingLibrary(StreamingLibrary streamingLibrary, DiagnosticChain diagnostics, Map<Object, Object> context) {
		return validate_EveryDefaultConstraint(streamingLibrary, diagnostics, context);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public boolean validateNetflixService(NetflixService netflixService, DiagnosticChain diagnostics, Map<Object, Object> context) {
		return validate_EveryDefaultConstraint(netflixService, diagnostics, context);
	}

	/**
	 * Returns the resource locator that will be used to fetch messages for this validator's diagnostics.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public ResourceLocator getResourceLocator() {
		// TODO
		// Specialize this to return a resource locator for messages specific to this validator.
		// Ensure that you remove @generated or mark it @generated NOT
		return super.getResourceLocator();
	}

} //NetflixValidator
