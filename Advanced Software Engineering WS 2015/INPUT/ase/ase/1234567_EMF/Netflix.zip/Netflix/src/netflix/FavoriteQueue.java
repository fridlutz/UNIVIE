/**
 */
package netflix;

import org.eclipse.emf.common.util.EList;

import org.eclipse.emf.ecore.EObject;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Favorite Queue</b></em>'.
 * <!-- end-user-doc -->
 *
 * <p>
 * The following features are supported:
 * <ul>
 *   <li>{@link netflix.FavoriteQueue#getMedien <em>Medien</em>}</li>
 * </ul>
 * </p>
 *
 * @see netflix.NetflixPackage#getFavoriteQueue()
 * @model
 * @generated
 */
public interface FavoriteQueue extends EObject {
	/**
	 * Returns the value of the '<em><b>Medien</b></em>' reference list.
	 * The list contents are of type {@link netflix.Media}.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Medien</em>' reference list isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Medien</em>' reference list.
	 * @see netflix.NetflixPackage#getFavoriteQueue_Medien()
	 * @model
	 * @generated
	 */
	EList<Media> getMedien();

} // FavoriteQueue
