/**
 */
package at.ac.univie.swa.ase2014.a0123456.task1.model.netflix;


/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>In House</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see at.ac.univie.swa.ase2014.a0123456.task1.model.netflix.NetflixPackage#getInHouse()
 * @model
 * @generated
 */
public interface InHouse extends LicenseHolder {
} // InHouse
