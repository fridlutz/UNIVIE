/**
 */
package netflix;


/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>DVD</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see netflix.NetflixPackage#getDVD()
 * @model
 * @generated
 */
public interface DVD extends RentalMedia {
} // DVD
