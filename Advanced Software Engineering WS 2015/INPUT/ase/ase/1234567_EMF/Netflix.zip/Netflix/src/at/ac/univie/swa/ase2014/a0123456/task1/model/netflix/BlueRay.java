/**
 */
package at.ac.univie.swa.ase2014.a0123456.task1.model.netflix;


/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Blue Ray</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see at.ac.univie.swa.ase2014.a0123456.task1.model.netflix.NetflixPackage#getBlueRay()
 * @model
 * @generated
 */
public interface BlueRay extends RentalMedia {
} // BlueRay
