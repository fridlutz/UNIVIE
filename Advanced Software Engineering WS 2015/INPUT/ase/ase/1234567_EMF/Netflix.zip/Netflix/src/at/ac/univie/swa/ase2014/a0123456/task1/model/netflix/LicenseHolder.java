/**
 */
package at.ac.univie.swa.ase2014.a0123456.task1.model.netflix;

import org.eclipse.emf.common.util.EList;

import org.eclipse.emf.ecore.EObject;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>License Holder</b></em>'.
 * <!-- end-user-doc -->
 *
 * <p>
 * The following features are supported:
 * <ul>
 *   <li>{@link at.ac.univie.swa.ase2014.a0123456.task1.model.netflix.LicenseHolder#getMedien <em>Medien</em>}</li>
 * </ul>
 * </p>
 *
 * @see at.ac.univie.swa.ase2014.a0123456.task1.model.netflix.NetflixPackage#getLicenseHolder()
 * @model abstract="true"
 * @generated
 */
public interface LicenseHolder extends EObject {
	/**
	 * Returns the value of the '<em><b>Medien</b></em>' reference list.
	 * The list contents are of type {@link at.ac.univie.swa.ase2014.a0123456.task1.model.netflix.Media}.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Medien</em>' reference list isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Medien</em>' reference list.
	 * @see at.ac.univie.swa.ase2014.a0123456.task1.model.netflix.NetflixPackage#getLicenseHolder_Medien()
	 * @model
	 * @generated
	 */
	EList<Media> getMedien();

} // LicenseHolder
