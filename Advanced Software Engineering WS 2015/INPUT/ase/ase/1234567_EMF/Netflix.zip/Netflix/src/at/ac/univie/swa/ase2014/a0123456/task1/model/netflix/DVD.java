/**
 */
package at.ac.univie.swa.ase2014.a0123456.task1.model.netflix;


/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>DVD</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see at.ac.univie.swa.ase2014.a0123456.task1.model.netflix.NetflixPackage#getDVD()
 * @model
 * @generated
 */
public interface DVD extends RentalMedia {
} // DVD
