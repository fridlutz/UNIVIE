package at.ac.univie.swa.ase2014.a1276754.task3.ui.contentassist.antlr.internal; 

import java.io.InputStream;
import org.eclipse.xtext.*;
import org.eclipse.xtext.parser.*;
import org.eclipse.xtext.parser.impl.*;
import org.eclipse.emf.ecore.util.EcoreUtil;
import org.eclipse.emf.ecore.EObject;
import org.eclipse.xtext.parser.antlr.XtextTokenStream;
import org.eclipse.xtext.parser.antlr.XtextTokenStream.HiddenTokens;
import org.eclipse.xtext.ui.editor.contentassist.antlr.internal.AbstractInternalContentAssistParser;
import org.eclipse.xtext.ui.editor.contentassist.antlr.internal.DFA;
import at.ac.univie.swa.ase2014.a1276754.task3.services.MydslGrammarAccess;



import org.antlr.runtime.*;
import java.util.Stack;
import java.util.List;
import java.util.ArrayList;

@SuppressWarnings("all")
public class InternalMydslParser extends AbstractInternalContentAssistParser {
    public static final String[] tokenNames = new String[] {
        "<invalid>", "<EOR>", "<DOWN>", "<UP>", "RULE_INT", "RULE_ID", "RULE_STRING", "RULE_ML_COMMENT", "RULE_SL_COMMENT", "RULE_WS", "RULE_ANY_OTHER", "'POP'", "'ROCK'", "'HARDROCK'", "'CLASSIC'", "'FOLK'", "'OTHER'", "'Distributors:'", "'Library:'", "'Playlists:'", "'Address:'", "'Account Information:'", "'IBAN:'", "'BIC:'", "'sung by'", "'produced by'", "'length:'", "'genre:'", "'price:'", "':'", "'.'", "' consists of'", "','", "'Playlist'", "'without'"
    };
    public static final int RULE_STRING=6;
    public static final int RULE_SL_COMMENT=8;
    public static final int T__19=19;
    public static final int T__15=15;
    public static final int T__16=16;
    public static final int T__17=17;
    public static final int T__18=18;
    public static final int T__11=11;
    public static final int T__33=33;
    public static final int T__12=12;
    public static final int T__34=34;
    public static final int T__13=13;
    public static final int T__14=14;
    public static final int EOF=-1;
    public static final int T__30=30;
    public static final int T__31=31;
    public static final int T__32=32;
    public static final int RULE_ID=5;
    public static final int RULE_WS=9;
    public static final int RULE_ANY_OTHER=10;
    public static final int T__26=26;
    public static final int T__27=27;
    public static final int T__28=28;
    public static final int RULE_INT=4;
    public static final int T__29=29;
    public static final int T__22=22;
    public static final int RULE_ML_COMMENT=7;
    public static final int T__23=23;
    public static final int T__24=24;
    public static final int T__25=25;
    public static final int T__20=20;
    public static final int T__21=21;

    // delegates
    // delegators


        public InternalMydslParser(TokenStream input) {
            this(input, new RecognizerSharedState());
        }
        public InternalMydslParser(TokenStream input, RecognizerSharedState state) {
            super(input, state);
             
        }
        

    public String[] getTokenNames() { return InternalMydslParser.tokenNames; }
    public String getGrammarFileName() { return "../at.ac.univie.swa.ase2014.a1276754.task3.mydsl.ui/src-gen/at/ac/univie/swa/ase2014/a1276754/task3/ui/contentassist/antlr/internal/InternalMydsl.g"; }


     
     	private MydslGrammarAccess grammarAccess;
     	
        public void setGrammarAccess(MydslGrammarAccess grammarAccess) {
        	this.grammarAccess = grammarAccess;
        }
        
        @Override
        protected Grammar getGrammar() {
        	return grammarAccess.getGrammar();
        }
        
        @Override
        protected String getValueForTokenName(String tokenName) {
        	return tokenName;
        }




    // $ANTLR start "entryRuleModel"
    // ../at.ac.univie.swa.ase2014.a1276754.task3.mydsl.ui/src-gen/at/ac/univie/swa/ase2014/a1276754/task3/ui/contentassist/antlr/internal/InternalMydsl.g:60:1: entryRuleModel : ruleModel EOF ;
    public final void entryRuleModel() throws RecognitionException {
        try {
            // ../at.ac.univie.swa.ase2014.a1276754.task3.mydsl.ui/src-gen/at/ac/univie/swa/ase2014/a1276754/task3/ui/contentassist/antlr/internal/InternalMydsl.g:61:1: ( ruleModel EOF )
            // ../at.ac.univie.swa.ase2014.a1276754.task3.mydsl.ui/src-gen/at/ac/univie/swa/ase2014/a1276754/task3/ui/contentassist/antlr/internal/InternalMydsl.g:62:1: ruleModel EOF
            {
             before(grammarAccess.getModelRule()); 
            pushFollow(FOLLOW_ruleModel_in_entryRuleModel61);
            ruleModel();

            state._fsp--;

             after(grammarAccess.getModelRule()); 
            match(input,EOF,FOLLOW_EOF_in_entryRuleModel68); 

            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {
        }
        return ;
    }
    // $ANTLR end "entryRuleModel"


    // $ANTLR start "ruleModel"
    // ../at.ac.univie.swa.ase2014.a1276754.task3.mydsl.ui/src-gen/at/ac/univie/swa/ase2014/a1276754/task3/ui/contentassist/antlr/internal/InternalMydsl.g:69:1: ruleModel : ( ( rule__Model__Group__0 ) ) ;
    public final void ruleModel() throws RecognitionException {

        		int stackSize = keepStackSize();
            
        try {
            // ../at.ac.univie.swa.ase2014.a1276754.task3.mydsl.ui/src-gen/at/ac/univie/swa/ase2014/a1276754/task3/ui/contentassist/antlr/internal/InternalMydsl.g:73:2: ( ( ( rule__Model__Group__0 ) ) )
            // ../at.ac.univie.swa.ase2014.a1276754.task3.mydsl.ui/src-gen/at/ac/univie/swa/ase2014/a1276754/task3/ui/contentassist/antlr/internal/InternalMydsl.g:74:1: ( ( rule__Model__Group__0 ) )
            {
            // ../at.ac.univie.swa.ase2014.a1276754.task3.mydsl.ui/src-gen/at/ac/univie/swa/ase2014/a1276754/task3/ui/contentassist/antlr/internal/InternalMydsl.g:74:1: ( ( rule__Model__Group__0 ) )
            // ../at.ac.univie.swa.ase2014.a1276754.task3.mydsl.ui/src-gen/at/ac/univie/swa/ase2014/a1276754/task3/ui/contentassist/antlr/internal/InternalMydsl.g:75:1: ( rule__Model__Group__0 )
            {
             before(grammarAccess.getModelAccess().getGroup()); 
            // ../at.ac.univie.swa.ase2014.a1276754.task3.mydsl.ui/src-gen/at/ac/univie/swa/ase2014/a1276754/task3/ui/contentassist/antlr/internal/InternalMydsl.g:76:1: ( rule__Model__Group__0 )
            // ../at.ac.univie.swa.ase2014.a1276754.task3.mydsl.ui/src-gen/at/ac/univie/swa/ase2014/a1276754/task3/ui/contentassist/antlr/internal/InternalMydsl.g:76:2: rule__Model__Group__0
            {
            pushFollow(FOLLOW_rule__Model__Group__0_in_ruleModel94);
            rule__Model__Group__0();

            state._fsp--;


            }

             after(grammarAccess.getModelAccess().getGroup()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "ruleModel"


    // $ANTLR start "entryRuleDistributor"
    // ../at.ac.univie.swa.ase2014.a1276754.task3.mydsl.ui/src-gen/at/ac/univie/swa/ase2014/a1276754/task3/ui/contentassist/antlr/internal/InternalMydsl.g:88:1: entryRuleDistributor : ruleDistributor EOF ;
    public final void entryRuleDistributor() throws RecognitionException {
        try {
            // ../at.ac.univie.swa.ase2014.a1276754.task3.mydsl.ui/src-gen/at/ac/univie/swa/ase2014/a1276754/task3/ui/contentassist/antlr/internal/InternalMydsl.g:89:1: ( ruleDistributor EOF )
            // ../at.ac.univie.swa.ase2014.a1276754.task3.mydsl.ui/src-gen/at/ac/univie/swa/ase2014/a1276754/task3/ui/contentassist/antlr/internal/InternalMydsl.g:90:1: ruleDistributor EOF
            {
             before(grammarAccess.getDistributorRule()); 
            pushFollow(FOLLOW_ruleDistributor_in_entryRuleDistributor121);
            ruleDistributor();

            state._fsp--;

             after(grammarAccess.getDistributorRule()); 
            match(input,EOF,FOLLOW_EOF_in_entryRuleDistributor128); 

            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {
        }
        return ;
    }
    // $ANTLR end "entryRuleDistributor"


    // $ANTLR start "ruleDistributor"
    // ../at.ac.univie.swa.ase2014.a1276754.task3.mydsl.ui/src-gen/at/ac/univie/swa/ase2014/a1276754/task3/ui/contentassist/antlr/internal/InternalMydsl.g:97:1: ruleDistributor : ( ( rule__Distributor__Group__0 ) ) ;
    public final void ruleDistributor() throws RecognitionException {

        		int stackSize = keepStackSize();
            
        try {
            // ../at.ac.univie.swa.ase2014.a1276754.task3.mydsl.ui/src-gen/at/ac/univie/swa/ase2014/a1276754/task3/ui/contentassist/antlr/internal/InternalMydsl.g:101:2: ( ( ( rule__Distributor__Group__0 ) ) )
            // ../at.ac.univie.swa.ase2014.a1276754.task3.mydsl.ui/src-gen/at/ac/univie/swa/ase2014/a1276754/task3/ui/contentassist/antlr/internal/InternalMydsl.g:102:1: ( ( rule__Distributor__Group__0 ) )
            {
            // ../at.ac.univie.swa.ase2014.a1276754.task3.mydsl.ui/src-gen/at/ac/univie/swa/ase2014/a1276754/task3/ui/contentassist/antlr/internal/InternalMydsl.g:102:1: ( ( rule__Distributor__Group__0 ) )
            // ../at.ac.univie.swa.ase2014.a1276754.task3.mydsl.ui/src-gen/at/ac/univie/swa/ase2014/a1276754/task3/ui/contentassist/antlr/internal/InternalMydsl.g:103:1: ( rule__Distributor__Group__0 )
            {
             before(grammarAccess.getDistributorAccess().getGroup()); 
            // ../at.ac.univie.swa.ase2014.a1276754.task3.mydsl.ui/src-gen/at/ac/univie/swa/ase2014/a1276754/task3/ui/contentassist/antlr/internal/InternalMydsl.g:104:1: ( rule__Distributor__Group__0 )
            // ../at.ac.univie.swa.ase2014.a1276754.task3.mydsl.ui/src-gen/at/ac/univie/swa/ase2014/a1276754/task3/ui/contentassist/antlr/internal/InternalMydsl.g:104:2: rule__Distributor__Group__0
            {
            pushFollow(FOLLOW_rule__Distributor__Group__0_in_ruleDistributor154);
            rule__Distributor__Group__0();

            state._fsp--;


            }

             after(grammarAccess.getDistributorAccess().getGroup()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "ruleDistributor"


    // $ANTLR start "entryRuleAccount_Information"
    // ../at.ac.univie.swa.ase2014.a1276754.task3.mydsl.ui/src-gen/at/ac/univie/swa/ase2014/a1276754/task3/ui/contentassist/antlr/internal/InternalMydsl.g:116:1: entryRuleAccount_Information : ruleAccount_Information EOF ;
    public final void entryRuleAccount_Information() throws RecognitionException {
        try {
            // ../at.ac.univie.swa.ase2014.a1276754.task3.mydsl.ui/src-gen/at/ac/univie/swa/ase2014/a1276754/task3/ui/contentassist/antlr/internal/InternalMydsl.g:117:1: ( ruleAccount_Information EOF )
            // ../at.ac.univie.swa.ase2014.a1276754.task3.mydsl.ui/src-gen/at/ac/univie/swa/ase2014/a1276754/task3/ui/contentassist/antlr/internal/InternalMydsl.g:118:1: ruleAccount_Information EOF
            {
             before(grammarAccess.getAccount_InformationRule()); 
            pushFollow(FOLLOW_ruleAccount_Information_in_entryRuleAccount_Information181);
            ruleAccount_Information();

            state._fsp--;

             after(grammarAccess.getAccount_InformationRule()); 
            match(input,EOF,FOLLOW_EOF_in_entryRuleAccount_Information188); 

            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {
        }
        return ;
    }
    // $ANTLR end "entryRuleAccount_Information"


    // $ANTLR start "ruleAccount_Information"
    // ../at.ac.univie.swa.ase2014.a1276754.task3.mydsl.ui/src-gen/at/ac/univie/swa/ase2014/a1276754/task3/ui/contentassist/antlr/internal/InternalMydsl.g:125:1: ruleAccount_Information : ( ( rule__Account_Information__Group__0 ) ) ;
    public final void ruleAccount_Information() throws RecognitionException {

        		int stackSize = keepStackSize();
            
        try {
            // ../at.ac.univie.swa.ase2014.a1276754.task3.mydsl.ui/src-gen/at/ac/univie/swa/ase2014/a1276754/task3/ui/contentassist/antlr/internal/InternalMydsl.g:129:2: ( ( ( rule__Account_Information__Group__0 ) ) )
            // ../at.ac.univie.swa.ase2014.a1276754.task3.mydsl.ui/src-gen/at/ac/univie/swa/ase2014/a1276754/task3/ui/contentassist/antlr/internal/InternalMydsl.g:130:1: ( ( rule__Account_Information__Group__0 ) )
            {
            // ../at.ac.univie.swa.ase2014.a1276754.task3.mydsl.ui/src-gen/at/ac/univie/swa/ase2014/a1276754/task3/ui/contentassist/antlr/internal/InternalMydsl.g:130:1: ( ( rule__Account_Information__Group__0 ) )
            // ../at.ac.univie.swa.ase2014.a1276754.task3.mydsl.ui/src-gen/at/ac/univie/swa/ase2014/a1276754/task3/ui/contentassist/antlr/internal/InternalMydsl.g:131:1: ( rule__Account_Information__Group__0 )
            {
             before(grammarAccess.getAccount_InformationAccess().getGroup()); 
            // ../at.ac.univie.swa.ase2014.a1276754.task3.mydsl.ui/src-gen/at/ac/univie/swa/ase2014/a1276754/task3/ui/contentassist/antlr/internal/InternalMydsl.g:132:1: ( rule__Account_Information__Group__0 )
            // ../at.ac.univie.swa.ase2014.a1276754.task3.mydsl.ui/src-gen/at/ac/univie/swa/ase2014/a1276754/task3/ui/contentassist/antlr/internal/InternalMydsl.g:132:2: rule__Account_Information__Group__0
            {
            pushFollow(FOLLOW_rule__Account_Information__Group__0_in_ruleAccount_Information214);
            rule__Account_Information__Group__0();

            state._fsp--;


            }

             after(grammarAccess.getAccount_InformationAccess().getGroup()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "ruleAccount_Information"


    // $ANTLR start "entryRuleSong"
    // ../at.ac.univie.swa.ase2014.a1276754.task3.mydsl.ui/src-gen/at/ac/univie/swa/ase2014/a1276754/task3/ui/contentassist/antlr/internal/InternalMydsl.g:144:1: entryRuleSong : ruleSong EOF ;
    public final void entryRuleSong() throws RecognitionException {
        try {
            // ../at.ac.univie.swa.ase2014.a1276754.task3.mydsl.ui/src-gen/at/ac/univie/swa/ase2014/a1276754/task3/ui/contentassist/antlr/internal/InternalMydsl.g:145:1: ( ruleSong EOF )
            // ../at.ac.univie.swa.ase2014.a1276754.task3.mydsl.ui/src-gen/at/ac/univie/swa/ase2014/a1276754/task3/ui/contentassist/antlr/internal/InternalMydsl.g:146:1: ruleSong EOF
            {
             before(grammarAccess.getSongRule()); 
            pushFollow(FOLLOW_ruleSong_in_entryRuleSong241);
            ruleSong();

            state._fsp--;

             after(grammarAccess.getSongRule()); 
            match(input,EOF,FOLLOW_EOF_in_entryRuleSong248); 

            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {
        }
        return ;
    }
    // $ANTLR end "entryRuleSong"


    // $ANTLR start "ruleSong"
    // ../at.ac.univie.swa.ase2014.a1276754.task3.mydsl.ui/src-gen/at/ac/univie/swa/ase2014/a1276754/task3/ui/contentassist/antlr/internal/InternalMydsl.g:153:1: ruleSong : ( ( rule__Song__Group__0 ) ) ;
    public final void ruleSong() throws RecognitionException {

        		int stackSize = keepStackSize();
            
        try {
            // ../at.ac.univie.swa.ase2014.a1276754.task3.mydsl.ui/src-gen/at/ac/univie/swa/ase2014/a1276754/task3/ui/contentassist/antlr/internal/InternalMydsl.g:157:2: ( ( ( rule__Song__Group__0 ) ) )
            // ../at.ac.univie.swa.ase2014.a1276754.task3.mydsl.ui/src-gen/at/ac/univie/swa/ase2014/a1276754/task3/ui/contentassist/antlr/internal/InternalMydsl.g:158:1: ( ( rule__Song__Group__0 ) )
            {
            // ../at.ac.univie.swa.ase2014.a1276754.task3.mydsl.ui/src-gen/at/ac/univie/swa/ase2014/a1276754/task3/ui/contentassist/antlr/internal/InternalMydsl.g:158:1: ( ( rule__Song__Group__0 ) )
            // ../at.ac.univie.swa.ase2014.a1276754.task3.mydsl.ui/src-gen/at/ac/univie/swa/ase2014/a1276754/task3/ui/contentassist/antlr/internal/InternalMydsl.g:159:1: ( rule__Song__Group__0 )
            {
             before(grammarAccess.getSongAccess().getGroup()); 
            // ../at.ac.univie.swa.ase2014.a1276754.task3.mydsl.ui/src-gen/at/ac/univie/swa/ase2014/a1276754/task3/ui/contentassist/antlr/internal/InternalMydsl.g:160:1: ( rule__Song__Group__0 )
            // ../at.ac.univie.swa.ase2014.a1276754.task3.mydsl.ui/src-gen/at/ac/univie/swa/ase2014/a1276754/task3/ui/contentassist/antlr/internal/InternalMydsl.g:160:2: rule__Song__Group__0
            {
            pushFollow(FOLLOW_rule__Song__Group__0_in_ruleSong274);
            rule__Song__Group__0();

            state._fsp--;


            }

             after(grammarAccess.getSongAccess().getGroup()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "ruleSong"


    // $ANTLR start "entryRuleTime"
    // ../at.ac.univie.swa.ase2014.a1276754.task3.mydsl.ui/src-gen/at/ac/univie/swa/ase2014/a1276754/task3/ui/contentassist/antlr/internal/InternalMydsl.g:172:1: entryRuleTime : ruleTime EOF ;
    public final void entryRuleTime() throws RecognitionException {
        try {
            // ../at.ac.univie.swa.ase2014.a1276754.task3.mydsl.ui/src-gen/at/ac/univie/swa/ase2014/a1276754/task3/ui/contentassist/antlr/internal/InternalMydsl.g:173:1: ( ruleTime EOF )
            // ../at.ac.univie.swa.ase2014.a1276754.task3.mydsl.ui/src-gen/at/ac/univie/swa/ase2014/a1276754/task3/ui/contentassist/antlr/internal/InternalMydsl.g:174:1: ruleTime EOF
            {
             before(grammarAccess.getTimeRule()); 
            pushFollow(FOLLOW_ruleTime_in_entryRuleTime301);
            ruleTime();

            state._fsp--;

             after(grammarAccess.getTimeRule()); 
            match(input,EOF,FOLLOW_EOF_in_entryRuleTime308); 

            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {
        }
        return ;
    }
    // $ANTLR end "entryRuleTime"


    // $ANTLR start "ruleTime"
    // ../at.ac.univie.swa.ase2014.a1276754.task3.mydsl.ui/src-gen/at/ac/univie/swa/ase2014/a1276754/task3/ui/contentassist/antlr/internal/InternalMydsl.g:181:1: ruleTime : ( ( rule__Time__Group__0 ) ) ;
    public final void ruleTime() throws RecognitionException {

        		int stackSize = keepStackSize();
            
        try {
            // ../at.ac.univie.swa.ase2014.a1276754.task3.mydsl.ui/src-gen/at/ac/univie/swa/ase2014/a1276754/task3/ui/contentassist/antlr/internal/InternalMydsl.g:185:2: ( ( ( rule__Time__Group__0 ) ) )
            // ../at.ac.univie.swa.ase2014.a1276754.task3.mydsl.ui/src-gen/at/ac/univie/swa/ase2014/a1276754/task3/ui/contentassist/antlr/internal/InternalMydsl.g:186:1: ( ( rule__Time__Group__0 ) )
            {
            // ../at.ac.univie.swa.ase2014.a1276754.task3.mydsl.ui/src-gen/at/ac/univie/swa/ase2014/a1276754/task3/ui/contentassist/antlr/internal/InternalMydsl.g:186:1: ( ( rule__Time__Group__0 ) )
            // ../at.ac.univie.swa.ase2014.a1276754.task3.mydsl.ui/src-gen/at/ac/univie/swa/ase2014/a1276754/task3/ui/contentassist/antlr/internal/InternalMydsl.g:187:1: ( rule__Time__Group__0 )
            {
             before(grammarAccess.getTimeAccess().getGroup()); 
            // ../at.ac.univie.swa.ase2014.a1276754.task3.mydsl.ui/src-gen/at/ac/univie/swa/ase2014/a1276754/task3/ui/contentassist/antlr/internal/InternalMydsl.g:188:1: ( rule__Time__Group__0 )
            // ../at.ac.univie.swa.ase2014.a1276754.task3.mydsl.ui/src-gen/at/ac/univie/swa/ase2014/a1276754/task3/ui/contentassist/antlr/internal/InternalMydsl.g:188:2: rule__Time__Group__0
            {
            pushFollow(FOLLOW_rule__Time__Group__0_in_ruleTime334);
            rule__Time__Group__0();

            state._fsp--;


            }

             after(grammarAccess.getTimeAccess().getGroup()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "ruleTime"


    // $ANTLR start "entryRuleDouble"
    // ../at.ac.univie.swa.ase2014.a1276754.task3.mydsl.ui/src-gen/at/ac/univie/swa/ase2014/a1276754/task3/ui/contentassist/antlr/internal/InternalMydsl.g:200:1: entryRuleDouble : ruleDouble EOF ;
    public final void entryRuleDouble() throws RecognitionException {
        try {
            // ../at.ac.univie.swa.ase2014.a1276754.task3.mydsl.ui/src-gen/at/ac/univie/swa/ase2014/a1276754/task3/ui/contentassist/antlr/internal/InternalMydsl.g:201:1: ( ruleDouble EOF )
            // ../at.ac.univie.swa.ase2014.a1276754.task3.mydsl.ui/src-gen/at/ac/univie/swa/ase2014/a1276754/task3/ui/contentassist/antlr/internal/InternalMydsl.g:202:1: ruleDouble EOF
            {
             before(grammarAccess.getDoubleRule()); 
            pushFollow(FOLLOW_ruleDouble_in_entryRuleDouble361);
            ruleDouble();

            state._fsp--;

             after(grammarAccess.getDoubleRule()); 
            match(input,EOF,FOLLOW_EOF_in_entryRuleDouble368); 

            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {
        }
        return ;
    }
    // $ANTLR end "entryRuleDouble"


    // $ANTLR start "ruleDouble"
    // ../at.ac.univie.swa.ase2014.a1276754.task3.mydsl.ui/src-gen/at/ac/univie/swa/ase2014/a1276754/task3/ui/contentassist/antlr/internal/InternalMydsl.g:209:1: ruleDouble : ( ( rule__Double__Group__0 ) ) ;
    public final void ruleDouble() throws RecognitionException {

        		int stackSize = keepStackSize();
            
        try {
            // ../at.ac.univie.swa.ase2014.a1276754.task3.mydsl.ui/src-gen/at/ac/univie/swa/ase2014/a1276754/task3/ui/contentassist/antlr/internal/InternalMydsl.g:213:2: ( ( ( rule__Double__Group__0 ) ) )
            // ../at.ac.univie.swa.ase2014.a1276754.task3.mydsl.ui/src-gen/at/ac/univie/swa/ase2014/a1276754/task3/ui/contentassist/antlr/internal/InternalMydsl.g:214:1: ( ( rule__Double__Group__0 ) )
            {
            // ../at.ac.univie.swa.ase2014.a1276754.task3.mydsl.ui/src-gen/at/ac/univie/swa/ase2014/a1276754/task3/ui/contentassist/antlr/internal/InternalMydsl.g:214:1: ( ( rule__Double__Group__0 ) )
            // ../at.ac.univie.swa.ase2014.a1276754.task3.mydsl.ui/src-gen/at/ac/univie/swa/ase2014/a1276754/task3/ui/contentassist/antlr/internal/InternalMydsl.g:215:1: ( rule__Double__Group__0 )
            {
             before(grammarAccess.getDoubleAccess().getGroup()); 
            // ../at.ac.univie.swa.ase2014.a1276754.task3.mydsl.ui/src-gen/at/ac/univie/swa/ase2014/a1276754/task3/ui/contentassist/antlr/internal/InternalMydsl.g:216:1: ( rule__Double__Group__0 )
            // ../at.ac.univie.swa.ase2014.a1276754.task3.mydsl.ui/src-gen/at/ac/univie/swa/ase2014/a1276754/task3/ui/contentassist/antlr/internal/InternalMydsl.g:216:2: rule__Double__Group__0
            {
            pushFollow(FOLLOW_rule__Double__Group__0_in_ruleDouble394);
            rule__Double__Group__0();

            state._fsp--;


            }

             after(grammarAccess.getDoubleAccess().getGroup()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "ruleDouble"


    // $ANTLR start "entryRulePlaylist"
    // ../at.ac.univie.swa.ase2014.a1276754.task3.mydsl.ui/src-gen/at/ac/univie/swa/ase2014/a1276754/task3/ui/contentassist/antlr/internal/InternalMydsl.g:228:1: entryRulePlaylist : rulePlaylist EOF ;
    public final void entryRulePlaylist() throws RecognitionException {
        try {
            // ../at.ac.univie.swa.ase2014.a1276754.task3.mydsl.ui/src-gen/at/ac/univie/swa/ase2014/a1276754/task3/ui/contentassist/antlr/internal/InternalMydsl.g:229:1: ( rulePlaylist EOF )
            // ../at.ac.univie.swa.ase2014.a1276754.task3.mydsl.ui/src-gen/at/ac/univie/swa/ase2014/a1276754/task3/ui/contentassist/antlr/internal/InternalMydsl.g:230:1: rulePlaylist EOF
            {
             before(grammarAccess.getPlaylistRule()); 
            pushFollow(FOLLOW_rulePlaylist_in_entryRulePlaylist421);
            rulePlaylist();

            state._fsp--;

             after(grammarAccess.getPlaylistRule()); 
            match(input,EOF,FOLLOW_EOF_in_entryRulePlaylist428); 

            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {
        }
        return ;
    }
    // $ANTLR end "entryRulePlaylist"


    // $ANTLR start "rulePlaylist"
    // ../at.ac.univie.swa.ase2014.a1276754.task3.mydsl.ui/src-gen/at/ac/univie/swa/ase2014/a1276754/task3/ui/contentassist/antlr/internal/InternalMydsl.g:237:1: rulePlaylist : ( ( rule__Playlist__Group__0 ) ) ;
    public final void rulePlaylist() throws RecognitionException {

        		int stackSize = keepStackSize();
            
        try {
            // ../at.ac.univie.swa.ase2014.a1276754.task3.mydsl.ui/src-gen/at/ac/univie/swa/ase2014/a1276754/task3/ui/contentassist/antlr/internal/InternalMydsl.g:241:2: ( ( ( rule__Playlist__Group__0 ) ) )
            // ../at.ac.univie.swa.ase2014.a1276754.task3.mydsl.ui/src-gen/at/ac/univie/swa/ase2014/a1276754/task3/ui/contentassist/antlr/internal/InternalMydsl.g:242:1: ( ( rule__Playlist__Group__0 ) )
            {
            // ../at.ac.univie.swa.ase2014.a1276754.task3.mydsl.ui/src-gen/at/ac/univie/swa/ase2014/a1276754/task3/ui/contentassist/antlr/internal/InternalMydsl.g:242:1: ( ( rule__Playlist__Group__0 ) )
            // ../at.ac.univie.swa.ase2014.a1276754.task3.mydsl.ui/src-gen/at/ac/univie/swa/ase2014/a1276754/task3/ui/contentassist/antlr/internal/InternalMydsl.g:243:1: ( rule__Playlist__Group__0 )
            {
             before(grammarAccess.getPlaylistAccess().getGroup()); 
            // ../at.ac.univie.swa.ase2014.a1276754.task3.mydsl.ui/src-gen/at/ac/univie/swa/ase2014/a1276754/task3/ui/contentassist/antlr/internal/InternalMydsl.g:244:1: ( rule__Playlist__Group__0 )
            // ../at.ac.univie.swa.ase2014.a1276754.task3.mydsl.ui/src-gen/at/ac/univie/swa/ase2014/a1276754/task3/ui/contentassist/antlr/internal/InternalMydsl.g:244:2: rule__Playlist__Group__0
            {
            pushFollow(FOLLOW_rule__Playlist__Group__0_in_rulePlaylist454);
            rule__Playlist__Group__0();

            state._fsp--;


            }

             after(grammarAccess.getPlaylistAccess().getGroup()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rulePlaylist"


    // $ANTLR start "ruleGenre"
    // ../at.ac.univie.swa.ase2014.a1276754.task3.mydsl.ui/src-gen/at/ac/univie/swa/ase2014/a1276754/task3/ui/contentassist/antlr/internal/InternalMydsl.g:257:1: ruleGenre : ( ( rule__Genre__Alternatives ) ) ;
    public final void ruleGenre() throws RecognitionException {

        		int stackSize = keepStackSize();
            
        try {
            // ../at.ac.univie.swa.ase2014.a1276754.task3.mydsl.ui/src-gen/at/ac/univie/swa/ase2014/a1276754/task3/ui/contentassist/antlr/internal/InternalMydsl.g:261:1: ( ( ( rule__Genre__Alternatives ) ) )
            // ../at.ac.univie.swa.ase2014.a1276754.task3.mydsl.ui/src-gen/at/ac/univie/swa/ase2014/a1276754/task3/ui/contentassist/antlr/internal/InternalMydsl.g:262:1: ( ( rule__Genre__Alternatives ) )
            {
            // ../at.ac.univie.swa.ase2014.a1276754.task3.mydsl.ui/src-gen/at/ac/univie/swa/ase2014/a1276754/task3/ui/contentassist/antlr/internal/InternalMydsl.g:262:1: ( ( rule__Genre__Alternatives ) )
            // ../at.ac.univie.swa.ase2014.a1276754.task3.mydsl.ui/src-gen/at/ac/univie/swa/ase2014/a1276754/task3/ui/contentassist/antlr/internal/InternalMydsl.g:263:1: ( rule__Genre__Alternatives )
            {
             before(grammarAccess.getGenreAccess().getAlternatives()); 
            // ../at.ac.univie.swa.ase2014.a1276754.task3.mydsl.ui/src-gen/at/ac/univie/swa/ase2014/a1276754/task3/ui/contentassist/antlr/internal/InternalMydsl.g:264:1: ( rule__Genre__Alternatives )
            // ../at.ac.univie.swa.ase2014.a1276754.task3.mydsl.ui/src-gen/at/ac/univie/swa/ase2014/a1276754/task3/ui/contentassist/antlr/internal/InternalMydsl.g:264:2: rule__Genre__Alternatives
            {
            pushFollow(FOLLOW_rule__Genre__Alternatives_in_ruleGenre491);
            rule__Genre__Alternatives();

            state._fsp--;


            }

             after(grammarAccess.getGenreAccess().getAlternatives()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "ruleGenre"


    // $ANTLR start "rule__Genre__Alternatives"
    // ../at.ac.univie.swa.ase2014.a1276754.task3.mydsl.ui/src-gen/at/ac/univie/swa/ase2014/a1276754/task3/ui/contentassist/antlr/internal/InternalMydsl.g:275:1: rule__Genre__Alternatives : ( ( ( 'POP' ) ) | ( ( 'ROCK' ) ) | ( ( 'HARDROCK' ) ) | ( ( 'CLASSIC' ) ) | ( ( 'FOLK' ) ) | ( ( 'OTHER' ) ) );
    public final void rule__Genre__Alternatives() throws RecognitionException {

        		int stackSize = keepStackSize();
            
        try {
            // ../at.ac.univie.swa.ase2014.a1276754.task3.mydsl.ui/src-gen/at/ac/univie/swa/ase2014/a1276754/task3/ui/contentassist/antlr/internal/InternalMydsl.g:279:1: ( ( ( 'POP' ) ) | ( ( 'ROCK' ) ) | ( ( 'HARDROCK' ) ) | ( ( 'CLASSIC' ) ) | ( ( 'FOLK' ) ) | ( ( 'OTHER' ) ) )
            int alt1=6;
            switch ( input.LA(1) ) {
            case 11:
                {
                alt1=1;
                }
                break;
            case 12:
                {
                alt1=2;
                }
                break;
            case 13:
                {
                alt1=3;
                }
                break;
            case 14:
                {
                alt1=4;
                }
                break;
            case 15:
                {
                alt1=5;
                }
                break;
            case 16:
                {
                alt1=6;
                }
                break;
            default:
                NoViableAltException nvae =
                    new NoViableAltException("", 1, 0, input);

                throw nvae;
            }

            switch (alt1) {
                case 1 :
                    // ../at.ac.univie.swa.ase2014.a1276754.task3.mydsl.ui/src-gen/at/ac/univie/swa/ase2014/a1276754/task3/ui/contentassist/antlr/internal/InternalMydsl.g:280:1: ( ( 'POP' ) )
                    {
                    // ../at.ac.univie.swa.ase2014.a1276754.task3.mydsl.ui/src-gen/at/ac/univie/swa/ase2014/a1276754/task3/ui/contentassist/antlr/internal/InternalMydsl.g:280:1: ( ( 'POP' ) )
                    // ../at.ac.univie.swa.ase2014.a1276754.task3.mydsl.ui/src-gen/at/ac/univie/swa/ase2014/a1276754/task3/ui/contentassist/antlr/internal/InternalMydsl.g:281:1: ( 'POP' )
                    {
                     before(grammarAccess.getGenreAccess().getPopEnumLiteralDeclaration_0()); 
                    // ../at.ac.univie.swa.ase2014.a1276754.task3.mydsl.ui/src-gen/at/ac/univie/swa/ase2014/a1276754/task3/ui/contentassist/antlr/internal/InternalMydsl.g:282:1: ( 'POP' )
                    // ../at.ac.univie.swa.ase2014.a1276754.task3.mydsl.ui/src-gen/at/ac/univie/swa/ase2014/a1276754/task3/ui/contentassist/antlr/internal/InternalMydsl.g:282:3: 'POP'
                    {
                    match(input,11,FOLLOW_11_in_rule__Genre__Alternatives527); 

                    }

                     after(grammarAccess.getGenreAccess().getPopEnumLiteralDeclaration_0()); 

                    }


                    }
                    break;
                case 2 :
                    // ../at.ac.univie.swa.ase2014.a1276754.task3.mydsl.ui/src-gen/at/ac/univie/swa/ase2014/a1276754/task3/ui/contentassist/antlr/internal/InternalMydsl.g:287:6: ( ( 'ROCK' ) )
                    {
                    // ../at.ac.univie.swa.ase2014.a1276754.task3.mydsl.ui/src-gen/at/ac/univie/swa/ase2014/a1276754/task3/ui/contentassist/antlr/internal/InternalMydsl.g:287:6: ( ( 'ROCK' ) )
                    // ../at.ac.univie.swa.ase2014.a1276754.task3.mydsl.ui/src-gen/at/ac/univie/swa/ase2014/a1276754/task3/ui/contentassist/antlr/internal/InternalMydsl.g:288:1: ( 'ROCK' )
                    {
                     before(grammarAccess.getGenreAccess().getRockEnumLiteralDeclaration_1()); 
                    // ../at.ac.univie.swa.ase2014.a1276754.task3.mydsl.ui/src-gen/at/ac/univie/swa/ase2014/a1276754/task3/ui/contentassist/antlr/internal/InternalMydsl.g:289:1: ( 'ROCK' )
                    // ../at.ac.univie.swa.ase2014.a1276754.task3.mydsl.ui/src-gen/at/ac/univie/swa/ase2014/a1276754/task3/ui/contentassist/antlr/internal/InternalMydsl.g:289:3: 'ROCK'
                    {
                    match(input,12,FOLLOW_12_in_rule__Genre__Alternatives548); 

                    }

                     after(grammarAccess.getGenreAccess().getRockEnumLiteralDeclaration_1()); 

                    }


                    }
                    break;
                case 3 :
                    // ../at.ac.univie.swa.ase2014.a1276754.task3.mydsl.ui/src-gen/at/ac/univie/swa/ase2014/a1276754/task3/ui/contentassist/antlr/internal/InternalMydsl.g:294:6: ( ( 'HARDROCK' ) )
                    {
                    // ../at.ac.univie.swa.ase2014.a1276754.task3.mydsl.ui/src-gen/at/ac/univie/swa/ase2014/a1276754/task3/ui/contentassist/antlr/internal/InternalMydsl.g:294:6: ( ( 'HARDROCK' ) )
                    // ../at.ac.univie.swa.ase2014.a1276754.task3.mydsl.ui/src-gen/at/ac/univie/swa/ase2014/a1276754/task3/ui/contentassist/antlr/internal/InternalMydsl.g:295:1: ( 'HARDROCK' )
                    {
                     before(grammarAccess.getGenreAccess().getHardrockEnumLiteralDeclaration_2()); 
                    // ../at.ac.univie.swa.ase2014.a1276754.task3.mydsl.ui/src-gen/at/ac/univie/swa/ase2014/a1276754/task3/ui/contentassist/antlr/internal/InternalMydsl.g:296:1: ( 'HARDROCK' )
                    // ../at.ac.univie.swa.ase2014.a1276754.task3.mydsl.ui/src-gen/at/ac/univie/swa/ase2014/a1276754/task3/ui/contentassist/antlr/internal/InternalMydsl.g:296:3: 'HARDROCK'
                    {
                    match(input,13,FOLLOW_13_in_rule__Genre__Alternatives569); 

                    }

                     after(grammarAccess.getGenreAccess().getHardrockEnumLiteralDeclaration_2()); 

                    }


                    }
                    break;
                case 4 :
                    // ../at.ac.univie.swa.ase2014.a1276754.task3.mydsl.ui/src-gen/at/ac/univie/swa/ase2014/a1276754/task3/ui/contentassist/antlr/internal/InternalMydsl.g:301:6: ( ( 'CLASSIC' ) )
                    {
                    // ../at.ac.univie.swa.ase2014.a1276754.task3.mydsl.ui/src-gen/at/ac/univie/swa/ase2014/a1276754/task3/ui/contentassist/antlr/internal/InternalMydsl.g:301:6: ( ( 'CLASSIC' ) )
                    // ../at.ac.univie.swa.ase2014.a1276754.task3.mydsl.ui/src-gen/at/ac/univie/swa/ase2014/a1276754/task3/ui/contentassist/antlr/internal/InternalMydsl.g:302:1: ( 'CLASSIC' )
                    {
                     before(grammarAccess.getGenreAccess().getClassicEnumLiteralDeclaration_3()); 
                    // ../at.ac.univie.swa.ase2014.a1276754.task3.mydsl.ui/src-gen/at/ac/univie/swa/ase2014/a1276754/task3/ui/contentassist/antlr/internal/InternalMydsl.g:303:1: ( 'CLASSIC' )
                    // ../at.ac.univie.swa.ase2014.a1276754.task3.mydsl.ui/src-gen/at/ac/univie/swa/ase2014/a1276754/task3/ui/contentassist/antlr/internal/InternalMydsl.g:303:3: 'CLASSIC'
                    {
                    match(input,14,FOLLOW_14_in_rule__Genre__Alternatives590); 

                    }

                     after(grammarAccess.getGenreAccess().getClassicEnumLiteralDeclaration_3()); 

                    }


                    }
                    break;
                case 5 :
                    // ../at.ac.univie.swa.ase2014.a1276754.task3.mydsl.ui/src-gen/at/ac/univie/swa/ase2014/a1276754/task3/ui/contentassist/antlr/internal/InternalMydsl.g:308:6: ( ( 'FOLK' ) )
                    {
                    // ../at.ac.univie.swa.ase2014.a1276754.task3.mydsl.ui/src-gen/at/ac/univie/swa/ase2014/a1276754/task3/ui/contentassist/antlr/internal/InternalMydsl.g:308:6: ( ( 'FOLK' ) )
                    // ../at.ac.univie.swa.ase2014.a1276754.task3.mydsl.ui/src-gen/at/ac/univie/swa/ase2014/a1276754/task3/ui/contentassist/antlr/internal/InternalMydsl.g:309:1: ( 'FOLK' )
                    {
                     before(grammarAccess.getGenreAccess().getFolkEnumLiteralDeclaration_4()); 
                    // ../at.ac.univie.swa.ase2014.a1276754.task3.mydsl.ui/src-gen/at/ac/univie/swa/ase2014/a1276754/task3/ui/contentassist/antlr/internal/InternalMydsl.g:310:1: ( 'FOLK' )
                    // ../at.ac.univie.swa.ase2014.a1276754.task3.mydsl.ui/src-gen/at/ac/univie/swa/ase2014/a1276754/task3/ui/contentassist/antlr/internal/InternalMydsl.g:310:3: 'FOLK'
                    {
                    match(input,15,FOLLOW_15_in_rule__Genre__Alternatives611); 

                    }

                     after(grammarAccess.getGenreAccess().getFolkEnumLiteralDeclaration_4()); 

                    }


                    }
                    break;
                case 6 :
                    // ../at.ac.univie.swa.ase2014.a1276754.task3.mydsl.ui/src-gen/at/ac/univie/swa/ase2014/a1276754/task3/ui/contentassist/antlr/internal/InternalMydsl.g:315:6: ( ( 'OTHER' ) )
                    {
                    // ../at.ac.univie.swa.ase2014.a1276754.task3.mydsl.ui/src-gen/at/ac/univie/swa/ase2014/a1276754/task3/ui/contentassist/antlr/internal/InternalMydsl.g:315:6: ( ( 'OTHER' ) )
                    // ../at.ac.univie.swa.ase2014.a1276754.task3.mydsl.ui/src-gen/at/ac/univie/swa/ase2014/a1276754/task3/ui/contentassist/antlr/internal/InternalMydsl.g:316:1: ( 'OTHER' )
                    {
                     before(grammarAccess.getGenreAccess().getOtherEnumLiteralDeclaration_5()); 
                    // ../at.ac.univie.swa.ase2014.a1276754.task3.mydsl.ui/src-gen/at/ac/univie/swa/ase2014/a1276754/task3/ui/contentassist/antlr/internal/InternalMydsl.g:317:1: ( 'OTHER' )
                    // ../at.ac.univie.swa.ase2014.a1276754.task3.mydsl.ui/src-gen/at/ac/univie/swa/ase2014/a1276754/task3/ui/contentassist/antlr/internal/InternalMydsl.g:317:3: 'OTHER'
                    {
                    match(input,16,FOLLOW_16_in_rule__Genre__Alternatives632); 

                    }

                     after(grammarAccess.getGenreAccess().getOtherEnumLiteralDeclaration_5()); 

                    }


                    }
                    break;

            }
        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Genre__Alternatives"


    // $ANTLR start "rule__Model__Group__0"
    // ../at.ac.univie.swa.ase2014.a1276754.task3.mydsl.ui/src-gen/at/ac/univie/swa/ase2014/a1276754/task3/ui/contentassist/antlr/internal/InternalMydsl.g:329:1: rule__Model__Group__0 : rule__Model__Group__0__Impl rule__Model__Group__1 ;
    public final void rule__Model__Group__0() throws RecognitionException {

        		int stackSize = keepStackSize();
            
        try {
            // ../at.ac.univie.swa.ase2014.a1276754.task3.mydsl.ui/src-gen/at/ac/univie/swa/ase2014/a1276754/task3/ui/contentassist/antlr/internal/InternalMydsl.g:333:1: ( rule__Model__Group__0__Impl rule__Model__Group__1 )
            // ../at.ac.univie.swa.ase2014.a1276754.task3.mydsl.ui/src-gen/at/ac/univie/swa/ase2014/a1276754/task3/ui/contentassist/antlr/internal/InternalMydsl.g:334:2: rule__Model__Group__0__Impl rule__Model__Group__1
            {
            pushFollow(FOLLOW_rule__Model__Group__0__Impl_in_rule__Model__Group__0665);
            rule__Model__Group__0__Impl();

            state._fsp--;

            pushFollow(FOLLOW_rule__Model__Group__1_in_rule__Model__Group__0668);
            rule__Model__Group__1();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Model__Group__0"


    // $ANTLR start "rule__Model__Group__0__Impl"
    // ../at.ac.univie.swa.ase2014.a1276754.task3.mydsl.ui/src-gen/at/ac/univie/swa/ase2014/a1276754/task3/ui/contentassist/antlr/internal/InternalMydsl.g:341:1: rule__Model__Group__0__Impl : ( 'Distributors:' ) ;
    public final void rule__Model__Group__0__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
            
        try {
            // ../at.ac.univie.swa.ase2014.a1276754.task3.mydsl.ui/src-gen/at/ac/univie/swa/ase2014/a1276754/task3/ui/contentassist/antlr/internal/InternalMydsl.g:345:1: ( ( 'Distributors:' ) )
            // ../at.ac.univie.swa.ase2014.a1276754.task3.mydsl.ui/src-gen/at/ac/univie/swa/ase2014/a1276754/task3/ui/contentassist/antlr/internal/InternalMydsl.g:346:1: ( 'Distributors:' )
            {
            // ../at.ac.univie.swa.ase2014.a1276754.task3.mydsl.ui/src-gen/at/ac/univie/swa/ase2014/a1276754/task3/ui/contentassist/antlr/internal/InternalMydsl.g:346:1: ( 'Distributors:' )
            // ../at.ac.univie.swa.ase2014.a1276754.task3.mydsl.ui/src-gen/at/ac/univie/swa/ase2014/a1276754/task3/ui/contentassist/antlr/internal/InternalMydsl.g:347:1: 'Distributors:'
            {
             before(grammarAccess.getModelAccess().getDistributorsKeyword_0()); 
            match(input,17,FOLLOW_17_in_rule__Model__Group__0__Impl696); 
             after(grammarAccess.getModelAccess().getDistributorsKeyword_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Model__Group__0__Impl"


    // $ANTLR start "rule__Model__Group__1"
    // ../at.ac.univie.swa.ase2014.a1276754.task3.mydsl.ui/src-gen/at/ac/univie/swa/ase2014/a1276754/task3/ui/contentassist/antlr/internal/InternalMydsl.g:360:1: rule__Model__Group__1 : rule__Model__Group__1__Impl rule__Model__Group__2 ;
    public final void rule__Model__Group__1() throws RecognitionException {

        		int stackSize = keepStackSize();
            
        try {
            // ../at.ac.univie.swa.ase2014.a1276754.task3.mydsl.ui/src-gen/at/ac/univie/swa/ase2014/a1276754/task3/ui/contentassist/antlr/internal/InternalMydsl.g:364:1: ( rule__Model__Group__1__Impl rule__Model__Group__2 )
            // ../at.ac.univie.swa.ase2014.a1276754.task3.mydsl.ui/src-gen/at/ac/univie/swa/ase2014/a1276754/task3/ui/contentassist/antlr/internal/InternalMydsl.g:365:2: rule__Model__Group__1__Impl rule__Model__Group__2
            {
            pushFollow(FOLLOW_rule__Model__Group__1__Impl_in_rule__Model__Group__1727);
            rule__Model__Group__1__Impl();

            state._fsp--;

            pushFollow(FOLLOW_rule__Model__Group__2_in_rule__Model__Group__1730);
            rule__Model__Group__2();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Model__Group__1"


    // $ANTLR start "rule__Model__Group__1__Impl"
    // ../at.ac.univie.swa.ase2014.a1276754.task3.mydsl.ui/src-gen/at/ac/univie/swa/ase2014/a1276754/task3/ui/contentassist/antlr/internal/InternalMydsl.g:372:1: rule__Model__Group__1__Impl : ( ( ( rule__Model__DistributorsAssignment_1 ) ) ( ( rule__Model__DistributorsAssignment_1 )* ) ) ;
    public final void rule__Model__Group__1__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
            
        try {
            // ../at.ac.univie.swa.ase2014.a1276754.task3.mydsl.ui/src-gen/at/ac/univie/swa/ase2014/a1276754/task3/ui/contentassist/antlr/internal/InternalMydsl.g:376:1: ( ( ( ( rule__Model__DistributorsAssignment_1 ) ) ( ( rule__Model__DistributorsAssignment_1 )* ) ) )
            // ../at.ac.univie.swa.ase2014.a1276754.task3.mydsl.ui/src-gen/at/ac/univie/swa/ase2014/a1276754/task3/ui/contentassist/antlr/internal/InternalMydsl.g:377:1: ( ( ( rule__Model__DistributorsAssignment_1 ) ) ( ( rule__Model__DistributorsAssignment_1 )* ) )
            {
            // ../at.ac.univie.swa.ase2014.a1276754.task3.mydsl.ui/src-gen/at/ac/univie/swa/ase2014/a1276754/task3/ui/contentassist/antlr/internal/InternalMydsl.g:377:1: ( ( ( rule__Model__DistributorsAssignment_1 ) ) ( ( rule__Model__DistributorsAssignment_1 )* ) )
            // ../at.ac.univie.swa.ase2014.a1276754.task3.mydsl.ui/src-gen/at/ac/univie/swa/ase2014/a1276754/task3/ui/contentassist/antlr/internal/InternalMydsl.g:378:1: ( ( rule__Model__DistributorsAssignment_1 ) ) ( ( rule__Model__DistributorsAssignment_1 )* )
            {
            // ../at.ac.univie.swa.ase2014.a1276754.task3.mydsl.ui/src-gen/at/ac/univie/swa/ase2014/a1276754/task3/ui/contentassist/antlr/internal/InternalMydsl.g:378:1: ( ( rule__Model__DistributorsAssignment_1 ) )
            // ../at.ac.univie.swa.ase2014.a1276754.task3.mydsl.ui/src-gen/at/ac/univie/swa/ase2014/a1276754/task3/ui/contentassist/antlr/internal/InternalMydsl.g:379:1: ( rule__Model__DistributorsAssignment_1 )
            {
             before(grammarAccess.getModelAccess().getDistributorsAssignment_1()); 
            // ../at.ac.univie.swa.ase2014.a1276754.task3.mydsl.ui/src-gen/at/ac/univie/swa/ase2014/a1276754/task3/ui/contentassist/antlr/internal/InternalMydsl.g:380:1: ( rule__Model__DistributorsAssignment_1 )
            // ../at.ac.univie.swa.ase2014.a1276754.task3.mydsl.ui/src-gen/at/ac/univie/swa/ase2014/a1276754/task3/ui/contentassist/antlr/internal/InternalMydsl.g:380:2: rule__Model__DistributorsAssignment_1
            {
            pushFollow(FOLLOW_rule__Model__DistributorsAssignment_1_in_rule__Model__Group__1__Impl759);
            rule__Model__DistributorsAssignment_1();

            state._fsp--;


            }

             after(grammarAccess.getModelAccess().getDistributorsAssignment_1()); 

            }

            // ../at.ac.univie.swa.ase2014.a1276754.task3.mydsl.ui/src-gen/at/ac/univie/swa/ase2014/a1276754/task3/ui/contentassist/antlr/internal/InternalMydsl.g:383:1: ( ( rule__Model__DistributorsAssignment_1 )* )
            // ../at.ac.univie.swa.ase2014.a1276754.task3.mydsl.ui/src-gen/at/ac/univie/swa/ase2014/a1276754/task3/ui/contentassist/antlr/internal/InternalMydsl.g:384:1: ( rule__Model__DistributorsAssignment_1 )*
            {
             before(grammarAccess.getModelAccess().getDistributorsAssignment_1()); 
            // ../at.ac.univie.swa.ase2014.a1276754.task3.mydsl.ui/src-gen/at/ac/univie/swa/ase2014/a1276754/task3/ui/contentassist/antlr/internal/InternalMydsl.g:385:1: ( rule__Model__DistributorsAssignment_1 )*
            loop2:
            do {
                int alt2=2;
                int LA2_0 = input.LA(1);

                if ( (LA2_0==RULE_ID) ) {
                    alt2=1;
                }


                switch (alt2) {
            	case 1 :
            	    // ../at.ac.univie.swa.ase2014.a1276754.task3.mydsl.ui/src-gen/at/ac/univie/swa/ase2014/a1276754/task3/ui/contentassist/antlr/internal/InternalMydsl.g:385:2: rule__Model__DistributorsAssignment_1
            	    {
            	    pushFollow(FOLLOW_rule__Model__DistributorsAssignment_1_in_rule__Model__Group__1__Impl771);
            	    rule__Model__DistributorsAssignment_1();

            	    state._fsp--;


            	    }
            	    break;

            	default :
            	    break loop2;
                }
            } while (true);

             after(grammarAccess.getModelAccess().getDistributorsAssignment_1()); 

            }


            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Model__Group__1__Impl"


    // $ANTLR start "rule__Model__Group__2"
    // ../at.ac.univie.swa.ase2014.a1276754.task3.mydsl.ui/src-gen/at/ac/univie/swa/ase2014/a1276754/task3/ui/contentassist/antlr/internal/InternalMydsl.g:396:1: rule__Model__Group__2 : rule__Model__Group__2__Impl rule__Model__Group__3 ;
    public final void rule__Model__Group__2() throws RecognitionException {

        		int stackSize = keepStackSize();
            
        try {
            // ../at.ac.univie.swa.ase2014.a1276754.task3.mydsl.ui/src-gen/at/ac/univie/swa/ase2014/a1276754/task3/ui/contentassist/antlr/internal/InternalMydsl.g:400:1: ( rule__Model__Group__2__Impl rule__Model__Group__3 )
            // ../at.ac.univie.swa.ase2014.a1276754.task3.mydsl.ui/src-gen/at/ac/univie/swa/ase2014/a1276754/task3/ui/contentassist/antlr/internal/InternalMydsl.g:401:2: rule__Model__Group__2__Impl rule__Model__Group__3
            {
            pushFollow(FOLLOW_rule__Model__Group__2__Impl_in_rule__Model__Group__2804);
            rule__Model__Group__2__Impl();

            state._fsp--;

            pushFollow(FOLLOW_rule__Model__Group__3_in_rule__Model__Group__2807);
            rule__Model__Group__3();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Model__Group__2"


    // $ANTLR start "rule__Model__Group__2__Impl"
    // ../at.ac.univie.swa.ase2014.a1276754.task3.mydsl.ui/src-gen/at/ac/univie/swa/ase2014/a1276754/task3/ui/contentassist/antlr/internal/InternalMydsl.g:408:1: rule__Model__Group__2__Impl : ( 'Library:' ) ;
    public final void rule__Model__Group__2__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
            
        try {
            // ../at.ac.univie.swa.ase2014.a1276754.task3.mydsl.ui/src-gen/at/ac/univie/swa/ase2014/a1276754/task3/ui/contentassist/antlr/internal/InternalMydsl.g:412:1: ( ( 'Library:' ) )
            // ../at.ac.univie.swa.ase2014.a1276754.task3.mydsl.ui/src-gen/at/ac/univie/swa/ase2014/a1276754/task3/ui/contentassist/antlr/internal/InternalMydsl.g:413:1: ( 'Library:' )
            {
            // ../at.ac.univie.swa.ase2014.a1276754.task3.mydsl.ui/src-gen/at/ac/univie/swa/ase2014/a1276754/task3/ui/contentassist/antlr/internal/InternalMydsl.g:413:1: ( 'Library:' )
            // ../at.ac.univie.swa.ase2014.a1276754.task3.mydsl.ui/src-gen/at/ac/univie/swa/ase2014/a1276754/task3/ui/contentassist/antlr/internal/InternalMydsl.g:414:1: 'Library:'
            {
             before(grammarAccess.getModelAccess().getLibraryKeyword_2()); 
            match(input,18,FOLLOW_18_in_rule__Model__Group__2__Impl835); 
             after(grammarAccess.getModelAccess().getLibraryKeyword_2()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Model__Group__2__Impl"


    // $ANTLR start "rule__Model__Group__3"
    // ../at.ac.univie.swa.ase2014.a1276754.task3.mydsl.ui/src-gen/at/ac/univie/swa/ase2014/a1276754/task3/ui/contentassist/antlr/internal/InternalMydsl.g:427:1: rule__Model__Group__3 : rule__Model__Group__3__Impl rule__Model__Group__4 ;
    public final void rule__Model__Group__3() throws RecognitionException {

        		int stackSize = keepStackSize();
            
        try {
            // ../at.ac.univie.swa.ase2014.a1276754.task3.mydsl.ui/src-gen/at/ac/univie/swa/ase2014/a1276754/task3/ui/contentassist/antlr/internal/InternalMydsl.g:431:1: ( rule__Model__Group__3__Impl rule__Model__Group__4 )
            // ../at.ac.univie.swa.ase2014.a1276754.task3.mydsl.ui/src-gen/at/ac/univie/swa/ase2014/a1276754/task3/ui/contentassist/antlr/internal/InternalMydsl.g:432:2: rule__Model__Group__3__Impl rule__Model__Group__4
            {
            pushFollow(FOLLOW_rule__Model__Group__3__Impl_in_rule__Model__Group__3866);
            rule__Model__Group__3__Impl();

            state._fsp--;

            pushFollow(FOLLOW_rule__Model__Group__4_in_rule__Model__Group__3869);
            rule__Model__Group__4();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Model__Group__3"


    // $ANTLR start "rule__Model__Group__3__Impl"
    // ../at.ac.univie.swa.ase2014.a1276754.task3.mydsl.ui/src-gen/at/ac/univie/swa/ase2014/a1276754/task3/ui/contentassist/antlr/internal/InternalMydsl.g:439:1: rule__Model__Group__3__Impl : ( ( ( rule__Model__SongsAssignment_3 ) ) ( ( rule__Model__SongsAssignment_3 )* ) ) ;
    public final void rule__Model__Group__3__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
            
        try {
            // ../at.ac.univie.swa.ase2014.a1276754.task3.mydsl.ui/src-gen/at/ac/univie/swa/ase2014/a1276754/task3/ui/contentassist/antlr/internal/InternalMydsl.g:443:1: ( ( ( ( rule__Model__SongsAssignment_3 ) ) ( ( rule__Model__SongsAssignment_3 )* ) ) )
            // ../at.ac.univie.swa.ase2014.a1276754.task3.mydsl.ui/src-gen/at/ac/univie/swa/ase2014/a1276754/task3/ui/contentassist/antlr/internal/InternalMydsl.g:444:1: ( ( ( rule__Model__SongsAssignment_3 ) ) ( ( rule__Model__SongsAssignment_3 )* ) )
            {
            // ../at.ac.univie.swa.ase2014.a1276754.task3.mydsl.ui/src-gen/at/ac/univie/swa/ase2014/a1276754/task3/ui/contentassist/antlr/internal/InternalMydsl.g:444:1: ( ( ( rule__Model__SongsAssignment_3 ) ) ( ( rule__Model__SongsAssignment_3 )* ) )
            // ../at.ac.univie.swa.ase2014.a1276754.task3.mydsl.ui/src-gen/at/ac/univie/swa/ase2014/a1276754/task3/ui/contentassist/antlr/internal/InternalMydsl.g:445:1: ( ( rule__Model__SongsAssignment_3 ) ) ( ( rule__Model__SongsAssignment_3 )* )
            {
            // ../at.ac.univie.swa.ase2014.a1276754.task3.mydsl.ui/src-gen/at/ac/univie/swa/ase2014/a1276754/task3/ui/contentassist/antlr/internal/InternalMydsl.g:445:1: ( ( rule__Model__SongsAssignment_3 ) )
            // ../at.ac.univie.swa.ase2014.a1276754.task3.mydsl.ui/src-gen/at/ac/univie/swa/ase2014/a1276754/task3/ui/contentassist/antlr/internal/InternalMydsl.g:446:1: ( rule__Model__SongsAssignment_3 )
            {
             before(grammarAccess.getModelAccess().getSongsAssignment_3()); 
            // ../at.ac.univie.swa.ase2014.a1276754.task3.mydsl.ui/src-gen/at/ac/univie/swa/ase2014/a1276754/task3/ui/contentassist/antlr/internal/InternalMydsl.g:447:1: ( rule__Model__SongsAssignment_3 )
            // ../at.ac.univie.swa.ase2014.a1276754.task3.mydsl.ui/src-gen/at/ac/univie/swa/ase2014/a1276754/task3/ui/contentassist/antlr/internal/InternalMydsl.g:447:2: rule__Model__SongsAssignment_3
            {
            pushFollow(FOLLOW_rule__Model__SongsAssignment_3_in_rule__Model__Group__3__Impl898);
            rule__Model__SongsAssignment_3();

            state._fsp--;


            }

             after(grammarAccess.getModelAccess().getSongsAssignment_3()); 

            }

            // ../at.ac.univie.swa.ase2014.a1276754.task3.mydsl.ui/src-gen/at/ac/univie/swa/ase2014/a1276754/task3/ui/contentassist/antlr/internal/InternalMydsl.g:450:1: ( ( rule__Model__SongsAssignment_3 )* )
            // ../at.ac.univie.swa.ase2014.a1276754.task3.mydsl.ui/src-gen/at/ac/univie/swa/ase2014/a1276754/task3/ui/contentassist/antlr/internal/InternalMydsl.g:451:1: ( rule__Model__SongsAssignment_3 )*
            {
             before(grammarAccess.getModelAccess().getSongsAssignment_3()); 
            // ../at.ac.univie.swa.ase2014.a1276754.task3.mydsl.ui/src-gen/at/ac/univie/swa/ase2014/a1276754/task3/ui/contentassist/antlr/internal/InternalMydsl.g:452:1: ( rule__Model__SongsAssignment_3 )*
            loop3:
            do {
                int alt3=2;
                int LA3_0 = input.LA(1);

                if ( (LA3_0==RULE_ID) ) {
                    alt3=1;
                }


                switch (alt3) {
            	case 1 :
            	    // ../at.ac.univie.swa.ase2014.a1276754.task3.mydsl.ui/src-gen/at/ac/univie/swa/ase2014/a1276754/task3/ui/contentassist/antlr/internal/InternalMydsl.g:452:2: rule__Model__SongsAssignment_3
            	    {
            	    pushFollow(FOLLOW_rule__Model__SongsAssignment_3_in_rule__Model__Group__3__Impl910);
            	    rule__Model__SongsAssignment_3();

            	    state._fsp--;


            	    }
            	    break;

            	default :
            	    break loop3;
                }
            } while (true);

             after(grammarAccess.getModelAccess().getSongsAssignment_3()); 

            }


            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Model__Group__3__Impl"


    // $ANTLR start "rule__Model__Group__4"
    // ../at.ac.univie.swa.ase2014.a1276754.task3.mydsl.ui/src-gen/at/ac/univie/swa/ase2014/a1276754/task3/ui/contentassist/antlr/internal/InternalMydsl.g:463:1: rule__Model__Group__4 : rule__Model__Group__4__Impl rule__Model__Group__5 ;
    public final void rule__Model__Group__4() throws RecognitionException {

        		int stackSize = keepStackSize();
            
        try {
            // ../at.ac.univie.swa.ase2014.a1276754.task3.mydsl.ui/src-gen/at/ac/univie/swa/ase2014/a1276754/task3/ui/contentassist/antlr/internal/InternalMydsl.g:467:1: ( rule__Model__Group__4__Impl rule__Model__Group__5 )
            // ../at.ac.univie.swa.ase2014.a1276754.task3.mydsl.ui/src-gen/at/ac/univie/swa/ase2014/a1276754/task3/ui/contentassist/antlr/internal/InternalMydsl.g:468:2: rule__Model__Group__4__Impl rule__Model__Group__5
            {
            pushFollow(FOLLOW_rule__Model__Group__4__Impl_in_rule__Model__Group__4943);
            rule__Model__Group__4__Impl();

            state._fsp--;

            pushFollow(FOLLOW_rule__Model__Group__5_in_rule__Model__Group__4946);
            rule__Model__Group__5();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Model__Group__4"


    // $ANTLR start "rule__Model__Group__4__Impl"
    // ../at.ac.univie.swa.ase2014.a1276754.task3.mydsl.ui/src-gen/at/ac/univie/swa/ase2014/a1276754/task3/ui/contentassist/antlr/internal/InternalMydsl.g:475:1: rule__Model__Group__4__Impl : ( 'Playlists:' ) ;
    public final void rule__Model__Group__4__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
            
        try {
            // ../at.ac.univie.swa.ase2014.a1276754.task3.mydsl.ui/src-gen/at/ac/univie/swa/ase2014/a1276754/task3/ui/contentassist/antlr/internal/InternalMydsl.g:479:1: ( ( 'Playlists:' ) )
            // ../at.ac.univie.swa.ase2014.a1276754.task3.mydsl.ui/src-gen/at/ac/univie/swa/ase2014/a1276754/task3/ui/contentassist/antlr/internal/InternalMydsl.g:480:1: ( 'Playlists:' )
            {
            // ../at.ac.univie.swa.ase2014.a1276754.task3.mydsl.ui/src-gen/at/ac/univie/swa/ase2014/a1276754/task3/ui/contentassist/antlr/internal/InternalMydsl.g:480:1: ( 'Playlists:' )
            // ../at.ac.univie.swa.ase2014.a1276754.task3.mydsl.ui/src-gen/at/ac/univie/swa/ase2014/a1276754/task3/ui/contentassist/antlr/internal/InternalMydsl.g:481:1: 'Playlists:'
            {
             before(grammarAccess.getModelAccess().getPlaylistsKeyword_4()); 
            match(input,19,FOLLOW_19_in_rule__Model__Group__4__Impl974); 
             after(grammarAccess.getModelAccess().getPlaylistsKeyword_4()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Model__Group__4__Impl"


    // $ANTLR start "rule__Model__Group__5"
    // ../at.ac.univie.swa.ase2014.a1276754.task3.mydsl.ui/src-gen/at/ac/univie/swa/ase2014/a1276754/task3/ui/contentassist/antlr/internal/InternalMydsl.g:494:1: rule__Model__Group__5 : rule__Model__Group__5__Impl ;
    public final void rule__Model__Group__5() throws RecognitionException {

        		int stackSize = keepStackSize();
            
        try {
            // ../at.ac.univie.swa.ase2014.a1276754.task3.mydsl.ui/src-gen/at/ac/univie/swa/ase2014/a1276754/task3/ui/contentassist/antlr/internal/InternalMydsl.g:498:1: ( rule__Model__Group__5__Impl )
            // ../at.ac.univie.swa.ase2014.a1276754.task3.mydsl.ui/src-gen/at/ac/univie/swa/ase2014/a1276754/task3/ui/contentassist/antlr/internal/InternalMydsl.g:499:2: rule__Model__Group__5__Impl
            {
            pushFollow(FOLLOW_rule__Model__Group__5__Impl_in_rule__Model__Group__51005);
            rule__Model__Group__5__Impl();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Model__Group__5"


    // $ANTLR start "rule__Model__Group__5__Impl"
    // ../at.ac.univie.swa.ase2014.a1276754.task3.mydsl.ui/src-gen/at/ac/univie/swa/ase2014/a1276754/task3/ui/contentassist/antlr/internal/InternalMydsl.g:505:1: rule__Model__Group__5__Impl : ( ( rule__Model__PlaylistsAssignment_5 )* ) ;
    public final void rule__Model__Group__5__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
            
        try {
            // ../at.ac.univie.swa.ase2014.a1276754.task3.mydsl.ui/src-gen/at/ac/univie/swa/ase2014/a1276754/task3/ui/contentassist/antlr/internal/InternalMydsl.g:509:1: ( ( ( rule__Model__PlaylistsAssignment_5 )* ) )
            // ../at.ac.univie.swa.ase2014.a1276754.task3.mydsl.ui/src-gen/at/ac/univie/swa/ase2014/a1276754/task3/ui/contentassist/antlr/internal/InternalMydsl.g:510:1: ( ( rule__Model__PlaylistsAssignment_5 )* )
            {
            // ../at.ac.univie.swa.ase2014.a1276754.task3.mydsl.ui/src-gen/at/ac/univie/swa/ase2014/a1276754/task3/ui/contentassist/antlr/internal/InternalMydsl.g:510:1: ( ( rule__Model__PlaylistsAssignment_5 )* )
            // ../at.ac.univie.swa.ase2014.a1276754.task3.mydsl.ui/src-gen/at/ac/univie/swa/ase2014/a1276754/task3/ui/contentassist/antlr/internal/InternalMydsl.g:511:1: ( rule__Model__PlaylistsAssignment_5 )*
            {
             before(grammarAccess.getModelAccess().getPlaylistsAssignment_5()); 
            // ../at.ac.univie.swa.ase2014.a1276754.task3.mydsl.ui/src-gen/at/ac/univie/swa/ase2014/a1276754/task3/ui/contentassist/antlr/internal/InternalMydsl.g:512:1: ( rule__Model__PlaylistsAssignment_5 )*
            loop4:
            do {
                int alt4=2;
                int LA4_0 = input.LA(1);

                if ( (LA4_0==RULE_ID) ) {
                    alt4=1;
                }


                switch (alt4) {
            	case 1 :
            	    // ../at.ac.univie.swa.ase2014.a1276754.task3.mydsl.ui/src-gen/at/ac/univie/swa/ase2014/a1276754/task3/ui/contentassist/antlr/internal/InternalMydsl.g:512:2: rule__Model__PlaylistsAssignment_5
            	    {
            	    pushFollow(FOLLOW_rule__Model__PlaylistsAssignment_5_in_rule__Model__Group__5__Impl1032);
            	    rule__Model__PlaylistsAssignment_5();

            	    state._fsp--;


            	    }
            	    break;

            	default :
            	    break loop4;
                }
            } while (true);

             after(grammarAccess.getModelAccess().getPlaylistsAssignment_5()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Model__Group__5__Impl"


    // $ANTLR start "rule__Distributor__Group__0"
    // ../at.ac.univie.swa.ase2014.a1276754.task3.mydsl.ui/src-gen/at/ac/univie/swa/ase2014/a1276754/task3/ui/contentassist/antlr/internal/InternalMydsl.g:534:1: rule__Distributor__Group__0 : rule__Distributor__Group__0__Impl rule__Distributor__Group__1 ;
    public final void rule__Distributor__Group__0() throws RecognitionException {

        		int stackSize = keepStackSize();
            
        try {
            // ../at.ac.univie.swa.ase2014.a1276754.task3.mydsl.ui/src-gen/at/ac/univie/swa/ase2014/a1276754/task3/ui/contentassist/antlr/internal/InternalMydsl.g:538:1: ( rule__Distributor__Group__0__Impl rule__Distributor__Group__1 )
            // ../at.ac.univie.swa.ase2014.a1276754.task3.mydsl.ui/src-gen/at/ac/univie/swa/ase2014/a1276754/task3/ui/contentassist/antlr/internal/InternalMydsl.g:539:2: rule__Distributor__Group__0__Impl rule__Distributor__Group__1
            {
            pushFollow(FOLLOW_rule__Distributor__Group__0__Impl_in_rule__Distributor__Group__01075);
            rule__Distributor__Group__0__Impl();

            state._fsp--;

            pushFollow(FOLLOW_rule__Distributor__Group__1_in_rule__Distributor__Group__01078);
            rule__Distributor__Group__1();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Distributor__Group__0"


    // $ANTLR start "rule__Distributor__Group__0__Impl"
    // ../at.ac.univie.swa.ase2014.a1276754.task3.mydsl.ui/src-gen/at/ac/univie/swa/ase2014/a1276754/task3/ui/contentassist/antlr/internal/InternalMydsl.g:546:1: rule__Distributor__Group__0__Impl : ( ( rule__Distributor__NameAssignment_0 ) ) ;
    public final void rule__Distributor__Group__0__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
            
        try {
            // ../at.ac.univie.swa.ase2014.a1276754.task3.mydsl.ui/src-gen/at/ac/univie/swa/ase2014/a1276754/task3/ui/contentassist/antlr/internal/InternalMydsl.g:550:1: ( ( ( rule__Distributor__NameAssignment_0 ) ) )
            // ../at.ac.univie.swa.ase2014.a1276754.task3.mydsl.ui/src-gen/at/ac/univie/swa/ase2014/a1276754/task3/ui/contentassist/antlr/internal/InternalMydsl.g:551:1: ( ( rule__Distributor__NameAssignment_0 ) )
            {
            // ../at.ac.univie.swa.ase2014.a1276754.task3.mydsl.ui/src-gen/at/ac/univie/swa/ase2014/a1276754/task3/ui/contentassist/antlr/internal/InternalMydsl.g:551:1: ( ( rule__Distributor__NameAssignment_0 ) )
            // ../at.ac.univie.swa.ase2014.a1276754.task3.mydsl.ui/src-gen/at/ac/univie/swa/ase2014/a1276754/task3/ui/contentassist/antlr/internal/InternalMydsl.g:552:1: ( rule__Distributor__NameAssignment_0 )
            {
             before(grammarAccess.getDistributorAccess().getNameAssignment_0()); 
            // ../at.ac.univie.swa.ase2014.a1276754.task3.mydsl.ui/src-gen/at/ac/univie/swa/ase2014/a1276754/task3/ui/contentassist/antlr/internal/InternalMydsl.g:553:1: ( rule__Distributor__NameAssignment_0 )
            // ../at.ac.univie.swa.ase2014.a1276754.task3.mydsl.ui/src-gen/at/ac/univie/swa/ase2014/a1276754/task3/ui/contentassist/antlr/internal/InternalMydsl.g:553:2: rule__Distributor__NameAssignment_0
            {
            pushFollow(FOLLOW_rule__Distributor__NameAssignment_0_in_rule__Distributor__Group__0__Impl1105);
            rule__Distributor__NameAssignment_0();

            state._fsp--;


            }

             after(grammarAccess.getDistributorAccess().getNameAssignment_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Distributor__Group__0__Impl"


    // $ANTLR start "rule__Distributor__Group__1"
    // ../at.ac.univie.swa.ase2014.a1276754.task3.mydsl.ui/src-gen/at/ac/univie/swa/ase2014/a1276754/task3/ui/contentassist/antlr/internal/InternalMydsl.g:563:1: rule__Distributor__Group__1 : rule__Distributor__Group__1__Impl rule__Distributor__Group__2 ;
    public final void rule__Distributor__Group__1() throws RecognitionException {

        		int stackSize = keepStackSize();
            
        try {
            // ../at.ac.univie.swa.ase2014.a1276754.task3.mydsl.ui/src-gen/at/ac/univie/swa/ase2014/a1276754/task3/ui/contentassist/antlr/internal/InternalMydsl.g:567:1: ( rule__Distributor__Group__1__Impl rule__Distributor__Group__2 )
            // ../at.ac.univie.swa.ase2014.a1276754.task3.mydsl.ui/src-gen/at/ac/univie/swa/ase2014/a1276754/task3/ui/contentassist/antlr/internal/InternalMydsl.g:568:2: rule__Distributor__Group__1__Impl rule__Distributor__Group__2
            {
            pushFollow(FOLLOW_rule__Distributor__Group__1__Impl_in_rule__Distributor__Group__11135);
            rule__Distributor__Group__1__Impl();

            state._fsp--;

            pushFollow(FOLLOW_rule__Distributor__Group__2_in_rule__Distributor__Group__11138);
            rule__Distributor__Group__2();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Distributor__Group__1"


    // $ANTLR start "rule__Distributor__Group__1__Impl"
    // ../at.ac.univie.swa.ase2014.a1276754.task3.mydsl.ui/src-gen/at/ac/univie/swa/ase2014/a1276754/task3/ui/contentassist/antlr/internal/InternalMydsl.g:575:1: rule__Distributor__Group__1__Impl : ( 'Address:' ) ;
    public final void rule__Distributor__Group__1__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
            
        try {
            // ../at.ac.univie.swa.ase2014.a1276754.task3.mydsl.ui/src-gen/at/ac/univie/swa/ase2014/a1276754/task3/ui/contentassist/antlr/internal/InternalMydsl.g:579:1: ( ( 'Address:' ) )
            // ../at.ac.univie.swa.ase2014.a1276754.task3.mydsl.ui/src-gen/at/ac/univie/swa/ase2014/a1276754/task3/ui/contentassist/antlr/internal/InternalMydsl.g:580:1: ( 'Address:' )
            {
            // ../at.ac.univie.swa.ase2014.a1276754.task3.mydsl.ui/src-gen/at/ac/univie/swa/ase2014/a1276754/task3/ui/contentassist/antlr/internal/InternalMydsl.g:580:1: ( 'Address:' )
            // ../at.ac.univie.swa.ase2014.a1276754.task3.mydsl.ui/src-gen/at/ac/univie/swa/ase2014/a1276754/task3/ui/contentassist/antlr/internal/InternalMydsl.g:581:1: 'Address:'
            {
             before(grammarAccess.getDistributorAccess().getAddressKeyword_1()); 
            match(input,20,FOLLOW_20_in_rule__Distributor__Group__1__Impl1166); 
             after(grammarAccess.getDistributorAccess().getAddressKeyword_1()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Distributor__Group__1__Impl"


    // $ANTLR start "rule__Distributor__Group__2"
    // ../at.ac.univie.swa.ase2014.a1276754.task3.mydsl.ui/src-gen/at/ac/univie/swa/ase2014/a1276754/task3/ui/contentassist/antlr/internal/InternalMydsl.g:594:1: rule__Distributor__Group__2 : rule__Distributor__Group__2__Impl rule__Distributor__Group__3 ;
    public final void rule__Distributor__Group__2() throws RecognitionException {

        		int stackSize = keepStackSize();
            
        try {
            // ../at.ac.univie.swa.ase2014.a1276754.task3.mydsl.ui/src-gen/at/ac/univie/swa/ase2014/a1276754/task3/ui/contentassist/antlr/internal/InternalMydsl.g:598:1: ( rule__Distributor__Group__2__Impl rule__Distributor__Group__3 )
            // ../at.ac.univie.swa.ase2014.a1276754.task3.mydsl.ui/src-gen/at/ac/univie/swa/ase2014/a1276754/task3/ui/contentassist/antlr/internal/InternalMydsl.g:599:2: rule__Distributor__Group__2__Impl rule__Distributor__Group__3
            {
            pushFollow(FOLLOW_rule__Distributor__Group__2__Impl_in_rule__Distributor__Group__21197);
            rule__Distributor__Group__2__Impl();

            state._fsp--;

            pushFollow(FOLLOW_rule__Distributor__Group__3_in_rule__Distributor__Group__21200);
            rule__Distributor__Group__3();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Distributor__Group__2"


    // $ANTLR start "rule__Distributor__Group__2__Impl"
    // ../at.ac.univie.swa.ase2014.a1276754.task3.mydsl.ui/src-gen/at/ac/univie/swa/ase2014/a1276754/task3/ui/contentassist/antlr/internal/InternalMydsl.g:606:1: rule__Distributor__Group__2__Impl : ( ( rule__Distributor__AdresseAssignment_2 ) ) ;
    public final void rule__Distributor__Group__2__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
            
        try {
            // ../at.ac.univie.swa.ase2014.a1276754.task3.mydsl.ui/src-gen/at/ac/univie/swa/ase2014/a1276754/task3/ui/contentassist/antlr/internal/InternalMydsl.g:610:1: ( ( ( rule__Distributor__AdresseAssignment_2 ) ) )
            // ../at.ac.univie.swa.ase2014.a1276754.task3.mydsl.ui/src-gen/at/ac/univie/swa/ase2014/a1276754/task3/ui/contentassist/antlr/internal/InternalMydsl.g:611:1: ( ( rule__Distributor__AdresseAssignment_2 ) )
            {
            // ../at.ac.univie.swa.ase2014.a1276754.task3.mydsl.ui/src-gen/at/ac/univie/swa/ase2014/a1276754/task3/ui/contentassist/antlr/internal/InternalMydsl.g:611:1: ( ( rule__Distributor__AdresseAssignment_2 ) )
            // ../at.ac.univie.swa.ase2014.a1276754.task3.mydsl.ui/src-gen/at/ac/univie/swa/ase2014/a1276754/task3/ui/contentassist/antlr/internal/InternalMydsl.g:612:1: ( rule__Distributor__AdresseAssignment_2 )
            {
             before(grammarAccess.getDistributorAccess().getAdresseAssignment_2()); 
            // ../at.ac.univie.swa.ase2014.a1276754.task3.mydsl.ui/src-gen/at/ac/univie/swa/ase2014/a1276754/task3/ui/contentassist/antlr/internal/InternalMydsl.g:613:1: ( rule__Distributor__AdresseAssignment_2 )
            // ../at.ac.univie.swa.ase2014.a1276754.task3.mydsl.ui/src-gen/at/ac/univie/swa/ase2014/a1276754/task3/ui/contentassist/antlr/internal/InternalMydsl.g:613:2: rule__Distributor__AdresseAssignment_2
            {
            pushFollow(FOLLOW_rule__Distributor__AdresseAssignment_2_in_rule__Distributor__Group__2__Impl1227);
            rule__Distributor__AdresseAssignment_2();

            state._fsp--;


            }

             after(grammarAccess.getDistributorAccess().getAdresseAssignment_2()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Distributor__Group__2__Impl"


    // $ANTLR start "rule__Distributor__Group__3"
    // ../at.ac.univie.swa.ase2014.a1276754.task3.mydsl.ui/src-gen/at/ac/univie/swa/ase2014/a1276754/task3/ui/contentassist/antlr/internal/InternalMydsl.g:623:1: rule__Distributor__Group__3 : rule__Distributor__Group__3__Impl rule__Distributor__Group__4 ;
    public final void rule__Distributor__Group__3() throws RecognitionException {

        		int stackSize = keepStackSize();
            
        try {
            // ../at.ac.univie.swa.ase2014.a1276754.task3.mydsl.ui/src-gen/at/ac/univie/swa/ase2014/a1276754/task3/ui/contentassist/antlr/internal/InternalMydsl.g:627:1: ( rule__Distributor__Group__3__Impl rule__Distributor__Group__4 )
            // ../at.ac.univie.swa.ase2014.a1276754.task3.mydsl.ui/src-gen/at/ac/univie/swa/ase2014/a1276754/task3/ui/contentassist/antlr/internal/InternalMydsl.g:628:2: rule__Distributor__Group__3__Impl rule__Distributor__Group__4
            {
            pushFollow(FOLLOW_rule__Distributor__Group__3__Impl_in_rule__Distributor__Group__31257);
            rule__Distributor__Group__3__Impl();

            state._fsp--;

            pushFollow(FOLLOW_rule__Distributor__Group__4_in_rule__Distributor__Group__31260);
            rule__Distributor__Group__4();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Distributor__Group__3"


    // $ANTLR start "rule__Distributor__Group__3__Impl"
    // ../at.ac.univie.swa.ase2014.a1276754.task3.mydsl.ui/src-gen/at/ac/univie/swa/ase2014/a1276754/task3/ui/contentassist/antlr/internal/InternalMydsl.g:635:1: rule__Distributor__Group__3__Impl : ( 'Account Information:' ) ;
    public final void rule__Distributor__Group__3__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
            
        try {
            // ../at.ac.univie.swa.ase2014.a1276754.task3.mydsl.ui/src-gen/at/ac/univie/swa/ase2014/a1276754/task3/ui/contentassist/antlr/internal/InternalMydsl.g:639:1: ( ( 'Account Information:' ) )
            // ../at.ac.univie.swa.ase2014.a1276754.task3.mydsl.ui/src-gen/at/ac/univie/swa/ase2014/a1276754/task3/ui/contentassist/antlr/internal/InternalMydsl.g:640:1: ( 'Account Information:' )
            {
            // ../at.ac.univie.swa.ase2014.a1276754.task3.mydsl.ui/src-gen/at/ac/univie/swa/ase2014/a1276754/task3/ui/contentassist/antlr/internal/InternalMydsl.g:640:1: ( 'Account Information:' )
            // ../at.ac.univie.swa.ase2014.a1276754.task3.mydsl.ui/src-gen/at/ac/univie/swa/ase2014/a1276754/task3/ui/contentassist/antlr/internal/InternalMydsl.g:641:1: 'Account Information:'
            {
             before(grammarAccess.getDistributorAccess().getAccountInformationKeyword_3()); 
            match(input,21,FOLLOW_21_in_rule__Distributor__Group__3__Impl1288); 
             after(grammarAccess.getDistributorAccess().getAccountInformationKeyword_3()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Distributor__Group__3__Impl"


    // $ANTLR start "rule__Distributor__Group__4"
    // ../at.ac.univie.swa.ase2014.a1276754.task3.mydsl.ui/src-gen/at/ac/univie/swa/ase2014/a1276754/task3/ui/contentassist/antlr/internal/InternalMydsl.g:654:1: rule__Distributor__Group__4 : rule__Distributor__Group__4__Impl ;
    public final void rule__Distributor__Group__4() throws RecognitionException {

        		int stackSize = keepStackSize();
            
        try {
            // ../at.ac.univie.swa.ase2014.a1276754.task3.mydsl.ui/src-gen/at/ac/univie/swa/ase2014/a1276754/task3/ui/contentassist/antlr/internal/InternalMydsl.g:658:1: ( rule__Distributor__Group__4__Impl )
            // ../at.ac.univie.swa.ase2014.a1276754.task3.mydsl.ui/src-gen/at/ac/univie/swa/ase2014/a1276754/task3/ui/contentassist/antlr/internal/InternalMydsl.g:659:2: rule__Distributor__Group__4__Impl
            {
            pushFollow(FOLLOW_rule__Distributor__Group__4__Impl_in_rule__Distributor__Group__41319);
            rule__Distributor__Group__4__Impl();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Distributor__Group__4"


    // $ANTLR start "rule__Distributor__Group__4__Impl"
    // ../at.ac.univie.swa.ase2014.a1276754.task3.mydsl.ui/src-gen/at/ac/univie/swa/ase2014/a1276754/task3/ui/contentassist/antlr/internal/InternalMydsl.g:665:1: rule__Distributor__Group__4__Impl : ( ( rule__Distributor__Acc_infoAssignment_4 ) ) ;
    public final void rule__Distributor__Group__4__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
            
        try {
            // ../at.ac.univie.swa.ase2014.a1276754.task3.mydsl.ui/src-gen/at/ac/univie/swa/ase2014/a1276754/task3/ui/contentassist/antlr/internal/InternalMydsl.g:669:1: ( ( ( rule__Distributor__Acc_infoAssignment_4 ) ) )
            // ../at.ac.univie.swa.ase2014.a1276754.task3.mydsl.ui/src-gen/at/ac/univie/swa/ase2014/a1276754/task3/ui/contentassist/antlr/internal/InternalMydsl.g:670:1: ( ( rule__Distributor__Acc_infoAssignment_4 ) )
            {
            // ../at.ac.univie.swa.ase2014.a1276754.task3.mydsl.ui/src-gen/at/ac/univie/swa/ase2014/a1276754/task3/ui/contentassist/antlr/internal/InternalMydsl.g:670:1: ( ( rule__Distributor__Acc_infoAssignment_4 ) )
            // ../at.ac.univie.swa.ase2014.a1276754.task3.mydsl.ui/src-gen/at/ac/univie/swa/ase2014/a1276754/task3/ui/contentassist/antlr/internal/InternalMydsl.g:671:1: ( rule__Distributor__Acc_infoAssignment_4 )
            {
             before(grammarAccess.getDistributorAccess().getAcc_infoAssignment_4()); 
            // ../at.ac.univie.swa.ase2014.a1276754.task3.mydsl.ui/src-gen/at/ac/univie/swa/ase2014/a1276754/task3/ui/contentassist/antlr/internal/InternalMydsl.g:672:1: ( rule__Distributor__Acc_infoAssignment_4 )
            // ../at.ac.univie.swa.ase2014.a1276754.task3.mydsl.ui/src-gen/at/ac/univie/swa/ase2014/a1276754/task3/ui/contentassist/antlr/internal/InternalMydsl.g:672:2: rule__Distributor__Acc_infoAssignment_4
            {
            pushFollow(FOLLOW_rule__Distributor__Acc_infoAssignment_4_in_rule__Distributor__Group__4__Impl1346);
            rule__Distributor__Acc_infoAssignment_4();

            state._fsp--;


            }

             after(grammarAccess.getDistributorAccess().getAcc_infoAssignment_4()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Distributor__Group__4__Impl"


    // $ANTLR start "rule__Account_Information__Group__0"
    // ../at.ac.univie.swa.ase2014.a1276754.task3.mydsl.ui/src-gen/at/ac/univie/swa/ase2014/a1276754/task3/ui/contentassist/antlr/internal/InternalMydsl.g:692:1: rule__Account_Information__Group__0 : rule__Account_Information__Group__0__Impl rule__Account_Information__Group__1 ;
    public final void rule__Account_Information__Group__0() throws RecognitionException {

        		int stackSize = keepStackSize();
            
        try {
            // ../at.ac.univie.swa.ase2014.a1276754.task3.mydsl.ui/src-gen/at/ac/univie/swa/ase2014/a1276754/task3/ui/contentassist/antlr/internal/InternalMydsl.g:696:1: ( rule__Account_Information__Group__0__Impl rule__Account_Information__Group__1 )
            // ../at.ac.univie.swa.ase2014.a1276754.task3.mydsl.ui/src-gen/at/ac/univie/swa/ase2014/a1276754/task3/ui/contentassist/antlr/internal/InternalMydsl.g:697:2: rule__Account_Information__Group__0__Impl rule__Account_Information__Group__1
            {
            pushFollow(FOLLOW_rule__Account_Information__Group__0__Impl_in_rule__Account_Information__Group__01386);
            rule__Account_Information__Group__0__Impl();

            state._fsp--;

            pushFollow(FOLLOW_rule__Account_Information__Group__1_in_rule__Account_Information__Group__01389);
            rule__Account_Information__Group__1();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Account_Information__Group__0"


    // $ANTLR start "rule__Account_Information__Group__0__Impl"
    // ../at.ac.univie.swa.ase2014.a1276754.task3.mydsl.ui/src-gen/at/ac/univie/swa/ase2014/a1276754/task3/ui/contentassist/antlr/internal/InternalMydsl.g:704:1: rule__Account_Information__Group__0__Impl : ( 'IBAN:' ) ;
    public final void rule__Account_Information__Group__0__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
            
        try {
            // ../at.ac.univie.swa.ase2014.a1276754.task3.mydsl.ui/src-gen/at/ac/univie/swa/ase2014/a1276754/task3/ui/contentassist/antlr/internal/InternalMydsl.g:708:1: ( ( 'IBAN:' ) )
            // ../at.ac.univie.swa.ase2014.a1276754.task3.mydsl.ui/src-gen/at/ac/univie/swa/ase2014/a1276754/task3/ui/contentassist/antlr/internal/InternalMydsl.g:709:1: ( 'IBAN:' )
            {
            // ../at.ac.univie.swa.ase2014.a1276754.task3.mydsl.ui/src-gen/at/ac/univie/swa/ase2014/a1276754/task3/ui/contentassist/antlr/internal/InternalMydsl.g:709:1: ( 'IBAN:' )
            // ../at.ac.univie.swa.ase2014.a1276754.task3.mydsl.ui/src-gen/at/ac/univie/swa/ase2014/a1276754/task3/ui/contentassist/antlr/internal/InternalMydsl.g:710:1: 'IBAN:'
            {
             before(grammarAccess.getAccount_InformationAccess().getIBANKeyword_0()); 
            match(input,22,FOLLOW_22_in_rule__Account_Information__Group__0__Impl1417); 
             after(grammarAccess.getAccount_InformationAccess().getIBANKeyword_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Account_Information__Group__0__Impl"


    // $ANTLR start "rule__Account_Information__Group__1"
    // ../at.ac.univie.swa.ase2014.a1276754.task3.mydsl.ui/src-gen/at/ac/univie/swa/ase2014/a1276754/task3/ui/contentassist/antlr/internal/InternalMydsl.g:723:1: rule__Account_Information__Group__1 : rule__Account_Information__Group__1__Impl rule__Account_Information__Group__2 ;
    public final void rule__Account_Information__Group__1() throws RecognitionException {

        		int stackSize = keepStackSize();
            
        try {
            // ../at.ac.univie.swa.ase2014.a1276754.task3.mydsl.ui/src-gen/at/ac/univie/swa/ase2014/a1276754/task3/ui/contentassist/antlr/internal/InternalMydsl.g:727:1: ( rule__Account_Information__Group__1__Impl rule__Account_Information__Group__2 )
            // ../at.ac.univie.swa.ase2014.a1276754.task3.mydsl.ui/src-gen/at/ac/univie/swa/ase2014/a1276754/task3/ui/contentassist/antlr/internal/InternalMydsl.g:728:2: rule__Account_Information__Group__1__Impl rule__Account_Information__Group__2
            {
            pushFollow(FOLLOW_rule__Account_Information__Group__1__Impl_in_rule__Account_Information__Group__11448);
            rule__Account_Information__Group__1__Impl();

            state._fsp--;

            pushFollow(FOLLOW_rule__Account_Information__Group__2_in_rule__Account_Information__Group__11451);
            rule__Account_Information__Group__2();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Account_Information__Group__1"


    // $ANTLR start "rule__Account_Information__Group__1__Impl"
    // ../at.ac.univie.swa.ase2014.a1276754.task3.mydsl.ui/src-gen/at/ac/univie/swa/ase2014/a1276754/task3/ui/contentassist/antlr/internal/InternalMydsl.g:735:1: rule__Account_Information__Group__1__Impl : ( ( rule__Account_Information__IbanAssignment_1 ) ) ;
    public final void rule__Account_Information__Group__1__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
            
        try {
            // ../at.ac.univie.swa.ase2014.a1276754.task3.mydsl.ui/src-gen/at/ac/univie/swa/ase2014/a1276754/task3/ui/contentassist/antlr/internal/InternalMydsl.g:739:1: ( ( ( rule__Account_Information__IbanAssignment_1 ) ) )
            // ../at.ac.univie.swa.ase2014.a1276754.task3.mydsl.ui/src-gen/at/ac/univie/swa/ase2014/a1276754/task3/ui/contentassist/antlr/internal/InternalMydsl.g:740:1: ( ( rule__Account_Information__IbanAssignment_1 ) )
            {
            // ../at.ac.univie.swa.ase2014.a1276754.task3.mydsl.ui/src-gen/at/ac/univie/swa/ase2014/a1276754/task3/ui/contentassist/antlr/internal/InternalMydsl.g:740:1: ( ( rule__Account_Information__IbanAssignment_1 ) )
            // ../at.ac.univie.swa.ase2014.a1276754.task3.mydsl.ui/src-gen/at/ac/univie/swa/ase2014/a1276754/task3/ui/contentassist/antlr/internal/InternalMydsl.g:741:1: ( rule__Account_Information__IbanAssignment_1 )
            {
             before(grammarAccess.getAccount_InformationAccess().getIbanAssignment_1()); 
            // ../at.ac.univie.swa.ase2014.a1276754.task3.mydsl.ui/src-gen/at/ac/univie/swa/ase2014/a1276754/task3/ui/contentassist/antlr/internal/InternalMydsl.g:742:1: ( rule__Account_Information__IbanAssignment_1 )
            // ../at.ac.univie.swa.ase2014.a1276754.task3.mydsl.ui/src-gen/at/ac/univie/swa/ase2014/a1276754/task3/ui/contentassist/antlr/internal/InternalMydsl.g:742:2: rule__Account_Information__IbanAssignment_1
            {
            pushFollow(FOLLOW_rule__Account_Information__IbanAssignment_1_in_rule__Account_Information__Group__1__Impl1478);
            rule__Account_Information__IbanAssignment_1();

            state._fsp--;


            }

             after(grammarAccess.getAccount_InformationAccess().getIbanAssignment_1()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Account_Information__Group__1__Impl"


    // $ANTLR start "rule__Account_Information__Group__2"
    // ../at.ac.univie.swa.ase2014.a1276754.task3.mydsl.ui/src-gen/at/ac/univie/swa/ase2014/a1276754/task3/ui/contentassist/antlr/internal/InternalMydsl.g:752:1: rule__Account_Information__Group__2 : rule__Account_Information__Group__2__Impl rule__Account_Information__Group__3 ;
    public final void rule__Account_Information__Group__2() throws RecognitionException {

        		int stackSize = keepStackSize();
            
        try {
            // ../at.ac.univie.swa.ase2014.a1276754.task3.mydsl.ui/src-gen/at/ac/univie/swa/ase2014/a1276754/task3/ui/contentassist/antlr/internal/InternalMydsl.g:756:1: ( rule__Account_Information__Group__2__Impl rule__Account_Information__Group__3 )
            // ../at.ac.univie.swa.ase2014.a1276754.task3.mydsl.ui/src-gen/at/ac/univie/swa/ase2014/a1276754/task3/ui/contentassist/antlr/internal/InternalMydsl.g:757:2: rule__Account_Information__Group__2__Impl rule__Account_Information__Group__3
            {
            pushFollow(FOLLOW_rule__Account_Information__Group__2__Impl_in_rule__Account_Information__Group__21508);
            rule__Account_Information__Group__2__Impl();

            state._fsp--;

            pushFollow(FOLLOW_rule__Account_Information__Group__3_in_rule__Account_Information__Group__21511);
            rule__Account_Information__Group__3();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Account_Information__Group__2"


    // $ANTLR start "rule__Account_Information__Group__2__Impl"
    // ../at.ac.univie.swa.ase2014.a1276754.task3.mydsl.ui/src-gen/at/ac/univie/swa/ase2014/a1276754/task3/ui/contentassist/antlr/internal/InternalMydsl.g:764:1: rule__Account_Information__Group__2__Impl : ( 'BIC:' ) ;
    public final void rule__Account_Information__Group__2__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
            
        try {
            // ../at.ac.univie.swa.ase2014.a1276754.task3.mydsl.ui/src-gen/at/ac/univie/swa/ase2014/a1276754/task3/ui/contentassist/antlr/internal/InternalMydsl.g:768:1: ( ( 'BIC:' ) )
            // ../at.ac.univie.swa.ase2014.a1276754.task3.mydsl.ui/src-gen/at/ac/univie/swa/ase2014/a1276754/task3/ui/contentassist/antlr/internal/InternalMydsl.g:769:1: ( 'BIC:' )
            {
            // ../at.ac.univie.swa.ase2014.a1276754.task3.mydsl.ui/src-gen/at/ac/univie/swa/ase2014/a1276754/task3/ui/contentassist/antlr/internal/InternalMydsl.g:769:1: ( 'BIC:' )
            // ../at.ac.univie.swa.ase2014.a1276754.task3.mydsl.ui/src-gen/at/ac/univie/swa/ase2014/a1276754/task3/ui/contentassist/antlr/internal/InternalMydsl.g:770:1: 'BIC:'
            {
             before(grammarAccess.getAccount_InformationAccess().getBICKeyword_2()); 
            match(input,23,FOLLOW_23_in_rule__Account_Information__Group__2__Impl1539); 
             after(grammarAccess.getAccount_InformationAccess().getBICKeyword_2()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Account_Information__Group__2__Impl"


    // $ANTLR start "rule__Account_Information__Group__3"
    // ../at.ac.univie.swa.ase2014.a1276754.task3.mydsl.ui/src-gen/at/ac/univie/swa/ase2014/a1276754/task3/ui/contentassist/antlr/internal/InternalMydsl.g:783:1: rule__Account_Information__Group__3 : rule__Account_Information__Group__3__Impl ;
    public final void rule__Account_Information__Group__3() throws RecognitionException {

        		int stackSize = keepStackSize();
            
        try {
            // ../at.ac.univie.swa.ase2014.a1276754.task3.mydsl.ui/src-gen/at/ac/univie/swa/ase2014/a1276754/task3/ui/contentassist/antlr/internal/InternalMydsl.g:787:1: ( rule__Account_Information__Group__3__Impl )
            // ../at.ac.univie.swa.ase2014.a1276754.task3.mydsl.ui/src-gen/at/ac/univie/swa/ase2014/a1276754/task3/ui/contentassist/antlr/internal/InternalMydsl.g:788:2: rule__Account_Information__Group__3__Impl
            {
            pushFollow(FOLLOW_rule__Account_Information__Group__3__Impl_in_rule__Account_Information__Group__31570);
            rule__Account_Information__Group__3__Impl();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Account_Information__Group__3"


    // $ANTLR start "rule__Account_Information__Group__3__Impl"
    // ../at.ac.univie.swa.ase2014.a1276754.task3.mydsl.ui/src-gen/at/ac/univie/swa/ase2014/a1276754/task3/ui/contentassist/antlr/internal/InternalMydsl.g:794:1: rule__Account_Information__Group__3__Impl : ( ( rule__Account_Information__BicAssignment_3 ) ) ;
    public final void rule__Account_Information__Group__3__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
            
        try {
            // ../at.ac.univie.swa.ase2014.a1276754.task3.mydsl.ui/src-gen/at/ac/univie/swa/ase2014/a1276754/task3/ui/contentassist/antlr/internal/InternalMydsl.g:798:1: ( ( ( rule__Account_Information__BicAssignment_3 ) ) )
            // ../at.ac.univie.swa.ase2014.a1276754.task3.mydsl.ui/src-gen/at/ac/univie/swa/ase2014/a1276754/task3/ui/contentassist/antlr/internal/InternalMydsl.g:799:1: ( ( rule__Account_Information__BicAssignment_3 ) )
            {
            // ../at.ac.univie.swa.ase2014.a1276754.task3.mydsl.ui/src-gen/at/ac/univie/swa/ase2014/a1276754/task3/ui/contentassist/antlr/internal/InternalMydsl.g:799:1: ( ( rule__Account_Information__BicAssignment_3 ) )
            // ../at.ac.univie.swa.ase2014.a1276754.task3.mydsl.ui/src-gen/at/ac/univie/swa/ase2014/a1276754/task3/ui/contentassist/antlr/internal/InternalMydsl.g:800:1: ( rule__Account_Information__BicAssignment_3 )
            {
             before(grammarAccess.getAccount_InformationAccess().getBicAssignment_3()); 
            // ../at.ac.univie.swa.ase2014.a1276754.task3.mydsl.ui/src-gen/at/ac/univie/swa/ase2014/a1276754/task3/ui/contentassist/antlr/internal/InternalMydsl.g:801:1: ( rule__Account_Information__BicAssignment_3 )
            // ../at.ac.univie.swa.ase2014.a1276754.task3.mydsl.ui/src-gen/at/ac/univie/swa/ase2014/a1276754/task3/ui/contentassist/antlr/internal/InternalMydsl.g:801:2: rule__Account_Information__BicAssignment_3
            {
            pushFollow(FOLLOW_rule__Account_Information__BicAssignment_3_in_rule__Account_Information__Group__3__Impl1597);
            rule__Account_Information__BicAssignment_3();

            state._fsp--;


            }

             after(grammarAccess.getAccount_InformationAccess().getBicAssignment_3()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Account_Information__Group__3__Impl"


    // $ANTLR start "rule__Song__Group__0"
    // ../at.ac.univie.swa.ase2014.a1276754.task3.mydsl.ui/src-gen/at/ac/univie/swa/ase2014/a1276754/task3/ui/contentassist/antlr/internal/InternalMydsl.g:819:1: rule__Song__Group__0 : rule__Song__Group__0__Impl rule__Song__Group__1 ;
    public final void rule__Song__Group__0() throws RecognitionException {

        		int stackSize = keepStackSize();
            
        try {
            // ../at.ac.univie.swa.ase2014.a1276754.task3.mydsl.ui/src-gen/at/ac/univie/swa/ase2014/a1276754/task3/ui/contentassist/antlr/internal/InternalMydsl.g:823:1: ( rule__Song__Group__0__Impl rule__Song__Group__1 )
            // ../at.ac.univie.swa.ase2014.a1276754.task3.mydsl.ui/src-gen/at/ac/univie/swa/ase2014/a1276754/task3/ui/contentassist/antlr/internal/InternalMydsl.g:824:2: rule__Song__Group__0__Impl rule__Song__Group__1
            {
            pushFollow(FOLLOW_rule__Song__Group__0__Impl_in_rule__Song__Group__01635);
            rule__Song__Group__0__Impl();

            state._fsp--;

            pushFollow(FOLLOW_rule__Song__Group__1_in_rule__Song__Group__01638);
            rule__Song__Group__1();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Song__Group__0"


    // $ANTLR start "rule__Song__Group__0__Impl"
    // ../at.ac.univie.swa.ase2014.a1276754.task3.mydsl.ui/src-gen/at/ac/univie/swa/ase2014/a1276754/task3/ui/contentassist/antlr/internal/InternalMydsl.g:831:1: rule__Song__Group__0__Impl : ( ( rule__Song__NameAssignment_0 ) ) ;
    public final void rule__Song__Group__0__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
            
        try {
            // ../at.ac.univie.swa.ase2014.a1276754.task3.mydsl.ui/src-gen/at/ac/univie/swa/ase2014/a1276754/task3/ui/contentassist/antlr/internal/InternalMydsl.g:835:1: ( ( ( rule__Song__NameAssignment_0 ) ) )
            // ../at.ac.univie.swa.ase2014.a1276754.task3.mydsl.ui/src-gen/at/ac/univie/swa/ase2014/a1276754/task3/ui/contentassist/antlr/internal/InternalMydsl.g:836:1: ( ( rule__Song__NameAssignment_0 ) )
            {
            // ../at.ac.univie.swa.ase2014.a1276754.task3.mydsl.ui/src-gen/at/ac/univie/swa/ase2014/a1276754/task3/ui/contentassist/antlr/internal/InternalMydsl.g:836:1: ( ( rule__Song__NameAssignment_0 ) )
            // ../at.ac.univie.swa.ase2014.a1276754.task3.mydsl.ui/src-gen/at/ac/univie/swa/ase2014/a1276754/task3/ui/contentassist/antlr/internal/InternalMydsl.g:837:1: ( rule__Song__NameAssignment_0 )
            {
             before(grammarAccess.getSongAccess().getNameAssignment_0()); 
            // ../at.ac.univie.swa.ase2014.a1276754.task3.mydsl.ui/src-gen/at/ac/univie/swa/ase2014/a1276754/task3/ui/contentassist/antlr/internal/InternalMydsl.g:838:1: ( rule__Song__NameAssignment_0 )
            // ../at.ac.univie.swa.ase2014.a1276754.task3.mydsl.ui/src-gen/at/ac/univie/swa/ase2014/a1276754/task3/ui/contentassist/antlr/internal/InternalMydsl.g:838:2: rule__Song__NameAssignment_0
            {
            pushFollow(FOLLOW_rule__Song__NameAssignment_0_in_rule__Song__Group__0__Impl1665);
            rule__Song__NameAssignment_0();

            state._fsp--;


            }

             after(grammarAccess.getSongAccess().getNameAssignment_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Song__Group__0__Impl"


    // $ANTLR start "rule__Song__Group__1"
    // ../at.ac.univie.swa.ase2014.a1276754.task3.mydsl.ui/src-gen/at/ac/univie/swa/ase2014/a1276754/task3/ui/contentassist/antlr/internal/InternalMydsl.g:848:1: rule__Song__Group__1 : rule__Song__Group__1__Impl rule__Song__Group__2 ;
    public final void rule__Song__Group__1() throws RecognitionException {

        		int stackSize = keepStackSize();
            
        try {
            // ../at.ac.univie.swa.ase2014.a1276754.task3.mydsl.ui/src-gen/at/ac/univie/swa/ase2014/a1276754/task3/ui/contentassist/antlr/internal/InternalMydsl.g:852:1: ( rule__Song__Group__1__Impl rule__Song__Group__2 )
            // ../at.ac.univie.swa.ase2014.a1276754.task3.mydsl.ui/src-gen/at/ac/univie/swa/ase2014/a1276754/task3/ui/contentassist/antlr/internal/InternalMydsl.g:853:2: rule__Song__Group__1__Impl rule__Song__Group__2
            {
            pushFollow(FOLLOW_rule__Song__Group__1__Impl_in_rule__Song__Group__11695);
            rule__Song__Group__1__Impl();

            state._fsp--;

            pushFollow(FOLLOW_rule__Song__Group__2_in_rule__Song__Group__11698);
            rule__Song__Group__2();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Song__Group__1"


    // $ANTLR start "rule__Song__Group__1__Impl"
    // ../at.ac.univie.swa.ase2014.a1276754.task3.mydsl.ui/src-gen/at/ac/univie/swa/ase2014/a1276754/task3/ui/contentassist/antlr/internal/InternalMydsl.g:860:1: rule__Song__Group__1__Impl : ( 'sung by' ) ;
    public final void rule__Song__Group__1__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
            
        try {
            // ../at.ac.univie.swa.ase2014.a1276754.task3.mydsl.ui/src-gen/at/ac/univie/swa/ase2014/a1276754/task3/ui/contentassist/antlr/internal/InternalMydsl.g:864:1: ( ( 'sung by' ) )
            // ../at.ac.univie.swa.ase2014.a1276754.task3.mydsl.ui/src-gen/at/ac/univie/swa/ase2014/a1276754/task3/ui/contentassist/antlr/internal/InternalMydsl.g:865:1: ( 'sung by' )
            {
            // ../at.ac.univie.swa.ase2014.a1276754.task3.mydsl.ui/src-gen/at/ac/univie/swa/ase2014/a1276754/task3/ui/contentassist/antlr/internal/InternalMydsl.g:865:1: ( 'sung by' )
            // ../at.ac.univie.swa.ase2014.a1276754.task3.mydsl.ui/src-gen/at/ac/univie/swa/ase2014/a1276754/task3/ui/contentassist/antlr/internal/InternalMydsl.g:866:1: 'sung by'
            {
             before(grammarAccess.getSongAccess().getSungByKeyword_1()); 
            match(input,24,FOLLOW_24_in_rule__Song__Group__1__Impl1726); 
             after(grammarAccess.getSongAccess().getSungByKeyword_1()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Song__Group__1__Impl"


    // $ANTLR start "rule__Song__Group__2"
    // ../at.ac.univie.swa.ase2014.a1276754.task3.mydsl.ui/src-gen/at/ac/univie/swa/ase2014/a1276754/task3/ui/contentassist/antlr/internal/InternalMydsl.g:879:1: rule__Song__Group__2 : rule__Song__Group__2__Impl rule__Song__Group__3 ;
    public final void rule__Song__Group__2() throws RecognitionException {

        		int stackSize = keepStackSize();
            
        try {
            // ../at.ac.univie.swa.ase2014.a1276754.task3.mydsl.ui/src-gen/at/ac/univie/swa/ase2014/a1276754/task3/ui/contentassist/antlr/internal/InternalMydsl.g:883:1: ( rule__Song__Group__2__Impl rule__Song__Group__3 )
            // ../at.ac.univie.swa.ase2014.a1276754.task3.mydsl.ui/src-gen/at/ac/univie/swa/ase2014/a1276754/task3/ui/contentassist/antlr/internal/InternalMydsl.g:884:2: rule__Song__Group__2__Impl rule__Song__Group__3
            {
            pushFollow(FOLLOW_rule__Song__Group__2__Impl_in_rule__Song__Group__21757);
            rule__Song__Group__2__Impl();

            state._fsp--;

            pushFollow(FOLLOW_rule__Song__Group__3_in_rule__Song__Group__21760);
            rule__Song__Group__3();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Song__Group__2"


    // $ANTLR start "rule__Song__Group__2__Impl"
    // ../at.ac.univie.swa.ase2014.a1276754.task3.mydsl.ui/src-gen/at/ac/univie/swa/ase2014/a1276754/task3/ui/contentassist/antlr/internal/InternalMydsl.g:891:1: rule__Song__Group__2__Impl : ( ( rule__Song__ArtistAssignment_2 ) ) ;
    public final void rule__Song__Group__2__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
            
        try {
            // ../at.ac.univie.swa.ase2014.a1276754.task3.mydsl.ui/src-gen/at/ac/univie/swa/ase2014/a1276754/task3/ui/contentassist/antlr/internal/InternalMydsl.g:895:1: ( ( ( rule__Song__ArtistAssignment_2 ) ) )
            // ../at.ac.univie.swa.ase2014.a1276754.task3.mydsl.ui/src-gen/at/ac/univie/swa/ase2014/a1276754/task3/ui/contentassist/antlr/internal/InternalMydsl.g:896:1: ( ( rule__Song__ArtistAssignment_2 ) )
            {
            // ../at.ac.univie.swa.ase2014.a1276754.task3.mydsl.ui/src-gen/at/ac/univie/swa/ase2014/a1276754/task3/ui/contentassist/antlr/internal/InternalMydsl.g:896:1: ( ( rule__Song__ArtistAssignment_2 ) )
            // ../at.ac.univie.swa.ase2014.a1276754.task3.mydsl.ui/src-gen/at/ac/univie/swa/ase2014/a1276754/task3/ui/contentassist/antlr/internal/InternalMydsl.g:897:1: ( rule__Song__ArtistAssignment_2 )
            {
             before(grammarAccess.getSongAccess().getArtistAssignment_2()); 
            // ../at.ac.univie.swa.ase2014.a1276754.task3.mydsl.ui/src-gen/at/ac/univie/swa/ase2014/a1276754/task3/ui/contentassist/antlr/internal/InternalMydsl.g:898:1: ( rule__Song__ArtistAssignment_2 )
            // ../at.ac.univie.swa.ase2014.a1276754.task3.mydsl.ui/src-gen/at/ac/univie/swa/ase2014/a1276754/task3/ui/contentassist/antlr/internal/InternalMydsl.g:898:2: rule__Song__ArtistAssignment_2
            {
            pushFollow(FOLLOW_rule__Song__ArtistAssignment_2_in_rule__Song__Group__2__Impl1787);
            rule__Song__ArtistAssignment_2();

            state._fsp--;


            }

             after(grammarAccess.getSongAccess().getArtistAssignment_2()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Song__Group__2__Impl"


    // $ANTLR start "rule__Song__Group__3"
    // ../at.ac.univie.swa.ase2014.a1276754.task3.mydsl.ui/src-gen/at/ac/univie/swa/ase2014/a1276754/task3/ui/contentassist/antlr/internal/InternalMydsl.g:908:1: rule__Song__Group__3 : rule__Song__Group__3__Impl rule__Song__Group__4 ;
    public final void rule__Song__Group__3() throws RecognitionException {

        		int stackSize = keepStackSize();
            
        try {
            // ../at.ac.univie.swa.ase2014.a1276754.task3.mydsl.ui/src-gen/at/ac/univie/swa/ase2014/a1276754/task3/ui/contentassist/antlr/internal/InternalMydsl.g:912:1: ( rule__Song__Group__3__Impl rule__Song__Group__4 )
            // ../at.ac.univie.swa.ase2014.a1276754.task3.mydsl.ui/src-gen/at/ac/univie/swa/ase2014/a1276754/task3/ui/contentassist/antlr/internal/InternalMydsl.g:913:2: rule__Song__Group__3__Impl rule__Song__Group__4
            {
            pushFollow(FOLLOW_rule__Song__Group__3__Impl_in_rule__Song__Group__31817);
            rule__Song__Group__3__Impl();

            state._fsp--;

            pushFollow(FOLLOW_rule__Song__Group__4_in_rule__Song__Group__31820);
            rule__Song__Group__4();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Song__Group__3"


    // $ANTLR start "rule__Song__Group__3__Impl"
    // ../at.ac.univie.swa.ase2014.a1276754.task3.mydsl.ui/src-gen/at/ac/univie/swa/ase2014/a1276754/task3/ui/contentassist/antlr/internal/InternalMydsl.g:920:1: rule__Song__Group__3__Impl : ( 'produced by' ) ;
    public final void rule__Song__Group__3__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
            
        try {
            // ../at.ac.univie.swa.ase2014.a1276754.task3.mydsl.ui/src-gen/at/ac/univie/swa/ase2014/a1276754/task3/ui/contentassist/antlr/internal/InternalMydsl.g:924:1: ( ( 'produced by' ) )
            // ../at.ac.univie.swa.ase2014.a1276754.task3.mydsl.ui/src-gen/at/ac/univie/swa/ase2014/a1276754/task3/ui/contentassist/antlr/internal/InternalMydsl.g:925:1: ( 'produced by' )
            {
            // ../at.ac.univie.swa.ase2014.a1276754.task3.mydsl.ui/src-gen/at/ac/univie/swa/ase2014/a1276754/task3/ui/contentassist/antlr/internal/InternalMydsl.g:925:1: ( 'produced by' )
            // ../at.ac.univie.swa.ase2014.a1276754.task3.mydsl.ui/src-gen/at/ac/univie/swa/ase2014/a1276754/task3/ui/contentassist/antlr/internal/InternalMydsl.g:926:1: 'produced by'
            {
             before(grammarAccess.getSongAccess().getProducedByKeyword_3()); 
            match(input,25,FOLLOW_25_in_rule__Song__Group__3__Impl1848); 
             after(grammarAccess.getSongAccess().getProducedByKeyword_3()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Song__Group__3__Impl"


    // $ANTLR start "rule__Song__Group__4"
    // ../at.ac.univie.swa.ase2014.a1276754.task3.mydsl.ui/src-gen/at/ac/univie/swa/ase2014/a1276754/task3/ui/contentassist/antlr/internal/InternalMydsl.g:939:1: rule__Song__Group__4 : rule__Song__Group__4__Impl rule__Song__Group__5 ;
    public final void rule__Song__Group__4() throws RecognitionException {

        		int stackSize = keepStackSize();
            
        try {
            // ../at.ac.univie.swa.ase2014.a1276754.task3.mydsl.ui/src-gen/at/ac/univie/swa/ase2014/a1276754/task3/ui/contentassist/antlr/internal/InternalMydsl.g:943:1: ( rule__Song__Group__4__Impl rule__Song__Group__5 )
            // ../at.ac.univie.swa.ase2014.a1276754.task3.mydsl.ui/src-gen/at/ac/univie/swa/ase2014/a1276754/task3/ui/contentassist/antlr/internal/InternalMydsl.g:944:2: rule__Song__Group__4__Impl rule__Song__Group__5
            {
            pushFollow(FOLLOW_rule__Song__Group__4__Impl_in_rule__Song__Group__41879);
            rule__Song__Group__4__Impl();

            state._fsp--;

            pushFollow(FOLLOW_rule__Song__Group__5_in_rule__Song__Group__41882);
            rule__Song__Group__5();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Song__Group__4"


    // $ANTLR start "rule__Song__Group__4__Impl"
    // ../at.ac.univie.swa.ase2014.a1276754.task3.mydsl.ui/src-gen/at/ac/univie/swa/ase2014/a1276754/task3/ui/contentassist/antlr/internal/InternalMydsl.g:951:1: rule__Song__Group__4__Impl : ( ( rule__Song__DistAssignment_4 ) ) ;
    public final void rule__Song__Group__4__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
            
        try {
            // ../at.ac.univie.swa.ase2014.a1276754.task3.mydsl.ui/src-gen/at/ac/univie/swa/ase2014/a1276754/task3/ui/contentassist/antlr/internal/InternalMydsl.g:955:1: ( ( ( rule__Song__DistAssignment_4 ) ) )
            // ../at.ac.univie.swa.ase2014.a1276754.task3.mydsl.ui/src-gen/at/ac/univie/swa/ase2014/a1276754/task3/ui/contentassist/antlr/internal/InternalMydsl.g:956:1: ( ( rule__Song__DistAssignment_4 ) )
            {
            // ../at.ac.univie.swa.ase2014.a1276754.task3.mydsl.ui/src-gen/at/ac/univie/swa/ase2014/a1276754/task3/ui/contentassist/antlr/internal/InternalMydsl.g:956:1: ( ( rule__Song__DistAssignment_4 ) )
            // ../at.ac.univie.swa.ase2014.a1276754.task3.mydsl.ui/src-gen/at/ac/univie/swa/ase2014/a1276754/task3/ui/contentassist/antlr/internal/InternalMydsl.g:957:1: ( rule__Song__DistAssignment_4 )
            {
             before(grammarAccess.getSongAccess().getDistAssignment_4()); 
            // ../at.ac.univie.swa.ase2014.a1276754.task3.mydsl.ui/src-gen/at/ac/univie/swa/ase2014/a1276754/task3/ui/contentassist/antlr/internal/InternalMydsl.g:958:1: ( rule__Song__DistAssignment_4 )
            // ../at.ac.univie.swa.ase2014.a1276754.task3.mydsl.ui/src-gen/at/ac/univie/swa/ase2014/a1276754/task3/ui/contentassist/antlr/internal/InternalMydsl.g:958:2: rule__Song__DistAssignment_4
            {
            pushFollow(FOLLOW_rule__Song__DistAssignment_4_in_rule__Song__Group__4__Impl1909);
            rule__Song__DistAssignment_4();

            state._fsp--;


            }

             after(grammarAccess.getSongAccess().getDistAssignment_4()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Song__Group__4__Impl"


    // $ANTLR start "rule__Song__Group__5"
    // ../at.ac.univie.swa.ase2014.a1276754.task3.mydsl.ui/src-gen/at/ac/univie/swa/ase2014/a1276754/task3/ui/contentassist/antlr/internal/InternalMydsl.g:968:1: rule__Song__Group__5 : rule__Song__Group__5__Impl rule__Song__Group__6 ;
    public final void rule__Song__Group__5() throws RecognitionException {

        		int stackSize = keepStackSize();
            
        try {
            // ../at.ac.univie.swa.ase2014.a1276754.task3.mydsl.ui/src-gen/at/ac/univie/swa/ase2014/a1276754/task3/ui/contentassist/antlr/internal/InternalMydsl.g:972:1: ( rule__Song__Group__5__Impl rule__Song__Group__6 )
            // ../at.ac.univie.swa.ase2014.a1276754.task3.mydsl.ui/src-gen/at/ac/univie/swa/ase2014/a1276754/task3/ui/contentassist/antlr/internal/InternalMydsl.g:973:2: rule__Song__Group__5__Impl rule__Song__Group__6
            {
            pushFollow(FOLLOW_rule__Song__Group__5__Impl_in_rule__Song__Group__51939);
            rule__Song__Group__5__Impl();

            state._fsp--;

            pushFollow(FOLLOW_rule__Song__Group__6_in_rule__Song__Group__51942);
            rule__Song__Group__6();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Song__Group__5"


    // $ANTLR start "rule__Song__Group__5__Impl"
    // ../at.ac.univie.swa.ase2014.a1276754.task3.mydsl.ui/src-gen/at/ac/univie/swa/ase2014/a1276754/task3/ui/contentassist/antlr/internal/InternalMydsl.g:980:1: rule__Song__Group__5__Impl : ( 'length:' ) ;
    public final void rule__Song__Group__5__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
            
        try {
            // ../at.ac.univie.swa.ase2014.a1276754.task3.mydsl.ui/src-gen/at/ac/univie/swa/ase2014/a1276754/task3/ui/contentassist/antlr/internal/InternalMydsl.g:984:1: ( ( 'length:' ) )
            // ../at.ac.univie.swa.ase2014.a1276754.task3.mydsl.ui/src-gen/at/ac/univie/swa/ase2014/a1276754/task3/ui/contentassist/antlr/internal/InternalMydsl.g:985:1: ( 'length:' )
            {
            // ../at.ac.univie.swa.ase2014.a1276754.task3.mydsl.ui/src-gen/at/ac/univie/swa/ase2014/a1276754/task3/ui/contentassist/antlr/internal/InternalMydsl.g:985:1: ( 'length:' )
            // ../at.ac.univie.swa.ase2014.a1276754.task3.mydsl.ui/src-gen/at/ac/univie/swa/ase2014/a1276754/task3/ui/contentassist/antlr/internal/InternalMydsl.g:986:1: 'length:'
            {
             before(grammarAccess.getSongAccess().getLengthKeyword_5()); 
            match(input,26,FOLLOW_26_in_rule__Song__Group__5__Impl1970); 
             after(grammarAccess.getSongAccess().getLengthKeyword_5()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Song__Group__5__Impl"


    // $ANTLR start "rule__Song__Group__6"
    // ../at.ac.univie.swa.ase2014.a1276754.task3.mydsl.ui/src-gen/at/ac/univie/swa/ase2014/a1276754/task3/ui/contentassist/antlr/internal/InternalMydsl.g:999:1: rule__Song__Group__6 : rule__Song__Group__6__Impl rule__Song__Group__7 ;
    public final void rule__Song__Group__6() throws RecognitionException {

        		int stackSize = keepStackSize();
            
        try {
            // ../at.ac.univie.swa.ase2014.a1276754.task3.mydsl.ui/src-gen/at/ac/univie/swa/ase2014/a1276754/task3/ui/contentassist/antlr/internal/InternalMydsl.g:1003:1: ( rule__Song__Group__6__Impl rule__Song__Group__7 )
            // ../at.ac.univie.swa.ase2014.a1276754.task3.mydsl.ui/src-gen/at/ac/univie/swa/ase2014/a1276754/task3/ui/contentassist/antlr/internal/InternalMydsl.g:1004:2: rule__Song__Group__6__Impl rule__Song__Group__7
            {
            pushFollow(FOLLOW_rule__Song__Group__6__Impl_in_rule__Song__Group__62001);
            rule__Song__Group__6__Impl();

            state._fsp--;

            pushFollow(FOLLOW_rule__Song__Group__7_in_rule__Song__Group__62004);
            rule__Song__Group__7();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Song__Group__6"


    // $ANTLR start "rule__Song__Group__6__Impl"
    // ../at.ac.univie.swa.ase2014.a1276754.task3.mydsl.ui/src-gen/at/ac/univie/swa/ase2014/a1276754/task3/ui/contentassist/antlr/internal/InternalMydsl.g:1011:1: rule__Song__Group__6__Impl : ( ( rule__Song__LengthAssignment_6 ) ) ;
    public final void rule__Song__Group__6__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
            
        try {
            // ../at.ac.univie.swa.ase2014.a1276754.task3.mydsl.ui/src-gen/at/ac/univie/swa/ase2014/a1276754/task3/ui/contentassist/antlr/internal/InternalMydsl.g:1015:1: ( ( ( rule__Song__LengthAssignment_6 ) ) )
            // ../at.ac.univie.swa.ase2014.a1276754.task3.mydsl.ui/src-gen/at/ac/univie/swa/ase2014/a1276754/task3/ui/contentassist/antlr/internal/InternalMydsl.g:1016:1: ( ( rule__Song__LengthAssignment_6 ) )
            {
            // ../at.ac.univie.swa.ase2014.a1276754.task3.mydsl.ui/src-gen/at/ac/univie/swa/ase2014/a1276754/task3/ui/contentassist/antlr/internal/InternalMydsl.g:1016:1: ( ( rule__Song__LengthAssignment_6 ) )
            // ../at.ac.univie.swa.ase2014.a1276754.task3.mydsl.ui/src-gen/at/ac/univie/swa/ase2014/a1276754/task3/ui/contentassist/antlr/internal/InternalMydsl.g:1017:1: ( rule__Song__LengthAssignment_6 )
            {
             before(grammarAccess.getSongAccess().getLengthAssignment_6()); 
            // ../at.ac.univie.swa.ase2014.a1276754.task3.mydsl.ui/src-gen/at/ac/univie/swa/ase2014/a1276754/task3/ui/contentassist/antlr/internal/InternalMydsl.g:1018:1: ( rule__Song__LengthAssignment_6 )
            // ../at.ac.univie.swa.ase2014.a1276754.task3.mydsl.ui/src-gen/at/ac/univie/swa/ase2014/a1276754/task3/ui/contentassist/antlr/internal/InternalMydsl.g:1018:2: rule__Song__LengthAssignment_6
            {
            pushFollow(FOLLOW_rule__Song__LengthAssignment_6_in_rule__Song__Group__6__Impl2031);
            rule__Song__LengthAssignment_6();

            state._fsp--;


            }

             after(grammarAccess.getSongAccess().getLengthAssignment_6()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Song__Group__6__Impl"


    // $ANTLR start "rule__Song__Group__7"
    // ../at.ac.univie.swa.ase2014.a1276754.task3.mydsl.ui/src-gen/at/ac/univie/swa/ase2014/a1276754/task3/ui/contentassist/antlr/internal/InternalMydsl.g:1028:1: rule__Song__Group__7 : rule__Song__Group__7__Impl rule__Song__Group__8 ;
    public final void rule__Song__Group__7() throws RecognitionException {

        		int stackSize = keepStackSize();
            
        try {
            // ../at.ac.univie.swa.ase2014.a1276754.task3.mydsl.ui/src-gen/at/ac/univie/swa/ase2014/a1276754/task3/ui/contentassist/antlr/internal/InternalMydsl.g:1032:1: ( rule__Song__Group__7__Impl rule__Song__Group__8 )
            // ../at.ac.univie.swa.ase2014.a1276754.task3.mydsl.ui/src-gen/at/ac/univie/swa/ase2014/a1276754/task3/ui/contentassist/antlr/internal/InternalMydsl.g:1033:2: rule__Song__Group__7__Impl rule__Song__Group__8
            {
            pushFollow(FOLLOW_rule__Song__Group__7__Impl_in_rule__Song__Group__72061);
            rule__Song__Group__7__Impl();

            state._fsp--;

            pushFollow(FOLLOW_rule__Song__Group__8_in_rule__Song__Group__72064);
            rule__Song__Group__8();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Song__Group__7"


    // $ANTLR start "rule__Song__Group__7__Impl"
    // ../at.ac.univie.swa.ase2014.a1276754.task3.mydsl.ui/src-gen/at/ac/univie/swa/ase2014/a1276754/task3/ui/contentassist/antlr/internal/InternalMydsl.g:1040:1: rule__Song__Group__7__Impl : ( 'genre:' ) ;
    public final void rule__Song__Group__7__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
            
        try {
            // ../at.ac.univie.swa.ase2014.a1276754.task3.mydsl.ui/src-gen/at/ac/univie/swa/ase2014/a1276754/task3/ui/contentassist/antlr/internal/InternalMydsl.g:1044:1: ( ( 'genre:' ) )
            // ../at.ac.univie.swa.ase2014.a1276754.task3.mydsl.ui/src-gen/at/ac/univie/swa/ase2014/a1276754/task3/ui/contentassist/antlr/internal/InternalMydsl.g:1045:1: ( 'genre:' )
            {
            // ../at.ac.univie.swa.ase2014.a1276754.task3.mydsl.ui/src-gen/at/ac/univie/swa/ase2014/a1276754/task3/ui/contentassist/antlr/internal/InternalMydsl.g:1045:1: ( 'genre:' )
            // ../at.ac.univie.swa.ase2014.a1276754.task3.mydsl.ui/src-gen/at/ac/univie/swa/ase2014/a1276754/task3/ui/contentassist/antlr/internal/InternalMydsl.g:1046:1: 'genre:'
            {
             before(grammarAccess.getSongAccess().getGenreKeyword_7()); 
            match(input,27,FOLLOW_27_in_rule__Song__Group__7__Impl2092); 
             after(grammarAccess.getSongAccess().getGenreKeyword_7()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Song__Group__7__Impl"


    // $ANTLR start "rule__Song__Group__8"
    // ../at.ac.univie.swa.ase2014.a1276754.task3.mydsl.ui/src-gen/at/ac/univie/swa/ase2014/a1276754/task3/ui/contentassist/antlr/internal/InternalMydsl.g:1059:1: rule__Song__Group__8 : rule__Song__Group__8__Impl rule__Song__Group__9 ;
    public final void rule__Song__Group__8() throws RecognitionException {

        		int stackSize = keepStackSize();
            
        try {
            // ../at.ac.univie.swa.ase2014.a1276754.task3.mydsl.ui/src-gen/at/ac/univie/swa/ase2014/a1276754/task3/ui/contentassist/antlr/internal/InternalMydsl.g:1063:1: ( rule__Song__Group__8__Impl rule__Song__Group__9 )
            // ../at.ac.univie.swa.ase2014.a1276754.task3.mydsl.ui/src-gen/at/ac/univie/swa/ase2014/a1276754/task3/ui/contentassist/antlr/internal/InternalMydsl.g:1064:2: rule__Song__Group__8__Impl rule__Song__Group__9
            {
            pushFollow(FOLLOW_rule__Song__Group__8__Impl_in_rule__Song__Group__82123);
            rule__Song__Group__8__Impl();

            state._fsp--;

            pushFollow(FOLLOW_rule__Song__Group__9_in_rule__Song__Group__82126);
            rule__Song__Group__9();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Song__Group__8"


    // $ANTLR start "rule__Song__Group__8__Impl"
    // ../at.ac.univie.swa.ase2014.a1276754.task3.mydsl.ui/src-gen/at/ac/univie/swa/ase2014/a1276754/task3/ui/contentassist/antlr/internal/InternalMydsl.g:1071:1: rule__Song__Group__8__Impl : ( ( rule__Song__GenreAssignment_8 ) ) ;
    public final void rule__Song__Group__8__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
            
        try {
            // ../at.ac.univie.swa.ase2014.a1276754.task3.mydsl.ui/src-gen/at/ac/univie/swa/ase2014/a1276754/task3/ui/contentassist/antlr/internal/InternalMydsl.g:1075:1: ( ( ( rule__Song__GenreAssignment_8 ) ) )
            // ../at.ac.univie.swa.ase2014.a1276754.task3.mydsl.ui/src-gen/at/ac/univie/swa/ase2014/a1276754/task3/ui/contentassist/antlr/internal/InternalMydsl.g:1076:1: ( ( rule__Song__GenreAssignment_8 ) )
            {
            // ../at.ac.univie.swa.ase2014.a1276754.task3.mydsl.ui/src-gen/at/ac/univie/swa/ase2014/a1276754/task3/ui/contentassist/antlr/internal/InternalMydsl.g:1076:1: ( ( rule__Song__GenreAssignment_8 ) )
            // ../at.ac.univie.swa.ase2014.a1276754.task3.mydsl.ui/src-gen/at/ac/univie/swa/ase2014/a1276754/task3/ui/contentassist/antlr/internal/InternalMydsl.g:1077:1: ( rule__Song__GenreAssignment_8 )
            {
             before(grammarAccess.getSongAccess().getGenreAssignment_8()); 
            // ../at.ac.univie.swa.ase2014.a1276754.task3.mydsl.ui/src-gen/at/ac/univie/swa/ase2014/a1276754/task3/ui/contentassist/antlr/internal/InternalMydsl.g:1078:1: ( rule__Song__GenreAssignment_8 )
            // ../at.ac.univie.swa.ase2014.a1276754.task3.mydsl.ui/src-gen/at/ac/univie/swa/ase2014/a1276754/task3/ui/contentassist/antlr/internal/InternalMydsl.g:1078:2: rule__Song__GenreAssignment_8
            {
            pushFollow(FOLLOW_rule__Song__GenreAssignment_8_in_rule__Song__Group__8__Impl2153);
            rule__Song__GenreAssignment_8();

            state._fsp--;


            }

             after(grammarAccess.getSongAccess().getGenreAssignment_8()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Song__Group__8__Impl"


    // $ANTLR start "rule__Song__Group__9"
    // ../at.ac.univie.swa.ase2014.a1276754.task3.mydsl.ui/src-gen/at/ac/univie/swa/ase2014/a1276754/task3/ui/contentassist/antlr/internal/InternalMydsl.g:1088:1: rule__Song__Group__9 : rule__Song__Group__9__Impl rule__Song__Group__10 ;
    public final void rule__Song__Group__9() throws RecognitionException {

        		int stackSize = keepStackSize();
            
        try {
            // ../at.ac.univie.swa.ase2014.a1276754.task3.mydsl.ui/src-gen/at/ac/univie/swa/ase2014/a1276754/task3/ui/contentassist/antlr/internal/InternalMydsl.g:1092:1: ( rule__Song__Group__9__Impl rule__Song__Group__10 )
            // ../at.ac.univie.swa.ase2014.a1276754.task3.mydsl.ui/src-gen/at/ac/univie/swa/ase2014/a1276754/task3/ui/contentassist/antlr/internal/InternalMydsl.g:1093:2: rule__Song__Group__9__Impl rule__Song__Group__10
            {
            pushFollow(FOLLOW_rule__Song__Group__9__Impl_in_rule__Song__Group__92183);
            rule__Song__Group__9__Impl();

            state._fsp--;

            pushFollow(FOLLOW_rule__Song__Group__10_in_rule__Song__Group__92186);
            rule__Song__Group__10();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Song__Group__9"


    // $ANTLR start "rule__Song__Group__9__Impl"
    // ../at.ac.univie.swa.ase2014.a1276754.task3.mydsl.ui/src-gen/at/ac/univie/swa/ase2014/a1276754/task3/ui/contentassist/antlr/internal/InternalMydsl.g:1100:1: rule__Song__Group__9__Impl : ( 'price:' ) ;
    public final void rule__Song__Group__9__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
            
        try {
            // ../at.ac.univie.swa.ase2014.a1276754.task3.mydsl.ui/src-gen/at/ac/univie/swa/ase2014/a1276754/task3/ui/contentassist/antlr/internal/InternalMydsl.g:1104:1: ( ( 'price:' ) )
            // ../at.ac.univie.swa.ase2014.a1276754.task3.mydsl.ui/src-gen/at/ac/univie/swa/ase2014/a1276754/task3/ui/contentassist/antlr/internal/InternalMydsl.g:1105:1: ( 'price:' )
            {
            // ../at.ac.univie.swa.ase2014.a1276754.task3.mydsl.ui/src-gen/at/ac/univie/swa/ase2014/a1276754/task3/ui/contentassist/antlr/internal/InternalMydsl.g:1105:1: ( 'price:' )
            // ../at.ac.univie.swa.ase2014.a1276754.task3.mydsl.ui/src-gen/at/ac/univie/swa/ase2014/a1276754/task3/ui/contentassist/antlr/internal/InternalMydsl.g:1106:1: 'price:'
            {
             before(grammarAccess.getSongAccess().getPriceKeyword_9()); 
            match(input,28,FOLLOW_28_in_rule__Song__Group__9__Impl2214); 
             after(grammarAccess.getSongAccess().getPriceKeyword_9()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Song__Group__9__Impl"


    // $ANTLR start "rule__Song__Group__10"
    // ../at.ac.univie.swa.ase2014.a1276754.task3.mydsl.ui/src-gen/at/ac/univie/swa/ase2014/a1276754/task3/ui/contentassist/antlr/internal/InternalMydsl.g:1119:1: rule__Song__Group__10 : rule__Song__Group__10__Impl ;
    public final void rule__Song__Group__10() throws RecognitionException {

        		int stackSize = keepStackSize();
            
        try {
            // ../at.ac.univie.swa.ase2014.a1276754.task3.mydsl.ui/src-gen/at/ac/univie/swa/ase2014/a1276754/task3/ui/contentassist/antlr/internal/InternalMydsl.g:1123:1: ( rule__Song__Group__10__Impl )
            // ../at.ac.univie.swa.ase2014.a1276754.task3.mydsl.ui/src-gen/at/ac/univie/swa/ase2014/a1276754/task3/ui/contentassist/antlr/internal/InternalMydsl.g:1124:2: rule__Song__Group__10__Impl
            {
            pushFollow(FOLLOW_rule__Song__Group__10__Impl_in_rule__Song__Group__102245);
            rule__Song__Group__10__Impl();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Song__Group__10"


    // $ANTLR start "rule__Song__Group__10__Impl"
    // ../at.ac.univie.swa.ase2014.a1276754.task3.mydsl.ui/src-gen/at/ac/univie/swa/ase2014/a1276754/task3/ui/contentassist/antlr/internal/InternalMydsl.g:1130:1: rule__Song__Group__10__Impl : ( ( rule__Song__PriceAssignment_10 ) ) ;
    public final void rule__Song__Group__10__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
            
        try {
            // ../at.ac.univie.swa.ase2014.a1276754.task3.mydsl.ui/src-gen/at/ac/univie/swa/ase2014/a1276754/task3/ui/contentassist/antlr/internal/InternalMydsl.g:1134:1: ( ( ( rule__Song__PriceAssignment_10 ) ) )
            // ../at.ac.univie.swa.ase2014.a1276754.task3.mydsl.ui/src-gen/at/ac/univie/swa/ase2014/a1276754/task3/ui/contentassist/antlr/internal/InternalMydsl.g:1135:1: ( ( rule__Song__PriceAssignment_10 ) )
            {
            // ../at.ac.univie.swa.ase2014.a1276754.task3.mydsl.ui/src-gen/at/ac/univie/swa/ase2014/a1276754/task3/ui/contentassist/antlr/internal/InternalMydsl.g:1135:1: ( ( rule__Song__PriceAssignment_10 ) )
            // ../at.ac.univie.swa.ase2014.a1276754.task3.mydsl.ui/src-gen/at/ac/univie/swa/ase2014/a1276754/task3/ui/contentassist/antlr/internal/InternalMydsl.g:1136:1: ( rule__Song__PriceAssignment_10 )
            {
             before(grammarAccess.getSongAccess().getPriceAssignment_10()); 
            // ../at.ac.univie.swa.ase2014.a1276754.task3.mydsl.ui/src-gen/at/ac/univie/swa/ase2014/a1276754/task3/ui/contentassist/antlr/internal/InternalMydsl.g:1137:1: ( rule__Song__PriceAssignment_10 )
            // ../at.ac.univie.swa.ase2014.a1276754.task3.mydsl.ui/src-gen/at/ac/univie/swa/ase2014/a1276754/task3/ui/contentassist/antlr/internal/InternalMydsl.g:1137:2: rule__Song__PriceAssignment_10
            {
            pushFollow(FOLLOW_rule__Song__PriceAssignment_10_in_rule__Song__Group__10__Impl2272);
            rule__Song__PriceAssignment_10();

            state._fsp--;


            }

             after(grammarAccess.getSongAccess().getPriceAssignment_10()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Song__Group__10__Impl"


    // $ANTLR start "rule__Time__Group__0"
    // ../at.ac.univie.swa.ase2014.a1276754.task3.mydsl.ui/src-gen/at/ac/univie/swa/ase2014/a1276754/task3/ui/contentassist/antlr/internal/InternalMydsl.g:1169:1: rule__Time__Group__0 : rule__Time__Group__0__Impl rule__Time__Group__1 ;
    public final void rule__Time__Group__0() throws RecognitionException {

        		int stackSize = keepStackSize();
            
        try {
            // ../at.ac.univie.swa.ase2014.a1276754.task3.mydsl.ui/src-gen/at/ac/univie/swa/ase2014/a1276754/task3/ui/contentassist/antlr/internal/InternalMydsl.g:1173:1: ( rule__Time__Group__0__Impl rule__Time__Group__1 )
            // ../at.ac.univie.swa.ase2014.a1276754.task3.mydsl.ui/src-gen/at/ac/univie/swa/ase2014/a1276754/task3/ui/contentassist/antlr/internal/InternalMydsl.g:1174:2: rule__Time__Group__0__Impl rule__Time__Group__1
            {
            pushFollow(FOLLOW_rule__Time__Group__0__Impl_in_rule__Time__Group__02324);
            rule__Time__Group__0__Impl();

            state._fsp--;

            pushFollow(FOLLOW_rule__Time__Group__1_in_rule__Time__Group__02327);
            rule__Time__Group__1();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Time__Group__0"


    // $ANTLR start "rule__Time__Group__0__Impl"
    // ../at.ac.univie.swa.ase2014.a1276754.task3.mydsl.ui/src-gen/at/ac/univie/swa/ase2014/a1276754/task3/ui/contentassist/antlr/internal/InternalMydsl.g:1181:1: rule__Time__Group__0__Impl : ( ( rule__Time__MinAssignment_0 ) ) ;
    public final void rule__Time__Group__0__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
            
        try {
            // ../at.ac.univie.swa.ase2014.a1276754.task3.mydsl.ui/src-gen/at/ac/univie/swa/ase2014/a1276754/task3/ui/contentassist/antlr/internal/InternalMydsl.g:1185:1: ( ( ( rule__Time__MinAssignment_0 ) ) )
            // ../at.ac.univie.swa.ase2014.a1276754.task3.mydsl.ui/src-gen/at/ac/univie/swa/ase2014/a1276754/task3/ui/contentassist/antlr/internal/InternalMydsl.g:1186:1: ( ( rule__Time__MinAssignment_0 ) )
            {
            // ../at.ac.univie.swa.ase2014.a1276754.task3.mydsl.ui/src-gen/at/ac/univie/swa/ase2014/a1276754/task3/ui/contentassist/antlr/internal/InternalMydsl.g:1186:1: ( ( rule__Time__MinAssignment_0 ) )
            // ../at.ac.univie.swa.ase2014.a1276754.task3.mydsl.ui/src-gen/at/ac/univie/swa/ase2014/a1276754/task3/ui/contentassist/antlr/internal/InternalMydsl.g:1187:1: ( rule__Time__MinAssignment_0 )
            {
             before(grammarAccess.getTimeAccess().getMinAssignment_0()); 
            // ../at.ac.univie.swa.ase2014.a1276754.task3.mydsl.ui/src-gen/at/ac/univie/swa/ase2014/a1276754/task3/ui/contentassist/antlr/internal/InternalMydsl.g:1188:1: ( rule__Time__MinAssignment_0 )
            // ../at.ac.univie.swa.ase2014.a1276754.task3.mydsl.ui/src-gen/at/ac/univie/swa/ase2014/a1276754/task3/ui/contentassist/antlr/internal/InternalMydsl.g:1188:2: rule__Time__MinAssignment_0
            {
            pushFollow(FOLLOW_rule__Time__MinAssignment_0_in_rule__Time__Group__0__Impl2354);
            rule__Time__MinAssignment_0();

            state._fsp--;


            }

             after(grammarAccess.getTimeAccess().getMinAssignment_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Time__Group__0__Impl"


    // $ANTLR start "rule__Time__Group__1"
    // ../at.ac.univie.swa.ase2014.a1276754.task3.mydsl.ui/src-gen/at/ac/univie/swa/ase2014/a1276754/task3/ui/contentassist/antlr/internal/InternalMydsl.g:1198:1: rule__Time__Group__1 : rule__Time__Group__1__Impl rule__Time__Group__2 ;
    public final void rule__Time__Group__1() throws RecognitionException {

        		int stackSize = keepStackSize();
            
        try {
            // ../at.ac.univie.swa.ase2014.a1276754.task3.mydsl.ui/src-gen/at/ac/univie/swa/ase2014/a1276754/task3/ui/contentassist/antlr/internal/InternalMydsl.g:1202:1: ( rule__Time__Group__1__Impl rule__Time__Group__2 )
            // ../at.ac.univie.swa.ase2014.a1276754.task3.mydsl.ui/src-gen/at/ac/univie/swa/ase2014/a1276754/task3/ui/contentassist/antlr/internal/InternalMydsl.g:1203:2: rule__Time__Group__1__Impl rule__Time__Group__2
            {
            pushFollow(FOLLOW_rule__Time__Group__1__Impl_in_rule__Time__Group__12384);
            rule__Time__Group__1__Impl();

            state._fsp--;

            pushFollow(FOLLOW_rule__Time__Group__2_in_rule__Time__Group__12387);
            rule__Time__Group__2();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Time__Group__1"


    // $ANTLR start "rule__Time__Group__1__Impl"
    // ../at.ac.univie.swa.ase2014.a1276754.task3.mydsl.ui/src-gen/at/ac/univie/swa/ase2014/a1276754/task3/ui/contentassist/antlr/internal/InternalMydsl.g:1210:1: rule__Time__Group__1__Impl : ( ':' ) ;
    public final void rule__Time__Group__1__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
            
        try {
            // ../at.ac.univie.swa.ase2014.a1276754.task3.mydsl.ui/src-gen/at/ac/univie/swa/ase2014/a1276754/task3/ui/contentassist/antlr/internal/InternalMydsl.g:1214:1: ( ( ':' ) )
            // ../at.ac.univie.swa.ase2014.a1276754.task3.mydsl.ui/src-gen/at/ac/univie/swa/ase2014/a1276754/task3/ui/contentassist/antlr/internal/InternalMydsl.g:1215:1: ( ':' )
            {
            // ../at.ac.univie.swa.ase2014.a1276754.task3.mydsl.ui/src-gen/at/ac/univie/swa/ase2014/a1276754/task3/ui/contentassist/antlr/internal/InternalMydsl.g:1215:1: ( ':' )
            // ../at.ac.univie.swa.ase2014.a1276754.task3.mydsl.ui/src-gen/at/ac/univie/swa/ase2014/a1276754/task3/ui/contentassist/antlr/internal/InternalMydsl.g:1216:1: ':'
            {
             before(grammarAccess.getTimeAccess().getColonKeyword_1()); 
            match(input,29,FOLLOW_29_in_rule__Time__Group__1__Impl2415); 
             after(grammarAccess.getTimeAccess().getColonKeyword_1()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Time__Group__1__Impl"


    // $ANTLR start "rule__Time__Group__2"
    // ../at.ac.univie.swa.ase2014.a1276754.task3.mydsl.ui/src-gen/at/ac/univie/swa/ase2014/a1276754/task3/ui/contentassist/antlr/internal/InternalMydsl.g:1229:1: rule__Time__Group__2 : rule__Time__Group__2__Impl ;
    public final void rule__Time__Group__2() throws RecognitionException {

        		int stackSize = keepStackSize();
            
        try {
            // ../at.ac.univie.swa.ase2014.a1276754.task3.mydsl.ui/src-gen/at/ac/univie/swa/ase2014/a1276754/task3/ui/contentassist/antlr/internal/InternalMydsl.g:1233:1: ( rule__Time__Group__2__Impl )
            // ../at.ac.univie.swa.ase2014.a1276754.task3.mydsl.ui/src-gen/at/ac/univie/swa/ase2014/a1276754/task3/ui/contentassist/antlr/internal/InternalMydsl.g:1234:2: rule__Time__Group__2__Impl
            {
            pushFollow(FOLLOW_rule__Time__Group__2__Impl_in_rule__Time__Group__22446);
            rule__Time__Group__2__Impl();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Time__Group__2"


    // $ANTLR start "rule__Time__Group__2__Impl"
    // ../at.ac.univie.swa.ase2014.a1276754.task3.mydsl.ui/src-gen/at/ac/univie/swa/ase2014/a1276754/task3/ui/contentassist/antlr/internal/InternalMydsl.g:1240:1: rule__Time__Group__2__Impl : ( ( rule__Time__SecAssignment_2 ) ) ;
    public final void rule__Time__Group__2__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
            
        try {
            // ../at.ac.univie.swa.ase2014.a1276754.task3.mydsl.ui/src-gen/at/ac/univie/swa/ase2014/a1276754/task3/ui/contentassist/antlr/internal/InternalMydsl.g:1244:1: ( ( ( rule__Time__SecAssignment_2 ) ) )
            // ../at.ac.univie.swa.ase2014.a1276754.task3.mydsl.ui/src-gen/at/ac/univie/swa/ase2014/a1276754/task3/ui/contentassist/antlr/internal/InternalMydsl.g:1245:1: ( ( rule__Time__SecAssignment_2 ) )
            {
            // ../at.ac.univie.swa.ase2014.a1276754.task3.mydsl.ui/src-gen/at/ac/univie/swa/ase2014/a1276754/task3/ui/contentassist/antlr/internal/InternalMydsl.g:1245:1: ( ( rule__Time__SecAssignment_2 ) )
            // ../at.ac.univie.swa.ase2014.a1276754.task3.mydsl.ui/src-gen/at/ac/univie/swa/ase2014/a1276754/task3/ui/contentassist/antlr/internal/InternalMydsl.g:1246:1: ( rule__Time__SecAssignment_2 )
            {
             before(grammarAccess.getTimeAccess().getSecAssignment_2()); 
            // ../at.ac.univie.swa.ase2014.a1276754.task3.mydsl.ui/src-gen/at/ac/univie/swa/ase2014/a1276754/task3/ui/contentassist/antlr/internal/InternalMydsl.g:1247:1: ( rule__Time__SecAssignment_2 )
            // ../at.ac.univie.swa.ase2014.a1276754.task3.mydsl.ui/src-gen/at/ac/univie/swa/ase2014/a1276754/task3/ui/contentassist/antlr/internal/InternalMydsl.g:1247:2: rule__Time__SecAssignment_2
            {
            pushFollow(FOLLOW_rule__Time__SecAssignment_2_in_rule__Time__Group__2__Impl2473);
            rule__Time__SecAssignment_2();

            state._fsp--;


            }

             after(grammarAccess.getTimeAccess().getSecAssignment_2()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Time__Group__2__Impl"


    // $ANTLR start "rule__Double__Group__0"
    // ../at.ac.univie.swa.ase2014.a1276754.task3.mydsl.ui/src-gen/at/ac/univie/swa/ase2014/a1276754/task3/ui/contentassist/antlr/internal/InternalMydsl.g:1263:1: rule__Double__Group__0 : rule__Double__Group__0__Impl rule__Double__Group__1 ;
    public final void rule__Double__Group__0() throws RecognitionException {

        		int stackSize = keepStackSize();
            
        try {
            // ../at.ac.univie.swa.ase2014.a1276754.task3.mydsl.ui/src-gen/at/ac/univie/swa/ase2014/a1276754/task3/ui/contentassist/antlr/internal/InternalMydsl.g:1267:1: ( rule__Double__Group__0__Impl rule__Double__Group__1 )
            // ../at.ac.univie.swa.ase2014.a1276754.task3.mydsl.ui/src-gen/at/ac/univie/swa/ase2014/a1276754/task3/ui/contentassist/antlr/internal/InternalMydsl.g:1268:2: rule__Double__Group__0__Impl rule__Double__Group__1
            {
            pushFollow(FOLLOW_rule__Double__Group__0__Impl_in_rule__Double__Group__02509);
            rule__Double__Group__0__Impl();

            state._fsp--;

            pushFollow(FOLLOW_rule__Double__Group__1_in_rule__Double__Group__02512);
            rule__Double__Group__1();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Double__Group__0"


    // $ANTLR start "rule__Double__Group__0__Impl"
    // ../at.ac.univie.swa.ase2014.a1276754.task3.mydsl.ui/src-gen/at/ac/univie/swa/ase2014/a1276754/task3/ui/contentassist/antlr/internal/InternalMydsl.g:1275:1: rule__Double__Group__0__Impl : ( RULE_INT ) ;
    public final void rule__Double__Group__0__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
            
        try {
            // ../at.ac.univie.swa.ase2014.a1276754.task3.mydsl.ui/src-gen/at/ac/univie/swa/ase2014/a1276754/task3/ui/contentassist/antlr/internal/InternalMydsl.g:1279:1: ( ( RULE_INT ) )
            // ../at.ac.univie.swa.ase2014.a1276754.task3.mydsl.ui/src-gen/at/ac/univie/swa/ase2014/a1276754/task3/ui/contentassist/antlr/internal/InternalMydsl.g:1280:1: ( RULE_INT )
            {
            // ../at.ac.univie.swa.ase2014.a1276754.task3.mydsl.ui/src-gen/at/ac/univie/swa/ase2014/a1276754/task3/ui/contentassist/antlr/internal/InternalMydsl.g:1280:1: ( RULE_INT )
            // ../at.ac.univie.swa.ase2014.a1276754.task3.mydsl.ui/src-gen/at/ac/univie/swa/ase2014/a1276754/task3/ui/contentassist/antlr/internal/InternalMydsl.g:1281:1: RULE_INT
            {
             before(grammarAccess.getDoubleAccess().getINTTerminalRuleCall_0()); 
            match(input,RULE_INT,FOLLOW_RULE_INT_in_rule__Double__Group__0__Impl2539); 
             after(grammarAccess.getDoubleAccess().getINTTerminalRuleCall_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Double__Group__0__Impl"


    // $ANTLR start "rule__Double__Group__1"
    // ../at.ac.univie.swa.ase2014.a1276754.task3.mydsl.ui/src-gen/at/ac/univie/swa/ase2014/a1276754/task3/ui/contentassist/antlr/internal/InternalMydsl.g:1292:1: rule__Double__Group__1 : rule__Double__Group__1__Impl rule__Double__Group__2 ;
    public final void rule__Double__Group__1() throws RecognitionException {

        		int stackSize = keepStackSize();
            
        try {
            // ../at.ac.univie.swa.ase2014.a1276754.task3.mydsl.ui/src-gen/at/ac/univie/swa/ase2014/a1276754/task3/ui/contentassist/antlr/internal/InternalMydsl.g:1296:1: ( rule__Double__Group__1__Impl rule__Double__Group__2 )
            // ../at.ac.univie.swa.ase2014.a1276754.task3.mydsl.ui/src-gen/at/ac/univie/swa/ase2014/a1276754/task3/ui/contentassist/antlr/internal/InternalMydsl.g:1297:2: rule__Double__Group__1__Impl rule__Double__Group__2
            {
            pushFollow(FOLLOW_rule__Double__Group__1__Impl_in_rule__Double__Group__12568);
            rule__Double__Group__1__Impl();

            state._fsp--;

            pushFollow(FOLLOW_rule__Double__Group__2_in_rule__Double__Group__12571);
            rule__Double__Group__2();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Double__Group__1"


    // $ANTLR start "rule__Double__Group__1__Impl"
    // ../at.ac.univie.swa.ase2014.a1276754.task3.mydsl.ui/src-gen/at/ac/univie/swa/ase2014/a1276754/task3/ui/contentassist/antlr/internal/InternalMydsl.g:1304:1: rule__Double__Group__1__Impl : ( '.' ) ;
    public final void rule__Double__Group__1__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
            
        try {
            // ../at.ac.univie.swa.ase2014.a1276754.task3.mydsl.ui/src-gen/at/ac/univie/swa/ase2014/a1276754/task3/ui/contentassist/antlr/internal/InternalMydsl.g:1308:1: ( ( '.' ) )
            // ../at.ac.univie.swa.ase2014.a1276754.task3.mydsl.ui/src-gen/at/ac/univie/swa/ase2014/a1276754/task3/ui/contentassist/antlr/internal/InternalMydsl.g:1309:1: ( '.' )
            {
            // ../at.ac.univie.swa.ase2014.a1276754.task3.mydsl.ui/src-gen/at/ac/univie/swa/ase2014/a1276754/task3/ui/contentassist/antlr/internal/InternalMydsl.g:1309:1: ( '.' )
            // ../at.ac.univie.swa.ase2014.a1276754.task3.mydsl.ui/src-gen/at/ac/univie/swa/ase2014/a1276754/task3/ui/contentassist/antlr/internal/InternalMydsl.g:1310:1: '.'
            {
             before(grammarAccess.getDoubleAccess().getFullStopKeyword_1()); 
            match(input,30,FOLLOW_30_in_rule__Double__Group__1__Impl2599); 
             after(grammarAccess.getDoubleAccess().getFullStopKeyword_1()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Double__Group__1__Impl"


    // $ANTLR start "rule__Double__Group__2"
    // ../at.ac.univie.swa.ase2014.a1276754.task3.mydsl.ui/src-gen/at/ac/univie/swa/ase2014/a1276754/task3/ui/contentassist/antlr/internal/InternalMydsl.g:1323:1: rule__Double__Group__2 : rule__Double__Group__2__Impl ;
    public final void rule__Double__Group__2() throws RecognitionException {

        		int stackSize = keepStackSize();
            
        try {
            // ../at.ac.univie.swa.ase2014.a1276754.task3.mydsl.ui/src-gen/at/ac/univie/swa/ase2014/a1276754/task3/ui/contentassist/antlr/internal/InternalMydsl.g:1327:1: ( rule__Double__Group__2__Impl )
            // ../at.ac.univie.swa.ase2014.a1276754.task3.mydsl.ui/src-gen/at/ac/univie/swa/ase2014/a1276754/task3/ui/contentassist/antlr/internal/InternalMydsl.g:1328:2: rule__Double__Group__2__Impl
            {
            pushFollow(FOLLOW_rule__Double__Group__2__Impl_in_rule__Double__Group__22630);
            rule__Double__Group__2__Impl();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Double__Group__2"


    // $ANTLR start "rule__Double__Group__2__Impl"
    // ../at.ac.univie.swa.ase2014.a1276754.task3.mydsl.ui/src-gen/at/ac/univie/swa/ase2014/a1276754/task3/ui/contentassist/antlr/internal/InternalMydsl.g:1334:1: rule__Double__Group__2__Impl : ( RULE_INT ) ;
    public final void rule__Double__Group__2__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
            
        try {
            // ../at.ac.univie.swa.ase2014.a1276754.task3.mydsl.ui/src-gen/at/ac/univie/swa/ase2014/a1276754/task3/ui/contentassist/antlr/internal/InternalMydsl.g:1338:1: ( ( RULE_INT ) )
            // ../at.ac.univie.swa.ase2014.a1276754.task3.mydsl.ui/src-gen/at/ac/univie/swa/ase2014/a1276754/task3/ui/contentassist/antlr/internal/InternalMydsl.g:1339:1: ( RULE_INT )
            {
            // ../at.ac.univie.swa.ase2014.a1276754.task3.mydsl.ui/src-gen/at/ac/univie/swa/ase2014/a1276754/task3/ui/contentassist/antlr/internal/InternalMydsl.g:1339:1: ( RULE_INT )
            // ../at.ac.univie.swa.ase2014.a1276754.task3.mydsl.ui/src-gen/at/ac/univie/swa/ase2014/a1276754/task3/ui/contentassist/antlr/internal/InternalMydsl.g:1340:1: RULE_INT
            {
             before(grammarAccess.getDoubleAccess().getINTTerminalRuleCall_2()); 
            match(input,RULE_INT,FOLLOW_RULE_INT_in_rule__Double__Group__2__Impl2657); 
             after(grammarAccess.getDoubleAccess().getINTTerminalRuleCall_2()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Double__Group__2__Impl"


    // $ANTLR start "rule__Playlist__Group__0"
    // ../at.ac.univie.swa.ase2014.a1276754.task3.mydsl.ui/src-gen/at/ac/univie/swa/ase2014/a1276754/task3/ui/contentassist/antlr/internal/InternalMydsl.g:1357:1: rule__Playlist__Group__0 : rule__Playlist__Group__0__Impl rule__Playlist__Group__1 ;
    public final void rule__Playlist__Group__0() throws RecognitionException {

        		int stackSize = keepStackSize();
            
        try {
            // ../at.ac.univie.swa.ase2014.a1276754.task3.mydsl.ui/src-gen/at/ac/univie/swa/ase2014/a1276754/task3/ui/contentassist/antlr/internal/InternalMydsl.g:1361:1: ( rule__Playlist__Group__0__Impl rule__Playlist__Group__1 )
            // ../at.ac.univie.swa.ase2014.a1276754.task3.mydsl.ui/src-gen/at/ac/univie/swa/ase2014/a1276754/task3/ui/contentassist/antlr/internal/InternalMydsl.g:1362:2: rule__Playlist__Group__0__Impl rule__Playlist__Group__1
            {
            pushFollow(FOLLOW_rule__Playlist__Group__0__Impl_in_rule__Playlist__Group__02692);
            rule__Playlist__Group__0__Impl();

            state._fsp--;

            pushFollow(FOLLOW_rule__Playlist__Group__1_in_rule__Playlist__Group__02695);
            rule__Playlist__Group__1();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Playlist__Group__0"


    // $ANTLR start "rule__Playlist__Group__0__Impl"
    // ../at.ac.univie.swa.ase2014.a1276754.task3.mydsl.ui/src-gen/at/ac/univie/swa/ase2014/a1276754/task3/ui/contentassist/antlr/internal/InternalMydsl.g:1369:1: rule__Playlist__Group__0__Impl : ( ( rule__Playlist__NameAssignment_0 ) ) ;
    public final void rule__Playlist__Group__0__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
            
        try {
            // ../at.ac.univie.swa.ase2014.a1276754.task3.mydsl.ui/src-gen/at/ac/univie/swa/ase2014/a1276754/task3/ui/contentassist/antlr/internal/InternalMydsl.g:1373:1: ( ( ( rule__Playlist__NameAssignment_0 ) ) )
            // ../at.ac.univie.swa.ase2014.a1276754.task3.mydsl.ui/src-gen/at/ac/univie/swa/ase2014/a1276754/task3/ui/contentassist/antlr/internal/InternalMydsl.g:1374:1: ( ( rule__Playlist__NameAssignment_0 ) )
            {
            // ../at.ac.univie.swa.ase2014.a1276754.task3.mydsl.ui/src-gen/at/ac/univie/swa/ase2014/a1276754/task3/ui/contentassist/antlr/internal/InternalMydsl.g:1374:1: ( ( rule__Playlist__NameAssignment_0 ) )
            // ../at.ac.univie.swa.ase2014.a1276754.task3.mydsl.ui/src-gen/at/ac/univie/swa/ase2014/a1276754/task3/ui/contentassist/antlr/internal/InternalMydsl.g:1375:1: ( rule__Playlist__NameAssignment_0 )
            {
             before(grammarAccess.getPlaylistAccess().getNameAssignment_0()); 
            // ../at.ac.univie.swa.ase2014.a1276754.task3.mydsl.ui/src-gen/at/ac/univie/swa/ase2014/a1276754/task3/ui/contentassist/antlr/internal/InternalMydsl.g:1376:1: ( rule__Playlist__NameAssignment_0 )
            // ../at.ac.univie.swa.ase2014.a1276754.task3.mydsl.ui/src-gen/at/ac/univie/swa/ase2014/a1276754/task3/ui/contentassist/antlr/internal/InternalMydsl.g:1376:2: rule__Playlist__NameAssignment_0
            {
            pushFollow(FOLLOW_rule__Playlist__NameAssignment_0_in_rule__Playlist__Group__0__Impl2722);
            rule__Playlist__NameAssignment_0();

            state._fsp--;


            }

             after(grammarAccess.getPlaylistAccess().getNameAssignment_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Playlist__Group__0__Impl"


    // $ANTLR start "rule__Playlist__Group__1"
    // ../at.ac.univie.swa.ase2014.a1276754.task3.mydsl.ui/src-gen/at/ac/univie/swa/ase2014/a1276754/task3/ui/contentassist/antlr/internal/InternalMydsl.g:1386:1: rule__Playlist__Group__1 : rule__Playlist__Group__1__Impl rule__Playlist__Group__2 ;
    public final void rule__Playlist__Group__1() throws RecognitionException {

        		int stackSize = keepStackSize();
            
        try {
            // ../at.ac.univie.swa.ase2014.a1276754.task3.mydsl.ui/src-gen/at/ac/univie/swa/ase2014/a1276754/task3/ui/contentassist/antlr/internal/InternalMydsl.g:1390:1: ( rule__Playlist__Group__1__Impl rule__Playlist__Group__2 )
            // ../at.ac.univie.swa.ase2014.a1276754.task3.mydsl.ui/src-gen/at/ac/univie/swa/ase2014/a1276754/task3/ui/contentassist/antlr/internal/InternalMydsl.g:1391:2: rule__Playlist__Group__1__Impl rule__Playlist__Group__2
            {
            pushFollow(FOLLOW_rule__Playlist__Group__1__Impl_in_rule__Playlist__Group__12752);
            rule__Playlist__Group__1__Impl();

            state._fsp--;

            pushFollow(FOLLOW_rule__Playlist__Group__2_in_rule__Playlist__Group__12755);
            rule__Playlist__Group__2();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Playlist__Group__1"


    // $ANTLR start "rule__Playlist__Group__1__Impl"
    // ../at.ac.univie.swa.ase2014.a1276754.task3.mydsl.ui/src-gen/at/ac/univie/swa/ase2014/a1276754/task3/ui/contentassist/antlr/internal/InternalMydsl.g:1398:1: rule__Playlist__Group__1__Impl : ( ' consists of' ) ;
    public final void rule__Playlist__Group__1__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
            
        try {
            // ../at.ac.univie.swa.ase2014.a1276754.task3.mydsl.ui/src-gen/at/ac/univie/swa/ase2014/a1276754/task3/ui/contentassist/antlr/internal/InternalMydsl.g:1402:1: ( ( ' consists of' ) )
            // ../at.ac.univie.swa.ase2014.a1276754.task3.mydsl.ui/src-gen/at/ac/univie/swa/ase2014/a1276754/task3/ui/contentassist/antlr/internal/InternalMydsl.g:1403:1: ( ' consists of' )
            {
            // ../at.ac.univie.swa.ase2014.a1276754.task3.mydsl.ui/src-gen/at/ac/univie/swa/ase2014/a1276754/task3/ui/contentassist/antlr/internal/InternalMydsl.g:1403:1: ( ' consists of' )
            // ../at.ac.univie.swa.ase2014.a1276754.task3.mydsl.ui/src-gen/at/ac/univie/swa/ase2014/a1276754/task3/ui/contentassist/antlr/internal/InternalMydsl.g:1404:1: ' consists of'
            {
             before(grammarAccess.getPlaylistAccess().getConsistsOfKeyword_1()); 
            match(input,31,FOLLOW_31_in_rule__Playlist__Group__1__Impl2783); 
             after(grammarAccess.getPlaylistAccess().getConsistsOfKeyword_1()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Playlist__Group__1__Impl"


    // $ANTLR start "rule__Playlist__Group__2"
    // ../at.ac.univie.swa.ase2014.a1276754.task3.mydsl.ui/src-gen/at/ac/univie/swa/ase2014/a1276754/task3/ui/contentassist/antlr/internal/InternalMydsl.g:1417:1: rule__Playlist__Group__2 : rule__Playlist__Group__2__Impl rule__Playlist__Group__3 ;
    public final void rule__Playlist__Group__2() throws RecognitionException {

        		int stackSize = keepStackSize();
            
        try {
            // ../at.ac.univie.swa.ase2014.a1276754.task3.mydsl.ui/src-gen/at/ac/univie/swa/ase2014/a1276754/task3/ui/contentassist/antlr/internal/InternalMydsl.g:1421:1: ( rule__Playlist__Group__2__Impl rule__Playlist__Group__3 )
            // ../at.ac.univie.swa.ase2014.a1276754.task3.mydsl.ui/src-gen/at/ac/univie/swa/ase2014/a1276754/task3/ui/contentassist/antlr/internal/InternalMydsl.g:1422:2: rule__Playlist__Group__2__Impl rule__Playlist__Group__3
            {
            pushFollow(FOLLOW_rule__Playlist__Group__2__Impl_in_rule__Playlist__Group__22814);
            rule__Playlist__Group__2__Impl();

            state._fsp--;

            pushFollow(FOLLOW_rule__Playlist__Group__3_in_rule__Playlist__Group__22817);
            rule__Playlist__Group__3();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Playlist__Group__2"


    // $ANTLR start "rule__Playlist__Group__2__Impl"
    // ../at.ac.univie.swa.ase2014.a1276754.task3.mydsl.ui/src-gen/at/ac/univie/swa/ase2014/a1276754/task3/ui/contentassist/antlr/internal/InternalMydsl.g:1429:1: rule__Playlist__Group__2__Impl : ( ( rule__Playlist__Group_2__0 )* ) ;
    public final void rule__Playlist__Group__2__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
            
        try {
            // ../at.ac.univie.swa.ase2014.a1276754.task3.mydsl.ui/src-gen/at/ac/univie/swa/ase2014/a1276754/task3/ui/contentassist/antlr/internal/InternalMydsl.g:1433:1: ( ( ( rule__Playlist__Group_2__0 )* ) )
            // ../at.ac.univie.swa.ase2014.a1276754.task3.mydsl.ui/src-gen/at/ac/univie/swa/ase2014/a1276754/task3/ui/contentassist/antlr/internal/InternalMydsl.g:1434:1: ( ( rule__Playlist__Group_2__0 )* )
            {
            // ../at.ac.univie.swa.ase2014.a1276754.task3.mydsl.ui/src-gen/at/ac/univie/swa/ase2014/a1276754/task3/ui/contentassist/antlr/internal/InternalMydsl.g:1434:1: ( ( rule__Playlist__Group_2__0 )* )
            // ../at.ac.univie.swa.ase2014.a1276754.task3.mydsl.ui/src-gen/at/ac/univie/swa/ase2014/a1276754/task3/ui/contentassist/antlr/internal/InternalMydsl.g:1435:1: ( rule__Playlist__Group_2__0 )*
            {
             before(grammarAccess.getPlaylistAccess().getGroup_2()); 
            // ../at.ac.univie.swa.ase2014.a1276754.task3.mydsl.ui/src-gen/at/ac/univie/swa/ase2014/a1276754/task3/ui/contentassist/antlr/internal/InternalMydsl.g:1436:1: ( rule__Playlist__Group_2__0 )*
            loop5:
            do {
                int alt5=2;
                int LA5_0 = input.LA(1);

                if ( (LA5_0==RULE_ID) ) {
                    int LA5_1 = input.LA(2);

                    if ( (LA5_1==32) ) {
                        alt5=1;
                    }


                }


                switch (alt5) {
            	case 1 :
            	    // ../at.ac.univie.swa.ase2014.a1276754.task3.mydsl.ui/src-gen/at/ac/univie/swa/ase2014/a1276754/task3/ui/contentassist/antlr/internal/InternalMydsl.g:1436:2: rule__Playlist__Group_2__0
            	    {
            	    pushFollow(FOLLOW_rule__Playlist__Group_2__0_in_rule__Playlist__Group__2__Impl2844);
            	    rule__Playlist__Group_2__0();

            	    state._fsp--;


            	    }
            	    break;

            	default :
            	    break loop5;
                }
            } while (true);

             after(grammarAccess.getPlaylistAccess().getGroup_2()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Playlist__Group__2__Impl"


    // $ANTLR start "rule__Playlist__Group__3"
    // ../at.ac.univie.swa.ase2014.a1276754.task3.mydsl.ui/src-gen/at/ac/univie/swa/ase2014/a1276754/task3/ui/contentassist/antlr/internal/InternalMydsl.g:1446:1: rule__Playlist__Group__3 : rule__Playlist__Group__3__Impl rule__Playlist__Group__4 ;
    public final void rule__Playlist__Group__3() throws RecognitionException {

        		int stackSize = keepStackSize();
            
        try {
            // ../at.ac.univie.swa.ase2014.a1276754.task3.mydsl.ui/src-gen/at/ac/univie/swa/ase2014/a1276754/task3/ui/contentassist/antlr/internal/InternalMydsl.g:1450:1: ( rule__Playlist__Group__3__Impl rule__Playlist__Group__4 )
            // ../at.ac.univie.swa.ase2014.a1276754.task3.mydsl.ui/src-gen/at/ac/univie/swa/ase2014/a1276754/task3/ui/contentassist/antlr/internal/InternalMydsl.g:1451:2: rule__Playlist__Group__3__Impl rule__Playlist__Group__4
            {
            pushFollow(FOLLOW_rule__Playlist__Group__3__Impl_in_rule__Playlist__Group__32875);
            rule__Playlist__Group__3__Impl();

            state._fsp--;

            pushFollow(FOLLOW_rule__Playlist__Group__4_in_rule__Playlist__Group__32878);
            rule__Playlist__Group__4();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Playlist__Group__3"


    // $ANTLR start "rule__Playlist__Group__3__Impl"
    // ../at.ac.univie.swa.ase2014.a1276754.task3.mydsl.ui/src-gen/at/ac/univie/swa/ase2014/a1276754/task3/ui/contentassist/antlr/internal/InternalMydsl.g:1458:1: rule__Playlist__Group__3__Impl : ( ( rule__Playlist__SongsAssignment_3 )? ) ;
    public final void rule__Playlist__Group__3__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
            
        try {
            // ../at.ac.univie.swa.ase2014.a1276754.task3.mydsl.ui/src-gen/at/ac/univie/swa/ase2014/a1276754/task3/ui/contentassist/antlr/internal/InternalMydsl.g:1462:1: ( ( ( rule__Playlist__SongsAssignment_3 )? ) )
            // ../at.ac.univie.swa.ase2014.a1276754.task3.mydsl.ui/src-gen/at/ac/univie/swa/ase2014/a1276754/task3/ui/contentassist/antlr/internal/InternalMydsl.g:1463:1: ( ( rule__Playlist__SongsAssignment_3 )? )
            {
            // ../at.ac.univie.swa.ase2014.a1276754.task3.mydsl.ui/src-gen/at/ac/univie/swa/ase2014/a1276754/task3/ui/contentassist/antlr/internal/InternalMydsl.g:1463:1: ( ( rule__Playlist__SongsAssignment_3 )? )
            // ../at.ac.univie.swa.ase2014.a1276754.task3.mydsl.ui/src-gen/at/ac/univie/swa/ase2014/a1276754/task3/ui/contentassist/antlr/internal/InternalMydsl.g:1464:1: ( rule__Playlist__SongsAssignment_3 )?
            {
             before(grammarAccess.getPlaylistAccess().getSongsAssignment_3()); 
            // ../at.ac.univie.swa.ase2014.a1276754.task3.mydsl.ui/src-gen/at/ac/univie/swa/ase2014/a1276754/task3/ui/contentassist/antlr/internal/InternalMydsl.g:1465:1: ( rule__Playlist__SongsAssignment_3 )?
            int alt6=2;
            int LA6_0 = input.LA(1);

            if ( (LA6_0==RULE_ID) ) {
                int LA6_1 = input.LA(2);

                if ( (LA6_1==EOF||LA6_1==RULE_ID||LA6_1==33) ) {
                    alt6=1;
                }
            }
            switch (alt6) {
                case 1 :
                    // ../at.ac.univie.swa.ase2014.a1276754.task3.mydsl.ui/src-gen/at/ac/univie/swa/ase2014/a1276754/task3/ui/contentassist/antlr/internal/InternalMydsl.g:1465:2: rule__Playlist__SongsAssignment_3
                    {
                    pushFollow(FOLLOW_rule__Playlist__SongsAssignment_3_in_rule__Playlist__Group__3__Impl2905);
                    rule__Playlist__SongsAssignment_3();

                    state._fsp--;


                    }
                    break;

            }

             after(grammarAccess.getPlaylistAccess().getSongsAssignment_3()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Playlist__Group__3__Impl"


    // $ANTLR start "rule__Playlist__Group__4"
    // ../at.ac.univie.swa.ase2014.a1276754.task3.mydsl.ui/src-gen/at/ac/univie/swa/ase2014/a1276754/task3/ui/contentassist/antlr/internal/InternalMydsl.g:1475:1: rule__Playlist__Group__4 : rule__Playlist__Group__4__Impl ;
    public final void rule__Playlist__Group__4() throws RecognitionException {

        		int stackSize = keepStackSize();
            
        try {
            // ../at.ac.univie.swa.ase2014.a1276754.task3.mydsl.ui/src-gen/at/ac/univie/swa/ase2014/a1276754/task3/ui/contentassist/antlr/internal/InternalMydsl.g:1479:1: ( rule__Playlist__Group__4__Impl )
            // ../at.ac.univie.swa.ase2014.a1276754.task3.mydsl.ui/src-gen/at/ac/univie/swa/ase2014/a1276754/task3/ui/contentassist/antlr/internal/InternalMydsl.g:1480:2: rule__Playlist__Group__4__Impl
            {
            pushFollow(FOLLOW_rule__Playlist__Group__4__Impl_in_rule__Playlist__Group__42936);
            rule__Playlist__Group__4__Impl();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Playlist__Group__4"


    // $ANTLR start "rule__Playlist__Group__4__Impl"
    // ../at.ac.univie.swa.ase2014.a1276754.task3.mydsl.ui/src-gen/at/ac/univie/swa/ase2014/a1276754/task3/ui/contentassist/antlr/internal/InternalMydsl.g:1486:1: rule__Playlist__Group__4__Impl : ( ( rule__Playlist__Group_4__0 )* ) ;
    public final void rule__Playlist__Group__4__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
            
        try {
            // ../at.ac.univie.swa.ase2014.a1276754.task3.mydsl.ui/src-gen/at/ac/univie/swa/ase2014/a1276754/task3/ui/contentassist/antlr/internal/InternalMydsl.g:1490:1: ( ( ( rule__Playlist__Group_4__0 )* ) )
            // ../at.ac.univie.swa.ase2014.a1276754.task3.mydsl.ui/src-gen/at/ac/univie/swa/ase2014/a1276754/task3/ui/contentassist/antlr/internal/InternalMydsl.g:1491:1: ( ( rule__Playlist__Group_4__0 )* )
            {
            // ../at.ac.univie.swa.ase2014.a1276754.task3.mydsl.ui/src-gen/at/ac/univie/swa/ase2014/a1276754/task3/ui/contentassist/antlr/internal/InternalMydsl.g:1491:1: ( ( rule__Playlist__Group_4__0 )* )
            // ../at.ac.univie.swa.ase2014.a1276754.task3.mydsl.ui/src-gen/at/ac/univie/swa/ase2014/a1276754/task3/ui/contentassist/antlr/internal/InternalMydsl.g:1492:1: ( rule__Playlist__Group_4__0 )*
            {
             before(grammarAccess.getPlaylistAccess().getGroup_4()); 
            // ../at.ac.univie.swa.ase2014.a1276754.task3.mydsl.ui/src-gen/at/ac/univie/swa/ase2014/a1276754/task3/ui/contentassist/antlr/internal/InternalMydsl.g:1493:1: ( rule__Playlist__Group_4__0 )*
            loop7:
            do {
                int alt7=2;
                int LA7_0 = input.LA(1);

                if ( (LA7_0==33) ) {
                    alt7=1;
                }


                switch (alt7) {
            	case 1 :
            	    // ../at.ac.univie.swa.ase2014.a1276754.task3.mydsl.ui/src-gen/at/ac/univie/swa/ase2014/a1276754/task3/ui/contentassist/antlr/internal/InternalMydsl.g:1493:2: rule__Playlist__Group_4__0
            	    {
            	    pushFollow(FOLLOW_rule__Playlist__Group_4__0_in_rule__Playlist__Group__4__Impl2963);
            	    rule__Playlist__Group_4__0();

            	    state._fsp--;


            	    }
            	    break;

            	default :
            	    break loop7;
                }
            } while (true);

             after(grammarAccess.getPlaylistAccess().getGroup_4()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Playlist__Group__4__Impl"


    // $ANTLR start "rule__Playlist__Group_2__0"
    // ../at.ac.univie.swa.ase2014.a1276754.task3.mydsl.ui/src-gen/at/ac/univie/swa/ase2014/a1276754/task3/ui/contentassist/antlr/internal/InternalMydsl.g:1513:1: rule__Playlist__Group_2__0 : rule__Playlist__Group_2__0__Impl rule__Playlist__Group_2__1 ;
    public final void rule__Playlist__Group_2__0() throws RecognitionException {

        		int stackSize = keepStackSize();
            
        try {
            // ../at.ac.univie.swa.ase2014.a1276754.task3.mydsl.ui/src-gen/at/ac/univie/swa/ase2014/a1276754/task3/ui/contentassist/antlr/internal/InternalMydsl.g:1517:1: ( rule__Playlist__Group_2__0__Impl rule__Playlist__Group_2__1 )
            // ../at.ac.univie.swa.ase2014.a1276754.task3.mydsl.ui/src-gen/at/ac/univie/swa/ase2014/a1276754/task3/ui/contentassist/antlr/internal/InternalMydsl.g:1518:2: rule__Playlist__Group_2__0__Impl rule__Playlist__Group_2__1
            {
            pushFollow(FOLLOW_rule__Playlist__Group_2__0__Impl_in_rule__Playlist__Group_2__03004);
            rule__Playlist__Group_2__0__Impl();

            state._fsp--;

            pushFollow(FOLLOW_rule__Playlist__Group_2__1_in_rule__Playlist__Group_2__03007);
            rule__Playlist__Group_2__1();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Playlist__Group_2__0"


    // $ANTLR start "rule__Playlist__Group_2__0__Impl"
    // ../at.ac.univie.swa.ase2014.a1276754.task3.mydsl.ui/src-gen/at/ac/univie/swa/ase2014/a1276754/task3/ui/contentassist/antlr/internal/InternalMydsl.g:1525:1: rule__Playlist__Group_2__0__Impl : ( ( rule__Playlist__SongsAssignment_2_0 ) ) ;
    public final void rule__Playlist__Group_2__0__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
            
        try {
            // ../at.ac.univie.swa.ase2014.a1276754.task3.mydsl.ui/src-gen/at/ac/univie/swa/ase2014/a1276754/task3/ui/contentassist/antlr/internal/InternalMydsl.g:1529:1: ( ( ( rule__Playlist__SongsAssignment_2_0 ) ) )
            // ../at.ac.univie.swa.ase2014.a1276754.task3.mydsl.ui/src-gen/at/ac/univie/swa/ase2014/a1276754/task3/ui/contentassist/antlr/internal/InternalMydsl.g:1530:1: ( ( rule__Playlist__SongsAssignment_2_0 ) )
            {
            // ../at.ac.univie.swa.ase2014.a1276754.task3.mydsl.ui/src-gen/at/ac/univie/swa/ase2014/a1276754/task3/ui/contentassist/antlr/internal/InternalMydsl.g:1530:1: ( ( rule__Playlist__SongsAssignment_2_0 ) )
            // ../at.ac.univie.swa.ase2014.a1276754.task3.mydsl.ui/src-gen/at/ac/univie/swa/ase2014/a1276754/task3/ui/contentassist/antlr/internal/InternalMydsl.g:1531:1: ( rule__Playlist__SongsAssignment_2_0 )
            {
             before(grammarAccess.getPlaylistAccess().getSongsAssignment_2_0()); 
            // ../at.ac.univie.swa.ase2014.a1276754.task3.mydsl.ui/src-gen/at/ac/univie/swa/ase2014/a1276754/task3/ui/contentassist/antlr/internal/InternalMydsl.g:1532:1: ( rule__Playlist__SongsAssignment_2_0 )
            // ../at.ac.univie.swa.ase2014.a1276754.task3.mydsl.ui/src-gen/at/ac/univie/swa/ase2014/a1276754/task3/ui/contentassist/antlr/internal/InternalMydsl.g:1532:2: rule__Playlist__SongsAssignment_2_0
            {
            pushFollow(FOLLOW_rule__Playlist__SongsAssignment_2_0_in_rule__Playlist__Group_2__0__Impl3034);
            rule__Playlist__SongsAssignment_2_0();

            state._fsp--;


            }

             after(grammarAccess.getPlaylistAccess().getSongsAssignment_2_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Playlist__Group_2__0__Impl"


    // $ANTLR start "rule__Playlist__Group_2__1"
    // ../at.ac.univie.swa.ase2014.a1276754.task3.mydsl.ui/src-gen/at/ac/univie/swa/ase2014/a1276754/task3/ui/contentassist/antlr/internal/InternalMydsl.g:1542:1: rule__Playlist__Group_2__1 : rule__Playlist__Group_2__1__Impl ;
    public final void rule__Playlist__Group_2__1() throws RecognitionException {

        		int stackSize = keepStackSize();
            
        try {
            // ../at.ac.univie.swa.ase2014.a1276754.task3.mydsl.ui/src-gen/at/ac/univie/swa/ase2014/a1276754/task3/ui/contentassist/antlr/internal/InternalMydsl.g:1546:1: ( rule__Playlist__Group_2__1__Impl )
            // ../at.ac.univie.swa.ase2014.a1276754.task3.mydsl.ui/src-gen/at/ac/univie/swa/ase2014/a1276754/task3/ui/contentassist/antlr/internal/InternalMydsl.g:1547:2: rule__Playlist__Group_2__1__Impl
            {
            pushFollow(FOLLOW_rule__Playlist__Group_2__1__Impl_in_rule__Playlist__Group_2__13064);
            rule__Playlist__Group_2__1__Impl();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Playlist__Group_2__1"


    // $ANTLR start "rule__Playlist__Group_2__1__Impl"
    // ../at.ac.univie.swa.ase2014.a1276754.task3.mydsl.ui/src-gen/at/ac/univie/swa/ase2014/a1276754/task3/ui/contentassist/antlr/internal/InternalMydsl.g:1553:1: rule__Playlist__Group_2__1__Impl : ( ',' ) ;
    public final void rule__Playlist__Group_2__1__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
            
        try {
            // ../at.ac.univie.swa.ase2014.a1276754.task3.mydsl.ui/src-gen/at/ac/univie/swa/ase2014/a1276754/task3/ui/contentassist/antlr/internal/InternalMydsl.g:1557:1: ( ( ',' ) )
            // ../at.ac.univie.swa.ase2014.a1276754.task3.mydsl.ui/src-gen/at/ac/univie/swa/ase2014/a1276754/task3/ui/contentassist/antlr/internal/InternalMydsl.g:1558:1: ( ',' )
            {
            // ../at.ac.univie.swa.ase2014.a1276754.task3.mydsl.ui/src-gen/at/ac/univie/swa/ase2014/a1276754/task3/ui/contentassist/antlr/internal/InternalMydsl.g:1558:1: ( ',' )
            // ../at.ac.univie.swa.ase2014.a1276754.task3.mydsl.ui/src-gen/at/ac/univie/swa/ase2014/a1276754/task3/ui/contentassist/antlr/internal/InternalMydsl.g:1559:1: ','
            {
             before(grammarAccess.getPlaylistAccess().getCommaKeyword_2_1()); 
            match(input,32,FOLLOW_32_in_rule__Playlist__Group_2__1__Impl3092); 
             after(grammarAccess.getPlaylistAccess().getCommaKeyword_2_1()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Playlist__Group_2__1__Impl"


    // $ANTLR start "rule__Playlist__Group_4__0"
    // ../at.ac.univie.swa.ase2014.a1276754.task3.mydsl.ui/src-gen/at/ac/univie/swa/ase2014/a1276754/task3/ui/contentassist/antlr/internal/InternalMydsl.g:1576:1: rule__Playlist__Group_4__0 : rule__Playlist__Group_4__0__Impl rule__Playlist__Group_4__1 ;
    public final void rule__Playlist__Group_4__0() throws RecognitionException {

        		int stackSize = keepStackSize();
            
        try {
            // ../at.ac.univie.swa.ase2014.a1276754.task3.mydsl.ui/src-gen/at/ac/univie/swa/ase2014/a1276754/task3/ui/contentassist/antlr/internal/InternalMydsl.g:1580:1: ( rule__Playlist__Group_4__0__Impl rule__Playlist__Group_4__1 )
            // ../at.ac.univie.swa.ase2014.a1276754.task3.mydsl.ui/src-gen/at/ac/univie/swa/ase2014/a1276754/task3/ui/contentassist/antlr/internal/InternalMydsl.g:1581:2: rule__Playlist__Group_4__0__Impl rule__Playlist__Group_4__1
            {
            pushFollow(FOLLOW_rule__Playlist__Group_4__0__Impl_in_rule__Playlist__Group_4__03127);
            rule__Playlist__Group_4__0__Impl();

            state._fsp--;

            pushFollow(FOLLOW_rule__Playlist__Group_4__1_in_rule__Playlist__Group_4__03130);
            rule__Playlist__Group_4__1();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Playlist__Group_4__0"


    // $ANTLR start "rule__Playlist__Group_4__0__Impl"
    // ../at.ac.univie.swa.ase2014.a1276754.task3.mydsl.ui/src-gen/at/ac/univie/swa/ase2014/a1276754/task3/ui/contentassist/antlr/internal/InternalMydsl.g:1588:1: rule__Playlist__Group_4__0__Impl : ( 'Playlist' ) ;
    public final void rule__Playlist__Group_4__0__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
            
        try {
            // ../at.ac.univie.swa.ase2014.a1276754.task3.mydsl.ui/src-gen/at/ac/univie/swa/ase2014/a1276754/task3/ui/contentassist/antlr/internal/InternalMydsl.g:1592:1: ( ( 'Playlist' ) )
            // ../at.ac.univie.swa.ase2014.a1276754.task3.mydsl.ui/src-gen/at/ac/univie/swa/ase2014/a1276754/task3/ui/contentassist/antlr/internal/InternalMydsl.g:1593:1: ( 'Playlist' )
            {
            // ../at.ac.univie.swa.ase2014.a1276754.task3.mydsl.ui/src-gen/at/ac/univie/swa/ase2014/a1276754/task3/ui/contentassist/antlr/internal/InternalMydsl.g:1593:1: ( 'Playlist' )
            // ../at.ac.univie.swa.ase2014.a1276754.task3.mydsl.ui/src-gen/at/ac/univie/swa/ase2014/a1276754/task3/ui/contentassist/antlr/internal/InternalMydsl.g:1594:1: 'Playlist'
            {
             before(grammarAccess.getPlaylistAccess().getPlaylistKeyword_4_0()); 
            match(input,33,FOLLOW_33_in_rule__Playlist__Group_4__0__Impl3158); 
             after(grammarAccess.getPlaylistAccess().getPlaylistKeyword_4_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Playlist__Group_4__0__Impl"


    // $ANTLR start "rule__Playlist__Group_4__1"
    // ../at.ac.univie.swa.ase2014.a1276754.task3.mydsl.ui/src-gen/at/ac/univie/swa/ase2014/a1276754/task3/ui/contentassist/antlr/internal/InternalMydsl.g:1607:1: rule__Playlist__Group_4__1 : rule__Playlist__Group_4__1__Impl rule__Playlist__Group_4__2 ;
    public final void rule__Playlist__Group_4__1() throws RecognitionException {

        		int stackSize = keepStackSize();
            
        try {
            // ../at.ac.univie.swa.ase2014.a1276754.task3.mydsl.ui/src-gen/at/ac/univie/swa/ase2014/a1276754/task3/ui/contentassist/antlr/internal/InternalMydsl.g:1611:1: ( rule__Playlist__Group_4__1__Impl rule__Playlist__Group_4__2 )
            // ../at.ac.univie.swa.ase2014.a1276754.task3.mydsl.ui/src-gen/at/ac/univie/swa/ase2014/a1276754/task3/ui/contentassist/antlr/internal/InternalMydsl.g:1612:2: rule__Playlist__Group_4__1__Impl rule__Playlist__Group_4__2
            {
            pushFollow(FOLLOW_rule__Playlist__Group_4__1__Impl_in_rule__Playlist__Group_4__13189);
            rule__Playlist__Group_4__1__Impl();

            state._fsp--;

            pushFollow(FOLLOW_rule__Playlist__Group_4__2_in_rule__Playlist__Group_4__13192);
            rule__Playlist__Group_4__2();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Playlist__Group_4__1"


    // $ANTLR start "rule__Playlist__Group_4__1__Impl"
    // ../at.ac.univie.swa.ase2014.a1276754.task3.mydsl.ui/src-gen/at/ac/univie/swa/ase2014/a1276754/task3/ui/contentassist/antlr/internal/InternalMydsl.g:1619:1: rule__Playlist__Group_4__1__Impl : ( ( rule__Playlist__InclAssignment_4_1 ) ) ;
    public final void rule__Playlist__Group_4__1__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
            
        try {
            // ../at.ac.univie.swa.ase2014.a1276754.task3.mydsl.ui/src-gen/at/ac/univie/swa/ase2014/a1276754/task3/ui/contentassist/antlr/internal/InternalMydsl.g:1623:1: ( ( ( rule__Playlist__InclAssignment_4_1 ) ) )
            // ../at.ac.univie.swa.ase2014.a1276754.task3.mydsl.ui/src-gen/at/ac/univie/swa/ase2014/a1276754/task3/ui/contentassist/antlr/internal/InternalMydsl.g:1624:1: ( ( rule__Playlist__InclAssignment_4_1 ) )
            {
            // ../at.ac.univie.swa.ase2014.a1276754.task3.mydsl.ui/src-gen/at/ac/univie/swa/ase2014/a1276754/task3/ui/contentassist/antlr/internal/InternalMydsl.g:1624:1: ( ( rule__Playlist__InclAssignment_4_1 ) )
            // ../at.ac.univie.swa.ase2014.a1276754.task3.mydsl.ui/src-gen/at/ac/univie/swa/ase2014/a1276754/task3/ui/contentassist/antlr/internal/InternalMydsl.g:1625:1: ( rule__Playlist__InclAssignment_4_1 )
            {
             before(grammarAccess.getPlaylistAccess().getInclAssignment_4_1()); 
            // ../at.ac.univie.swa.ase2014.a1276754.task3.mydsl.ui/src-gen/at/ac/univie/swa/ase2014/a1276754/task3/ui/contentassist/antlr/internal/InternalMydsl.g:1626:1: ( rule__Playlist__InclAssignment_4_1 )
            // ../at.ac.univie.swa.ase2014.a1276754.task3.mydsl.ui/src-gen/at/ac/univie/swa/ase2014/a1276754/task3/ui/contentassist/antlr/internal/InternalMydsl.g:1626:2: rule__Playlist__InclAssignment_4_1
            {
            pushFollow(FOLLOW_rule__Playlist__InclAssignment_4_1_in_rule__Playlist__Group_4__1__Impl3219);
            rule__Playlist__InclAssignment_4_1();

            state._fsp--;


            }

             after(grammarAccess.getPlaylistAccess().getInclAssignment_4_1()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Playlist__Group_4__1__Impl"


    // $ANTLR start "rule__Playlist__Group_4__2"
    // ../at.ac.univie.swa.ase2014.a1276754.task3.mydsl.ui/src-gen/at/ac/univie/swa/ase2014/a1276754/task3/ui/contentassist/antlr/internal/InternalMydsl.g:1636:1: rule__Playlist__Group_4__2 : rule__Playlist__Group_4__2__Impl ;
    public final void rule__Playlist__Group_4__2() throws RecognitionException {

        		int stackSize = keepStackSize();
            
        try {
            // ../at.ac.univie.swa.ase2014.a1276754.task3.mydsl.ui/src-gen/at/ac/univie/swa/ase2014/a1276754/task3/ui/contentassist/antlr/internal/InternalMydsl.g:1640:1: ( rule__Playlist__Group_4__2__Impl )
            // ../at.ac.univie.swa.ase2014.a1276754.task3.mydsl.ui/src-gen/at/ac/univie/swa/ase2014/a1276754/task3/ui/contentassist/antlr/internal/InternalMydsl.g:1641:2: rule__Playlist__Group_4__2__Impl
            {
            pushFollow(FOLLOW_rule__Playlist__Group_4__2__Impl_in_rule__Playlist__Group_4__23249);
            rule__Playlist__Group_4__2__Impl();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Playlist__Group_4__2"


    // $ANTLR start "rule__Playlist__Group_4__2__Impl"
    // ../at.ac.univie.swa.ase2014.a1276754.task3.mydsl.ui/src-gen/at/ac/univie/swa/ase2014/a1276754/task3/ui/contentassist/antlr/internal/InternalMydsl.g:1647:1: rule__Playlist__Group_4__2__Impl : ( ( rule__Playlist__Group_4_2__0 )? ) ;
    public final void rule__Playlist__Group_4__2__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
            
        try {
            // ../at.ac.univie.swa.ase2014.a1276754.task3.mydsl.ui/src-gen/at/ac/univie/swa/ase2014/a1276754/task3/ui/contentassist/antlr/internal/InternalMydsl.g:1651:1: ( ( ( rule__Playlist__Group_4_2__0 )? ) )
            // ../at.ac.univie.swa.ase2014.a1276754.task3.mydsl.ui/src-gen/at/ac/univie/swa/ase2014/a1276754/task3/ui/contentassist/antlr/internal/InternalMydsl.g:1652:1: ( ( rule__Playlist__Group_4_2__0 )? )
            {
            // ../at.ac.univie.swa.ase2014.a1276754.task3.mydsl.ui/src-gen/at/ac/univie/swa/ase2014/a1276754/task3/ui/contentassist/antlr/internal/InternalMydsl.g:1652:1: ( ( rule__Playlist__Group_4_2__0 )? )
            // ../at.ac.univie.swa.ase2014.a1276754.task3.mydsl.ui/src-gen/at/ac/univie/swa/ase2014/a1276754/task3/ui/contentassist/antlr/internal/InternalMydsl.g:1653:1: ( rule__Playlist__Group_4_2__0 )?
            {
             before(grammarAccess.getPlaylistAccess().getGroup_4_2()); 
            // ../at.ac.univie.swa.ase2014.a1276754.task3.mydsl.ui/src-gen/at/ac/univie/swa/ase2014/a1276754/task3/ui/contentassist/antlr/internal/InternalMydsl.g:1654:1: ( rule__Playlist__Group_4_2__0 )?
            int alt8=2;
            int LA8_0 = input.LA(1);

            if ( (LA8_0==34) ) {
                alt8=1;
            }
            switch (alt8) {
                case 1 :
                    // ../at.ac.univie.swa.ase2014.a1276754.task3.mydsl.ui/src-gen/at/ac/univie/swa/ase2014/a1276754/task3/ui/contentassist/antlr/internal/InternalMydsl.g:1654:2: rule__Playlist__Group_4_2__0
                    {
                    pushFollow(FOLLOW_rule__Playlist__Group_4_2__0_in_rule__Playlist__Group_4__2__Impl3276);
                    rule__Playlist__Group_4_2__0();

                    state._fsp--;


                    }
                    break;

            }

             after(grammarAccess.getPlaylistAccess().getGroup_4_2()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Playlist__Group_4__2__Impl"


    // $ANTLR start "rule__Playlist__Group_4_2__0"
    // ../at.ac.univie.swa.ase2014.a1276754.task3.mydsl.ui/src-gen/at/ac/univie/swa/ase2014/a1276754/task3/ui/contentassist/antlr/internal/InternalMydsl.g:1670:1: rule__Playlist__Group_4_2__0 : rule__Playlist__Group_4_2__0__Impl rule__Playlist__Group_4_2__1 ;
    public final void rule__Playlist__Group_4_2__0() throws RecognitionException {

        		int stackSize = keepStackSize();
            
        try {
            // ../at.ac.univie.swa.ase2014.a1276754.task3.mydsl.ui/src-gen/at/ac/univie/swa/ase2014/a1276754/task3/ui/contentassist/antlr/internal/InternalMydsl.g:1674:1: ( rule__Playlist__Group_4_2__0__Impl rule__Playlist__Group_4_2__1 )
            // ../at.ac.univie.swa.ase2014.a1276754.task3.mydsl.ui/src-gen/at/ac/univie/swa/ase2014/a1276754/task3/ui/contentassist/antlr/internal/InternalMydsl.g:1675:2: rule__Playlist__Group_4_2__0__Impl rule__Playlist__Group_4_2__1
            {
            pushFollow(FOLLOW_rule__Playlist__Group_4_2__0__Impl_in_rule__Playlist__Group_4_2__03313);
            rule__Playlist__Group_4_2__0__Impl();

            state._fsp--;

            pushFollow(FOLLOW_rule__Playlist__Group_4_2__1_in_rule__Playlist__Group_4_2__03316);
            rule__Playlist__Group_4_2__1();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Playlist__Group_4_2__0"


    // $ANTLR start "rule__Playlist__Group_4_2__0__Impl"
    // ../at.ac.univie.swa.ase2014.a1276754.task3.mydsl.ui/src-gen/at/ac/univie/swa/ase2014/a1276754/task3/ui/contentassist/antlr/internal/InternalMydsl.g:1682:1: rule__Playlist__Group_4_2__0__Impl : ( 'without' ) ;
    public final void rule__Playlist__Group_4_2__0__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
            
        try {
            // ../at.ac.univie.swa.ase2014.a1276754.task3.mydsl.ui/src-gen/at/ac/univie/swa/ase2014/a1276754/task3/ui/contentassist/antlr/internal/InternalMydsl.g:1686:1: ( ( 'without' ) )
            // ../at.ac.univie.swa.ase2014.a1276754.task3.mydsl.ui/src-gen/at/ac/univie/swa/ase2014/a1276754/task3/ui/contentassist/antlr/internal/InternalMydsl.g:1687:1: ( 'without' )
            {
            // ../at.ac.univie.swa.ase2014.a1276754.task3.mydsl.ui/src-gen/at/ac/univie/swa/ase2014/a1276754/task3/ui/contentassist/antlr/internal/InternalMydsl.g:1687:1: ( 'without' )
            // ../at.ac.univie.swa.ase2014.a1276754.task3.mydsl.ui/src-gen/at/ac/univie/swa/ase2014/a1276754/task3/ui/contentassist/antlr/internal/InternalMydsl.g:1688:1: 'without'
            {
             before(grammarAccess.getPlaylistAccess().getWithoutKeyword_4_2_0()); 
            match(input,34,FOLLOW_34_in_rule__Playlist__Group_4_2__0__Impl3344); 
             after(grammarAccess.getPlaylistAccess().getWithoutKeyword_4_2_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Playlist__Group_4_2__0__Impl"


    // $ANTLR start "rule__Playlist__Group_4_2__1"
    // ../at.ac.univie.swa.ase2014.a1276754.task3.mydsl.ui/src-gen/at/ac/univie/swa/ase2014/a1276754/task3/ui/contentassist/antlr/internal/InternalMydsl.g:1701:1: rule__Playlist__Group_4_2__1 : rule__Playlist__Group_4_2__1__Impl rule__Playlist__Group_4_2__2 ;
    public final void rule__Playlist__Group_4_2__1() throws RecognitionException {

        		int stackSize = keepStackSize();
            
        try {
            // ../at.ac.univie.swa.ase2014.a1276754.task3.mydsl.ui/src-gen/at/ac/univie/swa/ase2014/a1276754/task3/ui/contentassist/antlr/internal/InternalMydsl.g:1705:1: ( rule__Playlist__Group_4_2__1__Impl rule__Playlist__Group_4_2__2 )
            // ../at.ac.univie.swa.ase2014.a1276754.task3.mydsl.ui/src-gen/at/ac/univie/swa/ase2014/a1276754/task3/ui/contentassist/antlr/internal/InternalMydsl.g:1706:2: rule__Playlist__Group_4_2__1__Impl rule__Playlist__Group_4_2__2
            {
            pushFollow(FOLLOW_rule__Playlist__Group_4_2__1__Impl_in_rule__Playlist__Group_4_2__13375);
            rule__Playlist__Group_4_2__1__Impl();

            state._fsp--;

            pushFollow(FOLLOW_rule__Playlist__Group_4_2__2_in_rule__Playlist__Group_4_2__13378);
            rule__Playlist__Group_4_2__2();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Playlist__Group_4_2__1"


    // $ANTLR start "rule__Playlist__Group_4_2__1__Impl"
    // ../at.ac.univie.swa.ase2014.a1276754.task3.mydsl.ui/src-gen/at/ac/univie/swa/ase2014/a1276754/task3/ui/contentassist/antlr/internal/InternalMydsl.g:1713:1: rule__Playlist__Group_4_2__1__Impl : ( ( rule__Playlist__Group_4_2_1__0 )* ) ;
    public final void rule__Playlist__Group_4_2__1__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
            
        try {
            // ../at.ac.univie.swa.ase2014.a1276754.task3.mydsl.ui/src-gen/at/ac/univie/swa/ase2014/a1276754/task3/ui/contentassist/antlr/internal/InternalMydsl.g:1717:1: ( ( ( rule__Playlist__Group_4_2_1__0 )* ) )
            // ../at.ac.univie.swa.ase2014.a1276754.task3.mydsl.ui/src-gen/at/ac/univie/swa/ase2014/a1276754/task3/ui/contentassist/antlr/internal/InternalMydsl.g:1718:1: ( ( rule__Playlist__Group_4_2_1__0 )* )
            {
            // ../at.ac.univie.swa.ase2014.a1276754.task3.mydsl.ui/src-gen/at/ac/univie/swa/ase2014/a1276754/task3/ui/contentassist/antlr/internal/InternalMydsl.g:1718:1: ( ( rule__Playlist__Group_4_2_1__0 )* )
            // ../at.ac.univie.swa.ase2014.a1276754.task3.mydsl.ui/src-gen/at/ac/univie/swa/ase2014/a1276754/task3/ui/contentassist/antlr/internal/InternalMydsl.g:1719:1: ( rule__Playlist__Group_4_2_1__0 )*
            {
             before(grammarAccess.getPlaylistAccess().getGroup_4_2_1()); 
            // ../at.ac.univie.swa.ase2014.a1276754.task3.mydsl.ui/src-gen/at/ac/univie/swa/ase2014/a1276754/task3/ui/contentassist/antlr/internal/InternalMydsl.g:1720:1: ( rule__Playlist__Group_4_2_1__0 )*
            loop9:
            do {
                int alt9=2;
                int LA9_0 = input.LA(1);

                if ( (LA9_0==RULE_ID) ) {
                    int LA9_1 = input.LA(2);

                    if ( (LA9_1==32) ) {
                        alt9=1;
                    }


                }


                switch (alt9) {
            	case 1 :
            	    // ../at.ac.univie.swa.ase2014.a1276754.task3.mydsl.ui/src-gen/at/ac/univie/swa/ase2014/a1276754/task3/ui/contentassist/antlr/internal/InternalMydsl.g:1720:2: rule__Playlist__Group_4_2_1__0
            	    {
            	    pushFollow(FOLLOW_rule__Playlist__Group_4_2_1__0_in_rule__Playlist__Group_4_2__1__Impl3405);
            	    rule__Playlist__Group_4_2_1__0();

            	    state._fsp--;


            	    }
            	    break;

            	default :
            	    break loop9;
                }
            } while (true);

             after(grammarAccess.getPlaylistAccess().getGroup_4_2_1()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Playlist__Group_4_2__1__Impl"


    // $ANTLR start "rule__Playlist__Group_4_2__2"
    // ../at.ac.univie.swa.ase2014.a1276754.task3.mydsl.ui/src-gen/at/ac/univie/swa/ase2014/a1276754/task3/ui/contentassist/antlr/internal/InternalMydsl.g:1730:1: rule__Playlist__Group_4_2__2 : rule__Playlist__Group_4_2__2__Impl ;
    public final void rule__Playlist__Group_4_2__2() throws RecognitionException {

        		int stackSize = keepStackSize();
            
        try {
            // ../at.ac.univie.swa.ase2014.a1276754.task3.mydsl.ui/src-gen/at/ac/univie/swa/ase2014/a1276754/task3/ui/contentassist/antlr/internal/InternalMydsl.g:1734:1: ( rule__Playlist__Group_4_2__2__Impl )
            // ../at.ac.univie.swa.ase2014.a1276754.task3.mydsl.ui/src-gen/at/ac/univie/swa/ase2014/a1276754/task3/ui/contentassist/antlr/internal/InternalMydsl.g:1735:2: rule__Playlist__Group_4_2__2__Impl
            {
            pushFollow(FOLLOW_rule__Playlist__Group_4_2__2__Impl_in_rule__Playlist__Group_4_2__23436);
            rule__Playlist__Group_4_2__2__Impl();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Playlist__Group_4_2__2"


    // $ANTLR start "rule__Playlist__Group_4_2__2__Impl"
    // ../at.ac.univie.swa.ase2014.a1276754.task3.mydsl.ui/src-gen/at/ac/univie/swa/ase2014/a1276754/task3/ui/contentassist/antlr/internal/InternalMydsl.g:1741:1: rule__Playlist__Group_4_2__2__Impl : ( ( rule__Playlist__ExclAssignment_4_2_2 ) ) ;
    public final void rule__Playlist__Group_4_2__2__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
            
        try {
            // ../at.ac.univie.swa.ase2014.a1276754.task3.mydsl.ui/src-gen/at/ac/univie/swa/ase2014/a1276754/task3/ui/contentassist/antlr/internal/InternalMydsl.g:1745:1: ( ( ( rule__Playlist__ExclAssignment_4_2_2 ) ) )
            // ../at.ac.univie.swa.ase2014.a1276754.task3.mydsl.ui/src-gen/at/ac/univie/swa/ase2014/a1276754/task3/ui/contentassist/antlr/internal/InternalMydsl.g:1746:1: ( ( rule__Playlist__ExclAssignment_4_2_2 ) )
            {
            // ../at.ac.univie.swa.ase2014.a1276754.task3.mydsl.ui/src-gen/at/ac/univie/swa/ase2014/a1276754/task3/ui/contentassist/antlr/internal/InternalMydsl.g:1746:1: ( ( rule__Playlist__ExclAssignment_4_2_2 ) )
            // ../at.ac.univie.swa.ase2014.a1276754.task3.mydsl.ui/src-gen/at/ac/univie/swa/ase2014/a1276754/task3/ui/contentassist/antlr/internal/InternalMydsl.g:1747:1: ( rule__Playlist__ExclAssignment_4_2_2 )
            {
             before(grammarAccess.getPlaylistAccess().getExclAssignment_4_2_2()); 
            // ../at.ac.univie.swa.ase2014.a1276754.task3.mydsl.ui/src-gen/at/ac/univie/swa/ase2014/a1276754/task3/ui/contentassist/antlr/internal/InternalMydsl.g:1748:1: ( rule__Playlist__ExclAssignment_4_2_2 )
            // ../at.ac.univie.swa.ase2014.a1276754.task3.mydsl.ui/src-gen/at/ac/univie/swa/ase2014/a1276754/task3/ui/contentassist/antlr/internal/InternalMydsl.g:1748:2: rule__Playlist__ExclAssignment_4_2_2
            {
            pushFollow(FOLLOW_rule__Playlist__ExclAssignment_4_2_2_in_rule__Playlist__Group_4_2__2__Impl3463);
            rule__Playlist__ExclAssignment_4_2_2();

            state._fsp--;


            }

             after(grammarAccess.getPlaylistAccess().getExclAssignment_4_2_2()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Playlist__Group_4_2__2__Impl"


    // $ANTLR start "rule__Playlist__Group_4_2_1__0"
    // ../at.ac.univie.swa.ase2014.a1276754.task3.mydsl.ui/src-gen/at/ac/univie/swa/ase2014/a1276754/task3/ui/contentassist/antlr/internal/InternalMydsl.g:1764:1: rule__Playlist__Group_4_2_1__0 : rule__Playlist__Group_4_2_1__0__Impl rule__Playlist__Group_4_2_1__1 ;
    public final void rule__Playlist__Group_4_2_1__0() throws RecognitionException {

        		int stackSize = keepStackSize();
            
        try {
            // ../at.ac.univie.swa.ase2014.a1276754.task3.mydsl.ui/src-gen/at/ac/univie/swa/ase2014/a1276754/task3/ui/contentassist/antlr/internal/InternalMydsl.g:1768:1: ( rule__Playlist__Group_4_2_1__0__Impl rule__Playlist__Group_4_2_1__1 )
            // ../at.ac.univie.swa.ase2014.a1276754.task3.mydsl.ui/src-gen/at/ac/univie/swa/ase2014/a1276754/task3/ui/contentassist/antlr/internal/InternalMydsl.g:1769:2: rule__Playlist__Group_4_2_1__0__Impl rule__Playlist__Group_4_2_1__1
            {
            pushFollow(FOLLOW_rule__Playlist__Group_4_2_1__0__Impl_in_rule__Playlist__Group_4_2_1__03499);
            rule__Playlist__Group_4_2_1__0__Impl();

            state._fsp--;

            pushFollow(FOLLOW_rule__Playlist__Group_4_2_1__1_in_rule__Playlist__Group_4_2_1__03502);
            rule__Playlist__Group_4_2_1__1();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Playlist__Group_4_2_1__0"


    // $ANTLR start "rule__Playlist__Group_4_2_1__0__Impl"
    // ../at.ac.univie.swa.ase2014.a1276754.task3.mydsl.ui/src-gen/at/ac/univie/swa/ase2014/a1276754/task3/ui/contentassist/antlr/internal/InternalMydsl.g:1776:1: rule__Playlist__Group_4_2_1__0__Impl : ( ( rule__Playlist__ExclAssignment_4_2_1_0 ) ) ;
    public final void rule__Playlist__Group_4_2_1__0__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
            
        try {
            // ../at.ac.univie.swa.ase2014.a1276754.task3.mydsl.ui/src-gen/at/ac/univie/swa/ase2014/a1276754/task3/ui/contentassist/antlr/internal/InternalMydsl.g:1780:1: ( ( ( rule__Playlist__ExclAssignment_4_2_1_0 ) ) )
            // ../at.ac.univie.swa.ase2014.a1276754.task3.mydsl.ui/src-gen/at/ac/univie/swa/ase2014/a1276754/task3/ui/contentassist/antlr/internal/InternalMydsl.g:1781:1: ( ( rule__Playlist__ExclAssignment_4_2_1_0 ) )
            {
            // ../at.ac.univie.swa.ase2014.a1276754.task3.mydsl.ui/src-gen/at/ac/univie/swa/ase2014/a1276754/task3/ui/contentassist/antlr/internal/InternalMydsl.g:1781:1: ( ( rule__Playlist__ExclAssignment_4_2_1_0 ) )
            // ../at.ac.univie.swa.ase2014.a1276754.task3.mydsl.ui/src-gen/at/ac/univie/swa/ase2014/a1276754/task3/ui/contentassist/antlr/internal/InternalMydsl.g:1782:1: ( rule__Playlist__ExclAssignment_4_2_1_0 )
            {
             before(grammarAccess.getPlaylistAccess().getExclAssignment_4_2_1_0()); 
            // ../at.ac.univie.swa.ase2014.a1276754.task3.mydsl.ui/src-gen/at/ac/univie/swa/ase2014/a1276754/task3/ui/contentassist/antlr/internal/InternalMydsl.g:1783:1: ( rule__Playlist__ExclAssignment_4_2_1_0 )
            // ../at.ac.univie.swa.ase2014.a1276754.task3.mydsl.ui/src-gen/at/ac/univie/swa/ase2014/a1276754/task3/ui/contentassist/antlr/internal/InternalMydsl.g:1783:2: rule__Playlist__ExclAssignment_4_2_1_0
            {
            pushFollow(FOLLOW_rule__Playlist__ExclAssignment_4_2_1_0_in_rule__Playlist__Group_4_2_1__0__Impl3529);
            rule__Playlist__ExclAssignment_4_2_1_0();

            state._fsp--;


            }

             after(grammarAccess.getPlaylistAccess().getExclAssignment_4_2_1_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Playlist__Group_4_2_1__0__Impl"


    // $ANTLR start "rule__Playlist__Group_4_2_1__1"
    // ../at.ac.univie.swa.ase2014.a1276754.task3.mydsl.ui/src-gen/at/ac/univie/swa/ase2014/a1276754/task3/ui/contentassist/antlr/internal/InternalMydsl.g:1793:1: rule__Playlist__Group_4_2_1__1 : rule__Playlist__Group_4_2_1__1__Impl ;
    public final void rule__Playlist__Group_4_2_1__1() throws RecognitionException {

        		int stackSize = keepStackSize();
            
        try {
            // ../at.ac.univie.swa.ase2014.a1276754.task3.mydsl.ui/src-gen/at/ac/univie/swa/ase2014/a1276754/task3/ui/contentassist/antlr/internal/InternalMydsl.g:1797:1: ( rule__Playlist__Group_4_2_1__1__Impl )
            // ../at.ac.univie.swa.ase2014.a1276754.task3.mydsl.ui/src-gen/at/ac/univie/swa/ase2014/a1276754/task3/ui/contentassist/antlr/internal/InternalMydsl.g:1798:2: rule__Playlist__Group_4_2_1__1__Impl
            {
            pushFollow(FOLLOW_rule__Playlist__Group_4_2_1__1__Impl_in_rule__Playlist__Group_4_2_1__13559);
            rule__Playlist__Group_4_2_1__1__Impl();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Playlist__Group_4_2_1__1"


    // $ANTLR start "rule__Playlist__Group_4_2_1__1__Impl"
    // ../at.ac.univie.swa.ase2014.a1276754.task3.mydsl.ui/src-gen/at/ac/univie/swa/ase2014/a1276754/task3/ui/contentassist/antlr/internal/InternalMydsl.g:1804:1: rule__Playlist__Group_4_2_1__1__Impl : ( ',' ) ;
    public final void rule__Playlist__Group_4_2_1__1__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
            
        try {
            // ../at.ac.univie.swa.ase2014.a1276754.task3.mydsl.ui/src-gen/at/ac/univie/swa/ase2014/a1276754/task3/ui/contentassist/antlr/internal/InternalMydsl.g:1808:1: ( ( ',' ) )
            // ../at.ac.univie.swa.ase2014.a1276754.task3.mydsl.ui/src-gen/at/ac/univie/swa/ase2014/a1276754/task3/ui/contentassist/antlr/internal/InternalMydsl.g:1809:1: ( ',' )
            {
            // ../at.ac.univie.swa.ase2014.a1276754.task3.mydsl.ui/src-gen/at/ac/univie/swa/ase2014/a1276754/task3/ui/contentassist/antlr/internal/InternalMydsl.g:1809:1: ( ',' )
            // ../at.ac.univie.swa.ase2014.a1276754.task3.mydsl.ui/src-gen/at/ac/univie/swa/ase2014/a1276754/task3/ui/contentassist/antlr/internal/InternalMydsl.g:1810:1: ','
            {
             before(grammarAccess.getPlaylistAccess().getCommaKeyword_4_2_1_1()); 
            match(input,32,FOLLOW_32_in_rule__Playlist__Group_4_2_1__1__Impl3587); 
             after(grammarAccess.getPlaylistAccess().getCommaKeyword_4_2_1_1()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Playlist__Group_4_2_1__1__Impl"


    // $ANTLR start "rule__Model__DistributorsAssignment_1"
    // ../at.ac.univie.swa.ase2014.a1276754.task3.mydsl.ui/src-gen/at/ac/univie/swa/ase2014/a1276754/task3/ui/contentassist/antlr/internal/InternalMydsl.g:1828:1: rule__Model__DistributorsAssignment_1 : ( ruleDistributor ) ;
    public final void rule__Model__DistributorsAssignment_1() throws RecognitionException {

        		int stackSize = keepStackSize();
            
        try {
            // ../at.ac.univie.swa.ase2014.a1276754.task3.mydsl.ui/src-gen/at/ac/univie/swa/ase2014/a1276754/task3/ui/contentassist/antlr/internal/InternalMydsl.g:1832:1: ( ( ruleDistributor ) )
            // ../at.ac.univie.swa.ase2014.a1276754.task3.mydsl.ui/src-gen/at/ac/univie/swa/ase2014/a1276754/task3/ui/contentassist/antlr/internal/InternalMydsl.g:1833:1: ( ruleDistributor )
            {
            // ../at.ac.univie.swa.ase2014.a1276754.task3.mydsl.ui/src-gen/at/ac/univie/swa/ase2014/a1276754/task3/ui/contentassist/antlr/internal/InternalMydsl.g:1833:1: ( ruleDistributor )
            // ../at.ac.univie.swa.ase2014.a1276754.task3.mydsl.ui/src-gen/at/ac/univie/swa/ase2014/a1276754/task3/ui/contentassist/antlr/internal/InternalMydsl.g:1834:1: ruleDistributor
            {
             before(grammarAccess.getModelAccess().getDistributorsDistributorParserRuleCall_1_0()); 
            pushFollow(FOLLOW_ruleDistributor_in_rule__Model__DistributorsAssignment_13627);
            ruleDistributor();

            state._fsp--;

             after(grammarAccess.getModelAccess().getDistributorsDistributorParserRuleCall_1_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Model__DistributorsAssignment_1"


    // $ANTLR start "rule__Model__SongsAssignment_3"
    // ../at.ac.univie.swa.ase2014.a1276754.task3.mydsl.ui/src-gen/at/ac/univie/swa/ase2014/a1276754/task3/ui/contentassist/antlr/internal/InternalMydsl.g:1843:1: rule__Model__SongsAssignment_3 : ( ruleSong ) ;
    public final void rule__Model__SongsAssignment_3() throws RecognitionException {

        		int stackSize = keepStackSize();
            
        try {
            // ../at.ac.univie.swa.ase2014.a1276754.task3.mydsl.ui/src-gen/at/ac/univie/swa/ase2014/a1276754/task3/ui/contentassist/antlr/internal/InternalMydsl.g:1847:1: ( ( ruleSong ) )
            // ../at.ac.univie.swa.ase2014.a1276754.task3.mydsl.ui/src-gen/at/ac/univie/swa/ase2014/a1276754/task3/ui/contentassist/antlr/internal/InternalMydsl.g:1848:1: ( ruleSong )
            {
            // ../at.ac.univie.swa.ase2014.a1276754.task3.mydsl.ui/src-gen/at/ac/univie/swa/ase2014/a1276754/task3/ui/contentassist/antlr/internal/InternalMydsl.g:1848:1: ( ruleSong )
            // ../at.ac.univie.swa.ase2014.a1276754.task3.mydsl.ui/src-gen/at/ac/univie/swa/ase2014/a1276754/task3/ui/contentassist/antlr/internal/InternalMydsl.g:1849:1: ruleSong
            {
             before(grammarAccess.getModelAccess().getSongsSongParserRuleCall_3_0()); 
            pushFollow(FOLLOW_ruleSong_in_rule__Model__SongsAssignment_33658);
            ruleSong();

            state._fsp--;

             after(grammarAccess.getModelAccess().getSongsSongParserRuleCall_3_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Model__SongsAssignment_3"


    // $ANTLR start "rule__Model__PlaylistsAssignment_5"
    // ../at.ac.univie.swa.ase2014.a1276754.task3.mydsl.ui/src-gen/at/ac/univie/swa/ase2014/a1276754/task3/ui/contentassist/antlr/internal/InternalMydsl.g:1858:1: rule__Model__PlaylistsAssignment_5 : ( rulePlaylist ) ;
    public final void rule__Model__PlaylistsAssignment_5() throws RecognitionException {

        		int stackSize = keepStackSize();
            
        try {
            // ../at.ac.univie.swa.ase2014.a1276754.task3.mydsl.ui/src-gen/at/ac/univie/swa/ase2014/a1276754/task3/ui/contentassist/antlr/internal/InternalMydsl.g:1862:1: ( ( rulePlaylist ) )
            // ../at.ac.univie.swa.ase2014.a1276754.task3.mydsl.ui/src-gen/at/ac/univie/swa/ase2014/a1276754/task3/ui/contentassist/antlr/internal/InternalMydsl.g:1863:1: ( rulePlaylist )
            {
            // ../at.ac.univie.swa.ase2014.a1276754.task3.mydsl.ui/src-gen/at/ac/univie/swa/ase2014/a1276754/task3/ui/contentassist/antlr/internal/InternalMydsl.g:1863:1: ( rulePlaylist )
            // ../at.ac.univie.swa.ase2014.a1276754.task3.mydsl.ui/src-gen/at/ac/univie/swa/ase2014/a1276754/task3/ui/contentassist/antlr/internal/InternalMydsl.g:1864:1: rulePlaylist
            {
             before(grammarAccess.getModelAccess().getPlaylistsPlaylistParserRuleCall_5_0()); 
            pushFollow(FOLLOW_rulePlaylist_in_rule__Model__PlaylistsAssignment_53689);
            rulePlaylist();

            state._fsp--;

             after(grammarAccess.getModelAccess().getPlaylistsPlaylistParserRuleCall_5_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Model__PlaylistsAssignment_5"


    // $ANTLR start "rule__Distributor__NameAssignment_0"
    // ../at.ac.univie.swa.ase2014.a1276754.task3.mydsl.ui/src-gen/at/ac/univie/swa/ase2014/a1276754/task3/ui/contentassist/antlr/internal/InternalMydsl.g:1873:1: rule__Distributor__NameAssignment_0 : ( RULE_ID ) ;
    public final void rule__Distributor__NameAssignment_0() throws RecognitionException {

        		int stackSize = keepStackSize();
            
        try {
            // ../at.ac.univie.swa.ase2014.a1276754.task3.mydsl.ui/src-gen/at/ac/univie/swa/ase2014/a1276754/task3/ui/contentassist/antlr/internal/InternalMydsl.g:1877:1: ( ( RULE_ID ) )
            // ../at.ac.univie.swa.ase2014.a1276754.task3.mydsl.ui/src-gen/at/ac/univie/swa/ase2014/a1276754/task3/ui/contentassist/antlr/internal/InternalMydsl.g:1878:1: ( RULE_ID )
            {
            // ../at.ac.univie.swa.ase2014.a1276754.task3.mydsl.ui/src-gen/at/ac/univie/swa/ase2014/a1276754/task3/ui/contentassist/antlr/internal/InternalMydsl.g:1878:1: ( RULE_ID )
            // ../at.ac.univie.swa.ase2014.a1276754.task3.mydsl.ui/src-gen/at/ac/univie/swa/ase2014/a1276754/task3/ui/contentassist/antlr/internal/InternalMydsl.g:1879:1: RULE_ID
            {
             before(grammarAccess.getDistributorAccess().getNameIDTerminalRuleCall_0_0()); 
            match(input,RULE_ID,FOLLOW_RULE_ID_in_rule__Distributor__NameAssignment_03720); 
             after(grammarAccess.getDistributorAccess().getNameIDTerminalRuleCall_0_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Distributor__NameAssignment_0"


    // $ANTLR start "rule__Distributor__AdresseAssignment_2"
    // ../at.ac.univie.swa.ase2014.a1276754.task3.mydsl.ui/src-gen/at/ac/univie/swa/ase2014/a1276754/task3/ui/contentassist/antlr/internal/InternalMydsl.g:1888:1: rule__Distributor__AdresseAssignment_2 : ( RULE_STRING ) ;
    public final void rule__Distributor__AdresseAssignment_2() throws RecognitionException {

        		int stackSize = keepStackSize();
            
        try {
            // ../at.ac.univie.swa.ase2014.a1276754.task3.mydsl.ui/src-gen/at/ac/univie/swa/ase2014/a1276754/task3/ui/contentassist/antlr/internal/InternalMydsl.g:1892:1: ( ( RULE_STRING ) )
            // ../at.ac.univie.swa.ase2014.a1276754.task3.mydsl.ui/src-gen/at/ac/univie/swa/ase2014/a1276754/task3/ui/contentassist/antlr/internal/InternalMydsl.g:1893:1: ( RULE_STRING )
            {
            // ../at.ac.univie.swa.ase2014.a1276754.task3.mydsl.ui/src-gen/at/ac/univie/swa/ase2014/a1276754/task3/ui/contentassist/antlr/internal/InternalMydsl.g:1893:1: ( RULE_STRING )
            // ../at.ac.univie.swa.ase2014.a1276754.task3.mydsl.ui/src-gen/at/ac/univie/swa/ase2014/a1276754/task3/ui/contentassist/antlr/internal/InternalMydsl.g:1894:1: RULE_STRING
            {
             before(grammarAccess.getDistributorAccess().getAdresseSTRINGTerminalRuleCall_2_0()); 
            match(input,RULE_STRING,FOLLOW_RULE_STRING_in_rule__Distributor__AdresseAssignment_23751); 
             after(grammarAccess.getDistributorAccess().getAdresseSTRINGTerminalRuleCall_2_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Distributor__AdresseAssignment_2"


    // $ANTLR start "rule__Distributor__Acc_infoAssignment_4"
    // ../at.ac.univie.swa.ase2014.a1276754.task3.mydsl.ui/src-gen/at/ac/univie/swa/ase2014/a1276754/task3/ui/contentassist/antlr/internal/InternalMydsl.g:1903:1: rule__Distributor__Acc_infoAssignment_4 : ( ruleAccount_Information ) ;
    public final void rule__Distributor__Acc_infoAssignment_4() throws RecognitionException {

        		int stackSize = keepStackSize();
            
        try {
            // ../at.ac.univie.swa.ase2014.a1276754.task3.mydsl.ui/src-gen/at/ac/univie/swa/ase2014/a1276754/task3/ui/contentassist/antlr/internal/InternalMydsl.g:1907:1: ( ( ruleAccount_Information ) )
            // ../at.ac.univie.swa.ase2014.a1276754.task3.mydsl.ui/src-gen/at/ac/univie/swa/ase2014/a1276754/task3/ui/contentassist/antlr/internal/InternalMydsl.g:1908:1: ( ruleAccount_Information )
            {
            // ../at.ac.univie.swa.ase2014.a1276754.task3.mydsl.ui/src-gen/at/ac/univie/swa/ase2014/a1276754/task3/ui/contentassist/antlr/internal/InternalMydsl.g:1908:1: ( ruleAccount_Information )
            // ../at.ac.univie.swa.ase2014.a1276754.task3.mydsl.ui/src-gen/at/ac/univie/swa/ase2014/a1276754/task3/ui/contentassist/antlr/internal/InternalMydsl.g:1909:1: ruleAccount_Information
            {
             before(grammarAccess.getDistributorAccess().getAcc_infoAccount_InformationParserRuleCall_4_0()); 
            pushFollow(FOLLOW_ruleAccount_Information_in_rule__Distributor__Acc_infoAssignment_43782);
            ruleAccount_Information();

            state._fsp--;

             after(grammarAccess.getDistributorAccess().getAcc_infoAccount_InformationParserRuleCall_4_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Distributor__Acc_infoAssignment_4"


    // $ANTLR start "rule__Account_Information__IbanAssignment_1"
    // ../at.ac.univie.swa.ase2014.a1276754.task3.mydsl.ui/src-gen/at/ac/univie/swa/ase2014/a1276754/task3/ui/contentassist/antlr/internal/InternalMydsl.g:1918:1: rule__Account_Information__IbanAssignment_1 : ( RULE_STRING ) ;
    public final void rule__Account_Information__IbanAssignment_1() throws RecognitionException {

        		int stackSize = keepStackSize();
            
        try {
            // ../at.ac.univie.swa.ase2014.a1276754.task3.mydsl.ui/src-gen/at/ac/univie/swa/ase2014/a1276754/task3/ui/contentassist/antlr/internal/InternalMydsl.g:1922:1: ( ( RULE_STRING ) )
            // ../at.ac.univie.swa.ase2014.a1276754.task3.mydsl.ui/src-gen/at/ac/univie/swa/ase2014/a1276754/task3/ui/contentassist/antlr/internal/InternalMydsl.g:1923:1: ( RULE_STRING )
            {
            // ../at.ac.univie.swa.ase2014.a1276754.task3.mydsl.ui/src-gen/at/ac/univie/swa/ase2014/a1276754/task3/ui/contentassist/antlr/internal/InternalMydsl.g:1923:1: ( RULE_STRING )
            // ../at.ac.univie.swa.ase2014.a1276754.task3.mydsl.ui/src-gen/at/ac/univie/swa/ase2014/a1276754/task3/ui/contentassist/antlr/internal/InternalMydsl.g:1924:1: RULE_STRING
            {
             before(grammarAccess.getAccount_InformationAccess().getIbanSTRINGTerminalRuleCall_1_0()); 
            match(input,RULE_STRING,FOLLOW_RULE_STRING_in_rule__Account_Information__IbanAssignment_13813); 
             after(grammarAccess.getAccount_InformationAccess().getIbanSTRINGTerminalRuleCall_1_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Account_Information__IbanAssignment_1"


    // $ANTLR start "rule__Account_Information__BicAssignment_3"
    // ../at.ac.univie.swa.ase2014.a1276754.task3.mydsl.ui/src-gen/at/ac/univie/swa/ase2014/a1276754/task3/ui/contentassist/antlr/internal/InternalMydsl.g:1933:1: rule__Account_Information__BicAssignment_3 : ( RULE_STRING ) ;
    public final void rule__Account_Information__BicAssignment_3() throws RecognitionException {

        		int stackSize = keepStackSize();
            
        try {
            // ../at.ac.univie.swa.ase2014.a1276754.task3.mydsl.ui/src-gen/at/ac/univie/swa/ase2014/a1276754/task3/ui/contentassist/antlr/internal/InternalMydsl.g:1937:1: ( ( RULE_STRING ) )
            // ../at.ac.univie.swa.ase2014.a1276754.task3.mydsl.ui/src-gen/at/ac/univie/swa/ase2014/a1276754/task3/ui/contentassist/antlr/internal/InternalMydsl.g:1938:1: ( RULE_STRING )
            {
            // ../at.ac.univie.swa.ase2014.a1276754.task3.mydsl.ui/src-gen/at/ac/univie/swa/ase2014/a1276754/task3/ui/contentassist/antlr/internal/InternalMydsl.g:1938:1: ( RULE_STRING )
            // ../at.ac.univie.swa.ase2014.a1276754.task3.mydsl.ui/src-gen/at/ac/univie/swa/ase2014/a1276754/task3/ui/contentassist/antlr/internal/InternalMydsl.g:1939:1: RULE_STRING
            {
             before(grammarAccess.getAccount_InformationAccess().getBicSTRINGTerminalRuleCall_3_0()); 
            match(input,RULE_STRING,FOLLOW_RULE_STRING_in_rule__Account_Information__BicAssignment_33844); 
             after(grammarAccess.getAccount_InformationAccess().getBicSTRINGTerminalRuleCall_3_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Account_Information__BicAssignment_3"


    // $ANTLR start "rule__Song__NameAssignment_0"
    // ../at.ac.univie.swa.ase2014.a1276754.task3.mydsl.ui/src-gen/at/ac/univie/swa/ase2014/a1276754/task3/ui/contentassist/antlr/internal/InternalMydsl.g:1948:1: rule__Song__NameAssignment_0 : ( RULE_ID ) ;
    public final void rule__Song__NameAssignment_0() throws RecognitionException {

        		int stackSize = keepStackSize();
            
        try {
            // ../at.ac.univie.swa.ase2014.a1276754.task3.mydsl.ui/src-gen/at/ac/univie/swa/ase2014/a1276754/task3/ui/contentassist/antlr/internal/InternalMydsl.g:1952:1: ( ( RULE_ID ) )
            // ../at.ac.univie.swa.ase2014.a1276754.task3.mydsl.ui/src-gen/at/ac/univie/swa/ase2014/a1276754/task3/ui/contentassist/antlr/internal/InternalMydsl.g:1953:1: ( RULE_ID )
            {
            // ../at.ac.univie.swa.ase2014.a1276754.task3.mydsl.ui/src-gen/at/ac/univie/swa/ase2014/a1276754/task3/ui/contentassist/antlr/internal/InternalMydsl.g:1953:1: ( RULE_ID )
            // ../at.ac.univie.swa.ase2014.a1276754.task3.mydsl.ui/src-gen/at/ac/univie/swa/ase2014/a1276754/task3/ui/contentassist/antlr/internal/InternalMydsl.g:1954:1: RULE_ID
            {
             before(grammarAccess.getSongAccess().getNameIDTerminalRuleCall_0_0()); 
            match(input,RULE_ID,FOLLOW_RULE_ID_in_rule__Song__NameAssignment_03875); 
             after(grammarAccess.getSongAccess().getNameIDTerminalRuleCall_0_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Song__NameAssignment_0"


    // $ANTLR start "rule__Song__ArtistAssignment_2"
    // ../at.ac.univie.swa.ase2014.a1276754.task3.mydsl.ui/src-gen/at/ac/univie/swa/ase2014/a1276754/task3/ui/contentassist/antlr/internal/InternalMydsl.g:1963:1: rule__Song__ArtistAssignment_2 : ( RULE_STRING ) ;
    public final void rule__Song__ArtistAssignment_2() throws RecognitionException {

        		int stackSize = keepStackSize();
            
        try {
            // ../at.ac.univie.swa.ase2014.a1276754.task3.mydsl.ui/src-gen/at/ac/univie/swa/ase2014/a1276754/task3/ui/contentassist/antlr/internal/InternalMydsl.g:1967:1: ( ( RULE_STRING ) )
            // ../at.ac.univie.swa.ase2014.a1276754.task3.mydsl.ui/src-gen/at/ac/univie/swa/ase2014/a1276754/task3/ui/contentassist/antlr/internal/InternalMydsl.g:1968:1: ( RULE_STRING )
            {
            // ../at.ac.univie.swa.ase2014.a1276754.task3.mydsl.ui/src-gen/at/ac/univie/swa/ase2014/a1276754/task3/ui/contentassist/antlr/internal/InternalMydsl.g:1968:1: ( RULE_STRING )
            // ../at.ac.univie.swa.ase2014.a1276754.task3.mydsl.ui/src-gen/at/ac/univie/swa/ase2014/a1276754/task3/ui/contentassist/antlr/internal/InternalMydsl.g:1969:1: RULE_STRING
            {
             before(grammarAccess.getSongAccess().getArtistSTRINGTerminalRuleCall_2_0()); 
            match(input,RULE_STRING,FOLLOW_RULE_STRING_in_rule__Song__ArtistAssignment_23906); 
             after(grammarAccess.getSongAccess().getArtistSTRINGTerminalRuleCall_2_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Song__ArtistAssignment_2"


    // $ANTLR start "rule__Song__DistAssignment_4"
    // ../at.ac.univie.swa.ase2014.a1276754.task3.mydsl.ui/src-gen/at/ac/univie/swa/ase2014/a1276754/task3/ui/contentassist/antlr/internal/InternalMydsl.g:1978:1: rule__Song__DistAssignment_4 : ( ( RULE_ID ) ) ;
    public final void rule__Song__DistAssignment_4() throws RecognitionException {

        		int stackSize = keepStackSize();
            
        try {
            // ../at.ac.univie.swa.ase2014.a1276754.task3.mydsl.ui/src-gen/at/ac/univie/swa/ase2014/a1276754/task3/ui/contentassist/antlr/internal/InternalMydsl.g:1982:1: ( ( ( RULE_ID ) ) )
            // ../at.ac.univie.swa.ase2014.a1276754.task3.mydsl.ui/src-gen/at/ac/univie/swa/ase2014/a1276754/task3/ui/contentassist/antlr/internal/InternalMydsl.g:1983:1: ( ( RULE_ID ) )
            {
            // ../at.ac.univie.swa.ase2014.a1276754.task3.mydsl.ui/src-gen/at/ac/univie/swa/ase2014/a1276754/task3/ui/contentassist/antlr/internal/InternalMydsl.g:1983:1: ( ( RULE_ID ) )
            // ../at.ac.univie.swa.ase2014.a1276754.task3.mydsl.ui/src-gen/at/ac/univie/swa/ase2014/a1276754/task3/ui/contentassist/antlr/internal/InternalMydsl.g:1984:1: ( RULE_ID )
            {
             before(grammarAccess.getSongAccess().getDistDistributorCrossReference_4_0()); 
            // ../at.ac.univie.swa.ase2014.a1276754.task3.mydsl.ui/src-gen/at/ac/univie/swa/ase2014/a1276754/task3/ui/contentassist/antlr/internal/InternalMydsl.g:1985:1: ( RULE_ID )
            // ../at.ac.univie.swa.ase2014.a1276754.task3.mydsl.ui/src-gen/at/ac/univie/swa/ase2014/a1276754/task3/ui/contentassist/antlr/internal/InternalMydsl.g:1986:1: RULE_ID
            {
             before(grammarAccess.getSongAccess().getDistDistributorIDTerminalRuleCall_4_0_1()); 
            match(input,RULE_ID,FOLLOW_RULE_ID_in_rule__Song__DistAssignment_43941); 
             after(grammarAccess.getSongAccess().getDistDistributorIDTerminalRuleCall_4_0_1()); 

            }

             after(grammarAccess.getSongAccess().getDistDistributorCrossReference_4_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Song__DistAssignment_4"


    // $ANTLR start "rule__Song__LengthAssignment_6"
    // ../at.ac.univie.swa.ase2014.a1276754.task3.mydsl.ui/src-gen/at/ac/univie/swa/ase2014/a1276754/task3/ui/contentassist/antlr/internal/InternalMydsl.g:1997:1: rule__Song__LengthAssignment_6 : ( ruleTime ) ;
    public final void rule__Song__LengthAssignment_6() throws RecognitionException {

        		int stackSize = keepStackSize();
            
        try {
            // ../at.ac.univie.swa.ase2014.a1276754.task3.mydsl.ui/src-gen/at/ac/univie/swa/ase2014/a1276754/task3/ui/contentassist/antlr/internal/InternalMydsl.g:2001:1: ( ( ruleTime ) )
            // ../at.ac.univie.swa.ase2014.a1276754.task3.mydsl.ui/src-gen/at/ac/univie/swa/ase2014/a1276754/task3/ui/contentassist/antlr/internal/InternalMydsl.g:2002:1: ( ruleTime )
            {
            // ../at.ac.univie.swa.ase2014.a1276754.task3.mydsl.ui/src-gen/at/ac/univie/swa/ase2014/a1276754/task3/ui/contentassist/antlr/internal/InternalMydsl.g:2002:1: ( ruleTime )
            // ../at.ac.univie.swa.ase2014.a1276754.task3.mydsl.ui/src-gen/at/ac/univie/swa/ase2014/a1276754/task3/ui/contentassist/antlr/internal/InternalMydsl.g:2003:1: ruleTime
            {
             before(grammarAccess.getSongAccess().getLengthTimeParserRuleCall_6_0()); 
            pushFollow(FOLLOW_ruleTime_in_rule__Song__LengthAssignment_63976);
            ruleTime();

            state._fsp--;

             after(grammarAccess.getSongAccess().getLengthTimeParserRuleCall_6_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Song__LengthAssignment_6"


    // $ANTLR start "rule__Song__GenreAssignment_8"
    // ../at.ac.univie.swa.ase2014.a1276754.task3.mydsl.ui/src-gen/at/ac/univie/swa/ase2014/a1276754/task3/ui/contentassist/antlr/internal/InternalMydsl.g:2012:1: rule__Song__GenreAssignment_8 : ( ruleGenre ) ;
    public final void rule__Song__GenreAssignment_8() throws RecognitionException {

        		int stackSize = keepStackSize();
            
        try {
            // ../at.ac.univie.swa.ase2014.a1276754.task3.mydsl.ui/src-gen/at/ac/univie/swa/ase2014/a1276754/task3/ui/contentassist/antlr/internal/InternalMydsl.g:2016:1: ( ( ruleGenre ) )
            // ../at.ac.univie.swa.ase2014.a1276754.task3.mydsl.ui/src-gen/at/ac/univie/swa/ase2014/a1276754/task3/ui/contentassist/antlr/internal/InternalMydsl.g:2017:1: ( ruleGenre )
            {
            // ../at.ac.univie.swa.ase2014.a1276754.task3.mydsl.ui/src-gen/at/ac/univie/swa/ase2014/a1276754/task3/ui/contentassist/antlr/internal/InternalMydsl.g:2017:1: ( ruleGenre )
            // ../at.ac.univie.swa.ase2014.a1276754.task3.mydsl.ui/src-gen/at/ac/univie/swa/ase2014/a1276754/task3/ui/contentassist/antlr/internal/InternalMydsl.g:2018:1: ruleGenre
            {
             before(grammarAccess.getSongAccess().getGenreGenreEnumRuleCall_8_0()); 
            pushFollow(FOLLOW_ruleGenre_in_rule__Song__GenreAssignment_84007);
            ruleGenre();

            state._fsp--;

             after(grammarAccess.getSongAccess().getGenreGenreEnumRuleCall_8_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Song__GenreAssignment_8"


    // $ANTLR start "rule__Song__PriceAssignment_10"
    // ../at.ac.univie.swa.ase2014.a1276754.task3.mydsl.ui/src-gen/at/ac/univie/swa/ase2014/a1276754/task3/ui/contentassist/antlr/internal/InternalMydsl.g:2027:1: rule__Song__PriceAssignment_10 : ( ruleDouble ) ;
    public final void rule__Song__PriceAssignment_10() throws RecognitionException {

        		int stackSize = keepStackSize();
            
        try {
            // ../at.ac.univie.swa.ase2014.a1276754.task3.mydsl.ui/src-gen/at/ac/univie/swa/ase2014/a1276754/task3/ui/contentassist/antlr/internal/InternalMydsl.g:2031:1: ( ( ruleDouble ) )
            // ../at.ac.univie.swa.ase2014.a1276754.task3.mydsl.ui/src-gen/at/ac/univie/swa/ase2014/a1276754/task3/ui/contentassist/antlr/internal/InternalMydsl.g:2032:1: ( ruleDouble )
            {
            // ../at.ac.univie.swa.ase2014.a1276754.task3.mydsl.ui/src-gen/at/ac/univie/swa/ase2014/a1276754/task3/ui/contentassist/antlr/internal/InternalMydsl.g:2032:1: ( ruleDouble )
            // ../at.ac.univie.swa.ase2014.a1276754.task3.mydsl.ui/src-gen/at/ac/univie/swa/ase2014/a1276754/task3/ui/contentassist/antlr/internal/InternalMydsl.g:2033:1: ruleDouble
            {
             before(grammarAccess.getSongAccess().getPriceDoubleParserRuleCall_10_0()); 
            pushFollow(FOLLOW_ruleDouble_in_rule__Song__PriceAssignment_104038);
            ruleDouble();

            state._fsp--;

             after(grammarAccess.getSongAccess().getPriceDoubleParserRuleCall_10_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Song__PriceAssignment_10"


    // $ANTLR start "rule__Time__MinAssignment_0"
    // ../at.ac.univie.swa.ase2014.a1276754.task3.mydsl.ui/src-gen/at/ac/univie/swa/ase2014/a1276754/task3/ui/contentassist/antlr/internal/InternalMydsl.g:2042:1: rule__Time__MinAssignment_0 : ( RULE_INT ) ;
    public final void rule__Time__MinAssignment_0() throws RecognitionException {

        		int stackSize = keepStackSize();
            
        try {
            // ../at.ac.univie.swa.ase2014.a1276754.task3.mydsl.ui/src-gen/at/ac/univie/swa/ase2014/a1276754/task3/ui/contentassist/antlr/internal/InternalMydsl.g:2046:1: ( ( RULE_INT ) )
            // ../at.ac.univie.swa.ase2014.a1276754.task3.mydsl.ui/src-gen/at/ac/univie/swa/ase2014/a1276754/task3/ui/contentassist/antlr/internal/InternalMydsl.g:2047:1: ( RULE_INT )
            {
            // ../at.ac.univie.swa.ase2014.a1276754.task3.mydsl.ui/src-gen/at/ac/univie/swa/ase2014/a1276754/task3/ui/contentassist/antlr/internal/InternalMydsl.g:2047:1: ( RULE_INT )
            // ../at.ac.univie.swa.ase2014.a1276754.task3.mydsl.ui/src-gen/at/ac/univie/swa/ase2014/a1276754/task3/ui/contentassist/antlr/internal/InternalMydsl.g:2048:1: RULE_INT
            {
             before(grammarAccess.getTimeAccess().getMinINTTerminalRuleCall_0_0()); 
            match(input,RULE_INT,FOLLOW_RULE_INT_in_rule__Time__MinAssignment_04069); 
             after(grammarAccess.getTimeAccess().getMinINTTerminalRuleCall_0_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Time__MinAssignment_0"


    // $ANTLR start "rule__Time__SecAssignment_2"
    // ../at.ac.univie.swa.ase2014.a1276754.task3.mydsl.ui/src-gen/at/ac/univie/swa/ase2014/a1276754/task3/ui/contentassist/antlr/internal/InternalMydsl.g:2057:1: rule__Time__SecAssignment_2 : ( RULE_INT ) ;
    public final void rule__Time__SecAssignment_2() throws RecognitionException {

        		int stackSize = keepStackSize();
            
        try {
            // ../at.ac.univie.swa.ase2014.a1276754.task3.mydsl.ui/src-gen/at/ac/univie/swa/ase2014/a1276754/task3/ui/contentassist/antlr/internal/InternalMydsl.g:2061:1: ( ( RULE_INT ) )
            // ../at.ac.univie.swa.ase2014.a1276754.task3.mydsl.ui/src-gen/at/ac/univie/swa/ase2014/a1276754/task3/ui/contentassist/antlr/internal/InternalMydsl.g:2062:1: ( RULE_INT )
            {
            // ../at.ac.univie.swa.ase2014.a1276754.task3.mydsl.ui/src-gen/at/ac/univie/swa/ase2014/a1276754/task3/ui/contentassist/antlr/internal/InternalMydsl.g:2062:1: ( RULE_INT )
            // ../at.ac.univie.swa.ase2014.a1276754.task3.mydsl.ui/src-gen/at/ac/univie/swa/ase2014/a1276754/task3/ui/contentassist/antlr/internal/InternalMydsl.g:2063:1: RULE_INT
            {
             before(grammarAccess.getTimeAccess().getSecINTTerminalRuleCall_2_0()); 
            match(input,RULE_INT,FOLLOW_RULE_INT_in_rule__Time__SecAssignment_24100); 
             after(grammarAccess.getTimeAccess().getSecINTTerminalRuleCall_2_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Time__SecAssignment_2"


    // $ANTLR start "rule__Playlist__NameAssignment_0"
    // ../at.ac.univie.swa.ase2014.a1276754.task3.mydsl.ui/src-gen/at/ac/univie/swa/ase2014/a1276754/task3/ui/contentassist/antlr/internal/InternalMydsl.g:2072:1: rule__Playlist__NameAssignment_0 : ( RULE_ID ) ;
    public final void rule__Playlist__NameAssignment_0() throws RecognitionException {

        		int stackSize = keepStackSize();
            
        try {
            // ../at.ac.univie.swa.ase2014.a1276754.task3.mydsl.ui/src-gen/at/ac/univie/swa/ase2014/a1276754/task3/ui/contentassist/antlr/internal/InternalMydsl.g:2076:1: ( ( RULE_ID ) )
            // ../at.ac.univie.swa.ase2014.a1276754.task3.mydsl.ui/src-gen/at/ac/univie/swa/ase2014/a1276754/task3/ui/contentassist/antlr/internal/InternalMydsl.g:2077:1: ( RULE_ID )
            {
            // ../at.ac.univie.swa.ase2014.a1276754.task3.mydsl.ui/src-gen/at/ac/univie/swa/ase2014/a1276754/task3/ui/contentassist/antlr/internal/InternalMydsl.g:2077:1: ( RULE_ID )
            // ../at.ac.univie.swa.ase2014.a1276754.task3.mydsl.ui/src-gen/at/ac/univie/swa/ase2014/a1276754/task3/ui/contentassist/antlr/internal/InternalMydsl.g:2078:1: RULE_ID
            {
             before(grammarAccess.getPlaylistAccess().getNameIDTerminalRuleCall_0_0()); 
            match(input,RULE_ID,FOLLOW_RULE_ID_in_rule__Playlist__NameAssignment_04131); 
             after(grammarAccess.getPlaylistAccess().getNameIDTerminalRuleCall_0_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Playlist__NameAssignment_0"


    // $ANTLR start "rule__Playlist__SongsAssignment_2_0"
    // ../at.ac.univie.swa.ase2014.a1276754.task3.mydsl.ui/src-gen/at/ac/univie/swa/ase2014/a1276754/task3/ui/contentassist/antlr/internal/InternalMydsl.g:2087:1: rule__Playlist__SongsAssignment_2_0 : ( ( RULE_ID ) ) ;
    public final void rule__Playlist__SongsAssignment_2_0() throws RecognitionException {

        		int stackSize = keepStackSize();
            
        try {
            // ../at.ac.univie.swa.ase2014.a1276754.task3.mydsl.ui/src-gen/at/ac/univie/swa/ase2014/a1276754/task3/ui/contentassist/antlr/internal/InternalMydsl.g:2091:1: ( ( ( RULE_ID ) ) )
            // ../at.ac.univie.swa.ase2014.a1276754.task3.mydsl.ui/src-gen/at/ac/univie/swa/ase2014/a1276754/task3/ui/contentassist/antlr/internal/InternalMydsl.g:2092:1: ( ( RULE_ID ) )
            {
            // ../at.ac.univie.swa.ase2014.a1276754.task3.mydsl.ui/src-gen/at/ac/univie/swa/ase2014/a1276754/task3/ui/contentassist/antlr/internal/InternalMydsl.g:2092:1: ( ( RULE_ID ) )
            // ../at.ac.univie.swa.ase2014.a1276754.task3.mydsl.ui/src-gen/at/ac/univie/swa/ase2014/a1276754/task3/ui/contentassist/antlr/internal/InternalMydsl.g:2093:1: ( RULE_ID )
            {
             before(grammarAccess.getPlaylistAccess().getSongsSongCrossReference_2_0_0()); 
            // ../at.ac.univie.swa.ase2014.a1276754.task3.mydsl.ui/src-gen/at/ac/univie/swa/ase2014/a1276754/task3/ui/contentassist/antlr/internal/InternalMydsl.g:2094:1: ( RULE_ID )
            // ../at.ac.univie.swa.ase2014.a1276754.task3.mydsl.ui/src-gen/at/ac/univie/swa/ase2014/a1276754/task3/ui/contentassist/antlr/internal/InternalMydsl.g:2095:1: RULE_ID
            {
             before(grammarAccess.getPlaylistAccess().getSongsSongIDTerminalRuleCall_2_0_0_1()); 
            match(input,RULE_ID,FOLLOW_RULE_ID_in_rule__Playlist__SongsAssignment_2_04166); 
             after(grammarAccess.getPlaylistAccess().getSongsSongIDTerminalRuleCall_2_0_0_1()); 

            }

             after(grammarAccess.getPlaylistAccess().getSongsSongCrossReference_2_0_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Playlist__SongsAssignment_2_0"


    // $ANTLR start "rule__Playlist__SongsAssignment_3"
    // ../at.ac.univie.swa.ase2014.a1276754.task3.mydsl.ui/src-gen/at/ac/univie/swa/ase2014/a1276754/task3/ui/contentassist/antlr/internal/InternalMydsl.g:2106:1: rule__Playlist__SongsAssignment_3 : ( ( RULE_ID ) ) ;
    public final void rule__Playlist__SongsAssignment_3() throws RecognitionException {

        		int stackSize = keepStackSize();
            
        try {
            // ../at.ac.univie.swa.ase2014.a1276754.task3.mydsl.ui/src-gen/at/ac/univie/swa/ase2014/a1276754/task3/ui/contentassist/antlr/internal/InternalMydsl.g:2110:1: ( ( ( RULE_ID ) ) )
            // ../at.ac.univie.swa.ase2014.a1276754.task3.mydsl.ui/src-gen/at/ac/univie/swa/ase2014/a1276754/task3/ui/contentassist/antlr/internal/InternalMydsl.g:2111:1: ( ( RULE_ID ) )
            {
            // ../at.ac.univie.swa.ase2014.a1276754.task3.mydsl.ui/src-gen/at/ac/univie/swa/ase2014/a1276754/task3/ui/contentassist/antlr/internal/InternalMydsl.g:2111:1: ( ( RULE_ID ) )
            // ../at.ac.univie.swa.ase2014.a1276754.task3.mydsl.ui/src-gen/at/ac/univie/swa/ase2014/a1276754/task3/ui/contentassist/antlr/internal/InternalMydsl.g:2112:1: ( RULE_ID )
            {
             before(grammarAccess.getPlaylistAccess().getSongsSongCrossReference_3_0()); 
            // ../at.ac.univie.swa.ase2014.a1276754.task3.mydsl.ui/src-gen/at/ac/univie/swa/ase2014/a1276754/task3/ui/contentassist/antlr/internal/InternalMydsl.g:2113:1: ( RULE_ID )
            // ../at.ac.univie.swa.ase2014.a1276754.task3.mydsl.ui/src-gen/at/ac/univie/swa/ase2014/a1276754/task3/ui/contentassist/antlr/internal/InternalMydsl.g:2114:1: RULE_ID
            {
             before(grammarAccess.getPlaylistAccess().getSongsSongIDTerminalRuleCall_3_0_1()); 
            match(input,RULE_ID,FOLLOW_RULE_ID_in_rule__Playlist__SongsAssignment_34205); 
             after(grammarAccess.getPlaylistAccess().getSongsSongIDTerminalRuleCall_3_0_1()); 

            }

             after(grammarAccess.getPlaylistAccess().getSongsSongCrossReference_3_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Playlist__SongsAssignment_3"


    // $ANTLR start "rule__Playlist__InclAssignment_4_1"
    // ../at.ac.univie.swa.ase2014.a1276754.task3.mydsl.ui/src-gen/at/ac/univie/swa/ase2014/a1276754/task3/ui/contentassist/antlr/internal/InternalMydsl.g:2125:1: rule__Playlist__InclAssignment_4_1 : ( ( RULE_ID ) ) ;
    public final void rule__Playlist__InclAssignment_4_1() throws RecognitionException {

        		int stackSize = keepStackSize();
            
        try {
            // ../at.ac.univie.swa.ase2014.a1276754.task3.mydsl.ui/src-gen/at/ac/univie/swa/ase2014/a1276754/task3/ui/contentassist/antlr/internal/InternalMydsl.g:2129:1: ( ( ( RULE_ID ) ) )
            // ../at.ac.univie.swa.ase2014.a1276754.task3.mydsl.ui/src-gen/at/ac/univie/swa/ase2014/a1276754/task3/ui/contentassist/antlr/internal/InternalMydsl.g:2130:1: ( ( RULE_ID ) )
            {
            // ../at.ac.univie.swa.ase2014.a1276754.task3.mydsl.ui/src-gen/at/ac/univie/swa/ase2014/a1276754/task3/ui/contentassist/antlr/internal/InternalMydsl.g:2130:1: ( ( RULE_ID ) )
            // ../at.ac.univie.swa.ase2014.a1276754.task3.mydsl.ui/src-gen/at/ac/univie/swa/ase2014/a1276754/task3/ui/contentassist/antlr/internal/InternalMydsl.g:2131:1: ( RULE_ID )
            {
             before(grammarAccess.getPlaylistAccess().getInclPlaylistCrossReference_4_1_0()); 
            // ../at.ac.univie.swa.ase2014.a1276754.task3.mydsl.ui/src-gen/at/ac/univie/swa/ase2014/a1276754/task3/ui/contentassist/antlr/internal/InternalMydsl.g:2132:1: ( RULE_ID )
            // ../at.ac.univie.swa.ase2014.a1276754.task3.mydsl.ui/src-gen/at/ac/univie/swa/ase2014/a1276754/task3/ui/contentassist/antlr/internal/InternalMydsl.g:2133:1: RULE_ID
            {
             before(grammarAccess.getPlaylistAccess().getInclPlaylistIDTerminalRuleCall_4_1_0_1()); 
            match(input,RULE_ID,FOLLOW_RULE_ID_in_rule__Playlist__InclAssignment_4_14244); 
             after(grammarAccess.getPlaylistAccess().getInclPlaylistIDTerminalRuleCall_4_1_0_1()); 

            }

             after(grammarAccess.getPlaylistAccess().getInclPlaylistCrossReference_4_1_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Playlist__InclAssignment_4_1"


    // $ANTLR start "rule__Playlist__ExclAssignment_4_2_1_0"
    // ../at.ac.univie.swa.ase2014.a1276754.task3.mydsl.ui/src-gen/at/ac/univie/swa/ase2014/a1276754/task3/ui/contentassist/antlr/internal/InternalMydsl.g:2144:1: rule__Playlist__ExclAssignment_4_2_1_0 : ( ( RULE_ID ) ) ;
    public final void rule__Playlist__ExclAssignment_4_2_1_0() throws RecognitionException {

        		int stackSize = keepStackSize();
            
        try {
            // ../at.ac.univie.swa.ase2014.a1276754.task3.mydsl.ui/src-gen/at/ac/univie/swa/ase2014/a1276754/task3/ui/contentassist/antlr/internal/InternalMydsl.g:2148:1: ( ( ( RULE_ID ) ) )
            // ../at.ac.univie.swa.ase2014.a1276754.task3.mydsl.ui/src-gen/at/ac/univie/swa/ase2014/a1276754/task3/ui/contentassist/antlr/internal/InternalMydsl.g:2149:1: ( ( RULE_ID ) )
            {
            // ../at.ac.univie.swa.ase2014.a1276754.task3.mydsl.ui/src-gen/at/ac/univie/swa/ase2014/a1276754/task3/ui/contentassist/antlr/internal/InternalMydsl.g:2149:1: ( ( RULE_ID ) )
            // ../at.ac.univie.swa.ase2014.a1276754.task3.mydsl.ui/src-gen/at/ac/univie/swa/ase2014/a1276754/task3/ui/contentassist/antlr/internal/InternalMydsl.g:2150:1: ( RULE_ID )
            {
             before(grammarAccess.getPlaylistAccess().getExclSongCrossReference_4_2_1_0_0()); 
            // ../at.ac.univie.swa.ase2014.a1276754.task3.mydsl.ui/src-gen/at/ac/univie/swa/ase2014/a1276754/task3/ui/contentassist/antlr/internal/InternalMydsl.g:2151:1: ( RULE_ID )
            // ../at.ac.univie.swa.ase2014.a1276754.task3.mydsl.ui/src-gen/at/ac/univie/swa/ase2014/a1276754/task3/ui/contentassist/antlr/internal/InternalMydsl.g:2152:1: RULE_ID
            {
             before(grammarAccess.getPlaylistAccess().getExclSongIDTerminalRuleCall_4_2_1_0_0_1()); 
            match(input,RULE_ID,FOLLOW_RULE_ID_in_rule__Playlist__ExclAssignment_4_2_1_04283); 
             after(grammarAccess.getPlaylistAccess().getExclSongIDTerminalRuleCall_4_2_1_0_0_1()); 

            }

             after(grammarAccess.getPlaylistAccess().getExclSongCrossReference_4_2_1_0_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Playlist__ExclAssignment_4_2_1_0"


    // $ANTLR start "rule__Playlist__ExclAssignment_4_2_2"
    // ../at.ac.univie.swa.ase2014.a1276754.task3.mydsl.ui/src-gen/at/ac/univie/swa/ase2014/a1276754/task3/ui/contentassist/antlr/internal/InternalMydsl.g:2163:1: rule__Playlist__ExclAssignment_4_2_2 : ( ( RULE_ID ) ) ;
    public final void rule__Playlist__ExclAssignment_4_2_2() throws RecognitionException {

        		int stackSize = keepStackSize();
            
        try {
            // ../at.ac.univie.swa.ase2014.a1276754.task3.mydsl.ui/src-gen/at/ac/univie/swa/ase2014/a1276754/task3/ui/contentassist/antlr/internal/InternalMydsl.g:2167:1: ( ( ( RULE_ID ) ) )
            // ../at.ac.univie.swa.ase2014.a1276754.task3.mydsl.ui/src-gen/at/ac/univie/swa/ase2014/a1276754/task3/ui/contentassist/antlr/internal/InternalMydsl.g:2168:1: ( ( RULE_ID ) )
            {
            // ../at.ac.univie.swa.ase2014.a1276754.task3.mydsl.ui/src-gen/at/ac/univie/swa/ase2014/a1276754/task3/ui/contentassist/antlr/internal/InternalMydsl.g:2168:1: ( ( RULE_ID ) )
            // ../at.ac.univie.swa.ase2014.a1276754.task3.mydsl.ui/src-gen/at/ac/univie/swa/ase2014/a1276754/task3/ui/contentassist/antlr/internal/InternalMydsl.g:2169:1: ( RULE_ID )
            {
             before(grammarAccess.getPlaylistAccess().getExclSongCrossReference_4_2_2_0()); 
            // ../at.ac.univie.swa.ase2014.a1276754.task3.mydsl.ui/src-gen/at/ac/univie/swa/ase2014/a1276754/task3/ui/contentassist/antlr/internal/InternalMydsl.g:2170:1: ( RULE_ID )
            // ../at.ac.univie.swa.ase2014.a1276754.task3.mydsl.ui/src-gen/at/ac/univie/swa/ase2014/a1276754/task3/ui/contentassist/antlr/internal/InternalMydsl.g:2171:1: RULE_ID
            {
             before(grammarAccess.getPlaylistAccess().getExclSongIDTerminalRuleCall_4_2_2_0_1()); 
            match(input,RULE_ID,FOLLOW_RULE_ID_in_rule__Playlist__ExclAssignment_4_2_24322); 
             after(grammarAccess.getPlaylistAccess().getExclSongIDTerminalRuleCall_4_2_2_0_1()); 

            }

             after(grammarAccess.getPlaylistAccess().getExclSongCrossReference_4_2_2_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Playlist__ExclAssignment_4_2_2"

    // Delegated rules


 

    public static final BitSet FOLLOW_ruleModel_in_entryRuleModel61 = new BitSet(new long[]{0x0000000000000000L});
    public static final BitSet FOLLOW_EOF_in_entryRuleModel68 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_rule__Model__Group__0_in_ruleModel94 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_ruleDistributor_in_entryRuleDistributor121 = new BitSet(new long[]{0x0000000000000000L});
    public static final BitSet FOLLOW_EOF_in_entryRuleDistributor128 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_rule__Distributor__Group__0_in_ruleDistributor154 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_ruleAccount_Information_in_entryRuleAccount_Information181 = new BitSet(new long[]{0x0000000000000000L});
    public static final BitSet FOLLOW_EOF_in_entryRuleAccount_Information188 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_rule__Account_Information__Group__0_in_ruleAccount_Information214 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_ruleSong_in_entryRuleSong241 = new BitSet(new long[]{0x0000000000000000L});
    public static final BitSet FOLLOW_EOF_in_entryRuleSong248 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_rule__Song__Group__0_in_ruleSong274 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_ruleTime_in_entryRuleTime301 = new BitSet(new long[]{0x0000000000000000L});
    public static final BitSet FOLLOW_EOF_in_entryRuleTime308 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_rule__Time__Group__0_in_ruleTime334 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_ruleDouble_in_entryRuleDouble361 = new BitSet(new long[]{0x0000000000000000L});
    public static final BitSet FOLLOW_EOF_in_entryRuleDouble368 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_rule__Double__Group__0_in_ruleDouble394 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_rulePlaylist_in_entryRulePlaylist421 = new BitSet(new long[]{0x0000000000000000L});
    public static final BitSet FOLLOW_EOF_in_entryRulePlaylist428 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_rule__Playlist__Group__0_in_rulePlaylist454 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_rule__Genre__Alternatives_in_ruleGenre491 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_11_in_rule__Genre__Alternatives527 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_12_in_rule__Genre__Alternatives548 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_13_in_rule__Genre__Alternatives569 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_14_in_rule__Genre__Alternatives590 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_15_in_rule__Genre__Alternatives611 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_16_in_rule__Genre__Alternatives632 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_rule__Model__Group__0__Impl_in_rule__Model__Group__0665 = new BitSet(new long[]{0x0000000000000020L});
    public static final BitSet FOLLOW_rule__Model__Group__1_in_rule__Model__Group__0668 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_17_in_rule__Model__Group__0__Impl696 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_rule__Model__Group__1__Impl_in_rule__Model__Group__1727 = new BitSet(new long[]{0x0000000000040000L});
    public static final BitSet FOLLOW_rule__Model__Group__2_in_rule__Model__Group__1730 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_rule__Model__DistributorsAssignment_1_in_rule__Model__Group__1__Impl759 = new BitSet(new long[]{0x0000000000000022L});
    public static final BitSet FOLLOW_rule__Model__DistributorsAssignment_1_in_rule__Model__Group__1__Impl771 = new BitSet(new long[]{0x0000000000000022L});
    public static final BitSet FOLLOW_rule__Model__Group__2__Impl_in_rule__Model__Group__2804 = new BitSet(new long[]{0x0000000000000020L});
    public static final BitSet FOLLOW_rule__Model__Group__3_in_rule__Model__Group__2807 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_18_in_rule__Model__Group__2__Impl835 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_rule__Model__Group__3__Impl_in_rule__Model__Group__3866 = new BitSet(new long[]{0x0000000000080000L});
    public static final BitSet FOLLOW_rule__Model__Group__4_in_rule__Model__Group__3869 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_rule__Model__SongsAssignment_3_in_rule__Model__Group__3__Impl898 = new BitSet(new long[]{0x0000000000000022L});
    public static final BitSet FOLLOW_rule__Model__SongsAssignment_3_in_rule__Model__Group__3__Impl910 = new BitSet(new long[]{0x0000000000000022L});
    public static final BitSet FOLLOW_rule__Model__Group__4__Impl_in_rule__Model__Group__4943 = new BitSet(new long[]{0x0000000000000020L});
    public static final BitSet FOLLOW_rule__Model__Group__5_in_rule__Model__Group__4946 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_19_in_rule__Model__Group__4__Impl974 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_rule__Model__Group__5__Impl_in_rule__Model__Group__51005 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_rule__Model__PlaylistsAssignment_5_in_rule__Model__Group__5__Impl1032 = new BitSet(new long[]{0x0000000000000022L});
    public static final BitSet FOLLOW_rule__Distributor__Group__0__Impl_in_rule__Distributor__Group__01075 = new BitSet(new long[]{0x0000000000100000L});
    public static final BitSet FOLLOW_rule__Distributor__Group__1_in_rule__Distributor__Group__01078 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_rule__Distributor__NameAssignment_0_in_rule__Distributor__Group__0__Impl1105 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_rule__Distributor__Group__1__Impl_in_rule__Distributor__Group__11135 = new BitSet(new long[]{0x0000000000000040L});
    public static final BitSet FOLLOW_rule__Distributor__Group__2_in_rule__Distributor__Group__11138 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_20_in_rule__Distributor__Group__1__Impl1166 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_rule__Distributor__Group__2__Impl_in_rule__Distributor__Group__21197 = new BitSet(new long[]{0x0000000000200000L});
    public static final BitSet FOLLOW_rule__Distributor__Group__3_in_rule__Distributor__Group__21200 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_rule__Distributor__AdresseAssignment_2_in_rule__Distributor__Group__2__Impl1227 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_rule__Distributor__Group__3__Impl_in_rule__Distributor__Group__31257 = new BitSet(new long[]{0x0000000000400000L});
    public static final BitSet FOLLOW_rule__Distributor__Group__4_in_rule__Distributor__Group__31260 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_21_in_rule__Distributor__Group__3__Impl1288 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_rule__Distributor__Group__4__Impl_in_rule__Distributor__Group__41319 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_rule__Distributor__Acc_infoAssignment_4_in_rule__Distributor__Group__4__Impl1346 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_rule__Account_Information__Group__0__Impl_in_rule__Account_Information__Group__01386 = new BitSet(new long[]{0x0000000000000040L});
    public static final BitSet FOLLOW_rule__Account_Information__Group__1_in_rule__Account_Information__Group__01389 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_22_in_rule__Account_Information__Group__0__Impl1417 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_rule__Account_Information__Group__1__Impl_in_rule__Account_Information__Group__11448 = new BitSet(new long[]{0x0000000000800000L});
    public static final BitSet FOLLOW_rule__Account_Information__Group__2_in_rule__Account_Information__Group__11451 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_rule__Account_Information__IbanAssignment_1_in_rule__Account_Information__Group__1__Impl1478 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_rule__Account_Information__Group__2__Impl_in_rule__Account_Information__Group__21508 = new BitSet(new long[]{0x0000000000000040L});
    public static final BitSet FOLLOW_rule__Account_Information__Group__3_in_rule__Account_Information__Group__21511 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_23_in_rule__Account_Information__Group__2__Impl1539 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_rule__Account_Information__Group__3__Impl_in_rule__Account_Information__Group__31570 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_rule__Account_Information__BicAssignment_3_in_rule__Account_Information__Group__3__Impl1597 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_rule__Song__Group__0__Impl_in_rule__Song__Group__01635 = new BitSet(new long[]{0x0000000001000000L});
    public static final BitSet FOLLOW_rule__Song__Group__1_in_rule__Song__Group__01638 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_rule__Song__NameAssignment_0_in_rule__Song__Group__0__Impl1665 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_rule__Song__Group__1__Impl_in_rule__Song__Group__11695 = new BitSet(new long[]{0x0000000000000040L});
    public static final BitSet FOLLOW_rule__Song__Group__2_in_rule__Song__Group__11698 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_24_in_rule__Song__Group__1__Impl1726 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_rule__Song__Group__2__Impl_in_rule__Song__Group__21757 = new BitSet(new long[]{0x0000000002000000L});
    public static final BitSet FOLLOW_rule__Song__Group__3_in_rule__Song__Group__21760 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_rule__Song__ArtistAssignment_2_in_rule__Song__Group__2__Impl1787 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_rule__Song__Group__3__Impl_in_rule__Song__Group__31817 = new BitSet(new long[]{0x0000000000000020L});
    public static final BitSet FOLLOW_rule__Song__Group__4_in_rule__Song__Group__31820 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_25_in_rule__Song__Group__3__Impl1848 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_rule__Song__Group__4__Impl_in_rule__Song__Group__41879 = new BitSet(new long[]{0x0000000004000000L});
    public static final BitSet FOLLOW_rule__Song__Group__5_in_rule__Song__Group__41882 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_rule__Song__DistAssignment_4_in_rule__Song__Group__4__Impl1909 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_rule__Song__Group__5__Impl_in_rule__Song__Group__51939 = new BitSet(new long[]{0x0000000000000010L});
    public static final BitSet FOLLOW_rule__Song__Group__6_in_rule__Song__Group__51942 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_26_in_rule__Song__Group__5__Impl1970 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_rule__Song__Group__6__Impl_in_rule__Song__Group__62001 = new BitSet(new long[]{0x0000000008000000L});
    public static final BitSet FOLLOW_rule__Song__Group__7_in_rule__Song__Group__62004 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_rule__Song__LengthAssignment_6_in_rule__Song__Group__6__Impl2031 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_rule__Song__Group__7__Impl_in_rule__Song__Group__72061 = new BitSet(new long[]{0x000000000001F800L});
    public static final BitSet FOLLOW_rule__Song__Group__8_in_rule__Song__Group__72064 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_27_in_rule__Song__Group__7__Impl2092 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_rule__Song__Group__8__Impl_in_rule__Song__Group__82123 = new BitSet(new long[]{0x0000000010000000L});
    public static final BitSet FOLLOW_rule__Song__Group__9_in_rule__Song__Group__82126 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_rule__Song__GenreAssignment_8_in_rule__Song__Group__8__Impl2153 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_rule__Song__Group__9__Impl_in_rule__Song__Group__92183 = new BitSet(new long[]{0x0000000000000010L});
    public static final BitSet FOLLOW_rule__Song__Group__10_in_rule__Song__Group__92186 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_28_in_rule__Song__Group__9__Impl2214 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_rule__Song__Group__10__Impl_in_rule__Song__Group__102245 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_rule__Song__PriceAssignment_10_in_rule__Song__Group__10__Impl2272 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_rule__Time__Group__0__Impl_in_rule__Time__Group__02324 = new BitSet(new long[]{0x0000000020000000L});
    public static final BitSet FOLLOW_rule__Time__Group__1_in_rule__Time__Group__02327 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_rule__Time__MinAssignment_0_in_rule__Time__Group__0__Impl2354 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_rule__Time__Group__1__Impl_in_rule__Time__Group__12384 = new BitSet(new long[]{0x0000000000000010L});
    public static final BitSet FOLLOW_rule__Time__Group__2_in_rule__Time__Group__12387 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_29_in_rule__Time__Group__1__Impl2415 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_rule__Time__Group__2__Impl_in_rule__Time__Group__22446 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_rule__Time__SecAssignment_2_in_rule__Time__Group__2__Impl2473 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_rule__Double__Group__0__Impl_in_rule__Double__Group__02509 = new BitSet(new long[]{0x0000000040000000L});
    public static final BitSet FOLLOW_rule__Double__Group__1_in_rule__Double__Group__02512 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_RULE_INT_in_rule__Double__Group__0__Impl2539 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_rule__Double__Group__1__Impl_in_rule__Double__Group__12568 = new BitSet(new long[]{0x0000000000000010L});
    public static final BitSet FOLLOW_rule__Double__Group__2_in_rule__Double__Group__12571 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_30_in_rule__Double__Group__1__Impl2599 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_rule__Double__Group__2__Impl_in_rule__Double__Group__22630 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_RULE_INT_in_rule__Double__Group__2__Impl2657 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_rule__Playlist__Group__0__Impl_in_rule__Playlist__Group__02692 = new BitSet(new long[]{0x0000000080000000L});
    public static final BitSet FOLLOW_rule__Playlist__Group__1_in_rule__Playlist__Group__02695 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_rule__Playlist__NameAssignment_0_in_rule__Playlist__Group__0__Impl2722 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_rule__Playlist__Group__1__Impl_in_rule__Playlist__Group__12752 = new BitSet(new long[]{0x0000000200000020L});
    public static final BitSet FOLLOW_rule__Playlist__Group__2_in_rule__Playlist__Group__12755 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_31_in_rule__Playlist__Group__1__Impl2783 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_rule__Playlist__Group__2__Impl_in_rule__Playlist__Group__22814 = new BitSet(new long[]{0x0000000200000020L});
    public static final BitSet FOLLOW_rule__Playlist__Group__3_in_rule__Playlist__Group__22817 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_rule__Playlist__Group_2__0_in_rule__Playlist__Group__2__Impl2844 = new BitSet(new long[]{0x0000000000000022L});
    public static final BitSet FOLLOW_rule__Playlist__Group__3__Impl_in_rule__Playlist__Group__32875 = new BitSet(new long[]{0x0000000200000020L});
    public static final BitSet FOLLOW_rule__Playlist__Group__4_in_rule__Playlist__Group__32878 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_rule__Playlist__SongsAssignment_3_in_rule__Playlist__Group__3__Impl2905 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_rule__Playlist__Group__4__Impl_in_rule__Playlist__Group__42936 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_rule__Playlist__Group_4__0_in_rule__Playlist__Group__4__Impl2963 = new BitSet(new long[]{0x0000000200000002L});
    public static final BitSet FOLLOW_rule__Playlist__Group_2__0__Impl_in_rule__Playlist__Group_2__03004 = new BitSet(new long[]{0x0000000100000000L});
    public static final BitSet FOLLOW_rule__Playlist__Group_2__1_in_rule__Playlist__Group_2__03007 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_rule__Playlist__SongsAssignment_2_0_in_rule__Playlist__Group_2__0__Impl3034 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_rule__Playlist__Group_2__1__Impl_in_rule__Playlist__Group_2__13064 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_32_in_rule__Playlist__Group_2__1__Impl3092 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_rule__Playlist__Group_4__0__Impl_in_rule__Playlist__Group_4__03127 = new BitSet(new long[]{0x0000000000000020L});
    public static final BitSet FOLLOW_rule__Playlist__Group_4__1_in_rule__Playlist__Group_4__03130 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_33_in_rule__Playlist__Group_4__0__Impl3158 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_rule__Playlist__Group_4__1__Impl_in_rule__Playlist__Group_4__13189 = new BitSet(new long[]{0x0000000400000000L});
    public static final BitSet FOLLOW_rule__Playlist__Group_4__2_in_rule__Playlist__Group_4__13192 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_rule__Playlist__InclAssignment_4_1_in_rule__Playlist__Group_4__1__Impl3219 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_rule__Playlist__Group_4__2__Impl_in_rule__Playlist__Group_4__23249 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_rule__Playlist__Group_4_2__0_in_rule__Playlist__Group_4__2__Impl3276 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_rule__Playlist__Group_4_2__0__Impl_in_rule__Playlist__Group_4_2__03313 = new BitSet(new long[]{0x0000000000000020L});
    public static final BitSet FOLLOW_rule__Playlist__Group_4_2__1_in_rule__Playlist__Group_4_2__03316 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_34_in_rule__Playlist__Group_4_2__0__Impl3344 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_rule__Playlist__Group_4_2__1__Impl_in_rule__Playlist__Group_4_2__13375 = new BitSet(new long[]{0x0000000000000020L});
    public static final BitSet FOLLOW_rule__Playlist__Group_4_2__2_in_rule__Playlist__Group_4_2__13378 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_rule__Playlist__Group_4_2_1__0_in_rule__Playlist__Group_4_2__1__Impl3405 = new BitSet(new long[]{0x0000000000000022L});
    public static final BitSet FOLLOW_rule__Playlist__Group_4_2__2__Impl_in_rule__Playlist__Group_4_2__23436 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_rule__Playlist__ExclAssignment_4_2_2_in_rule__Playlist__Group_4_2__2__Impl3463 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_rule__Playlist__Group_4_2_1__0__Impl_in_rule__Playlist__Group_4_2_1__03499 = new BitSet(new long[]{0x0000000100000000L});
    public static final BitSet FOLLOW_rule__Playlist__Group_4_2_1__1_in_rule__Playlist__Group_4_2_1__03502 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_rule__Playlist__ExclAssignment_4_2_1_0_in_rule__Playlist__Group_4_2_1__0__Impl3529 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_rule__Playlist__Group_4_2_1__1__Impl_in_rule__Playlist__Group_4_2_1__13559 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_32_in_rule__Playlist__Group_4_2_1__1__Impl3587 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_ruleDistributor_in_rule__Model__DistributorsAssignment_13627 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_ruleSong_in_rule__Model__SongsAssignment_33658 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_rulePlaylist_in_rule__Model__PlaylistsAssignment_53689 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_RULE_ID_in_rule__Distributor__NameAssignment_03720 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_RULE_STRING_in_rule__Distributor__AdresseAssignment_23751 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_ruleAccount_Information_in_rule__Distributor__Acc_infoAssignment_43782 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_RULE_STRING_in_rule__Account_Information__IbanAssignment_13813 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_RULE_STRING_in_rule__Account_Information__BicAssignment_33844 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_RULE_ID_in_rule__Song__NameAssignment_03875 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_RULE_STRING_in_rule__Song__ArtistAssignment_23906 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_RULE_ID_in_rule__Song__DistAssignment_43941 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_ruleTime_in_rule__Song__LengthAssignment_63976 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_ruleGenre_in_rule__Song__GenreAssignment_84007 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_ruleDouble_in_rule__Song__PriceAssignment_104038 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_RULE_INT_in_rule__Time__MinAssignment_04069 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_RULE_INT_in_rule__Time__SecAssignment_24100 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_RULE_ID_in_rule__Playlist__NameAssignment_04131 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_RULE_ID_in_rule__Playlist__SongsAssignment_2_04166 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_RULE_ID_in_rule__Playlist__SongsAssignment_34205 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_RULE_ID_in_rule__Playlist__InclAssignment_4_14244 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_RULE_ID_in_rule__Playlist__ExclAssignment_4_2_1_04283 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_RULE_ID_in_rule__Playlist__ExclAssignment_4_2_24322 = new BitSet(new long[]{0x0000000000000002L});

}