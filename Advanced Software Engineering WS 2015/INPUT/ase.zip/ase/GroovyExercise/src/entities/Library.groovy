package entities


class Library {
	Model model
	List<Song> songs = new ArrayList<Song>()

}
