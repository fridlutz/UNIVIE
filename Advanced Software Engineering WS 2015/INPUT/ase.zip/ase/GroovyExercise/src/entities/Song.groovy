package entities

class Song {
	Library library
	String name
	String singer
	Distributor distributor
	String length
	Genre genre
	double price
}
