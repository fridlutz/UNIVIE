package entities

class Distributor {
	Model model
	String name
	String address
	String iban
	String bic

}
