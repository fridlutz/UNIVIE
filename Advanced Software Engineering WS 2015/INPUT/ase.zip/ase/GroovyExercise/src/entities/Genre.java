package entities;

public enum Genre {
	POP, ROCK, HARDROCK, CLASSIC, FOLK
}
