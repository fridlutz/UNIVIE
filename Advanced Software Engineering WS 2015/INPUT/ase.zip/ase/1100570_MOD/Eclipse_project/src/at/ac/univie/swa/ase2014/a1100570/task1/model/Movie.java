/**
 * @author Volodimir Begy, a1100570
 */

package at.ac.univie.swa.ase2014.a1100570.task1.model;

public class Movie extends Content {

	public Movie(int _id, String _name, boolean _inhome) {
		super(_id, _name, _inhome);
		
	}

}
